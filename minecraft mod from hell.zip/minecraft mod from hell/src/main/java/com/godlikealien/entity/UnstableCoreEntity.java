package com.godlikealien.entity;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.server.ExplosionManager;
import com.godlikealien.server.TimeFreeze;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkHooks;

import java.util.Optional;
import java.util.UUID;

/**
 * The unstable energy core left behind by the Super Laser. It pulses for a while and then detonates
 * in a ginormous, expanding explosion wave.
 */
public class UnstableCoreEntity extends Entity {
    private static final EntityDataAccessor<Integer> FUSE = SynchedEntityData.defineId(UnstableCoreEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MAX_FUSE = SynchedEntityData.defineId(UnstableCoreEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> POWER = SynchedEntityData.defineId(UnstableCoreEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(UnstableCoreEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    private int nextBeatIn = 0;

    public UnstableCoreEntity(EntityType<? extends UnstableCoreEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static UnstableCoreEntity plant(ServerLevel level, Vec3 pos, UUID owner, float power) {
        UnstableCoreEntity core = new UnstableCoreEntity(GodlikeEntities.UNSTABLE_CORE.get(), level);
        core.setPos(pos.x, pos.y, pos.z);
        int fuse = GodlikeConfig.COMMON.laserDetonationDelayTicks.get();
        core.entityData.set(FUSE, fuse);
        core.entityData.set(MAX_FUSE, fuse);
        core.entityData.set(POWER, power);
        core.entityData.set(OWNER, Optional.ofNullable(owner));
        level.addFreshEntity(core);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.RESPAWN_ANCHOR_SET_SPAWN, SoundSource.PLAYERS, 3.0f, 0.5f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 3.0f, 0.6f);
        return core;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(FUSE, 300);
        this.entityData.define(MAX_FUSE, 300);
        this.entityData.define(POWER, 0.0f);
        this.entityData.define(OWNER, Optional.empty());
    }

    public int getFuse() {
        return this.entityData.get(FUSE);
    }

    public int getMaxFuse() {
        return Math.max(1, this.entityData.get(MAX_FUSE));
    }

    public float getPower() {
        return this.entityData.get(POWER);
    }

    public Optional<UUID> getOwner() {
        return this.entityData.get(OWNER);
    }

    /** 0 = just planted, 1 = about to blow. */
    public float getProgress(float partialTick) {
        float fuse = getFuse() - partialTick;
        return Mth.clamp(1.0f - fuse / getMaxFuse(), 0.0f, 1.0f);
    }

    public int getExplosionRadius() {
        int min = GodlikeConfig.COMMON.laserExplosionMinRadius.get();
        int max = GodlikeConfig.COMMON.laserExplosionMaxRadius.get();
        return Math.round(Mth.lerp(getPower(), min, max));
    }

    @Override
    public void tick() {
        // Chaos Control: the countdown pauses while time is frozen
        if (this.level().isClientSide ? TimeFreeze.CLIENT_FROZEN.test(this) : TimeFreeze.isFrozen(this)) {
            this.setDeltaMovement(Vec3.ZERO);
            return;
        }
        super.tick();
        this.setDeltaMovement(Vec3.ZERO);
        if (this.level().isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.godlikealien.client.UnstableCoreClientFx.tick(this));
            return;
        }

        int fuse = getFuse() - 1;
        this.entityData.set(FUSE, fuse);

        // accelerating heartbeat
        if (--nextBeatIn <= 0) {
            float progress = getProgress(0);
            nextBeatIn = Math.max(3, Math.round(24 * (1.0f - progress * progress)));
            float pitch = 0.6f + progress * 0.9f;
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_HEARTBEAT, SoundSource.HOSTILE, 4.0f, pitch);
            if (progress > 0.75f) {
                this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.WARDEN_TENDRIL_CLICKS, SoundSource.HOSTILE, 3.0f, 0.5f + progress);
            }
        }
        if (fuse == 60 || fuse == 40 || fuse == 20) {
            this.level().playSound(null, getX(), getY(), getZ(), SoundEvents.SCULK_SHRIEKER_SHRIEK, SoundSource.HOSTILE, 5.0f, 0.8f);
        }
        if (fuse % 20 == 0 && fuse > 0 && this.level() instanceof ServerLevel serverLevel) {
            GodlikeNetwork.sendNear(serverLevel, position(), 256.0, new FxPacket(FxPacket.CORE_WARNING, position(), Vec3.ZERO, getPower(), fuse));
        }

        if (fuse <= 0) {
            detonate();
        }
    }

    private void detonate() {
        if (!(this.level() instanceof ServerLevel serverLevel)) return;
        int radius = getExplosionRadius();
        float damage = GodlikeConfig.COMMON.laserExplosionDamage.get().floatValue();
        Vec3 pos = position();
        ExplosionManager.start(serverLevel, pos, radius, getOwner().orElse(null), damage,
                GodlikeConfig.COMMON.laserExplosionBreaksBlocks.get());
        GodlikeNetwork.sendNear(serverLevel, pos, 512.0, new FxPacket(FxPacket.MEGA_EXPLOSION, pos, Vec3.ZERO, radius, 0));
        serverLevel.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 16.0f, 0.35f);
        serverLevel.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.HOSTILE, 16.0f, 0.5f);
        serverLevel.playSound(null, pos.x, pos.y, pos.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.HOSTILE, 10.0f, 0.4f);
        serverLevel.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENDER_DRAGON_DEATH, SoundSource.HOSTILE, 6.0f, 0.5f);
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 320.0 * 320.0;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(FUSE, tag.getInt("Fuse"));
        this.entityData.set(MAX_FUSE, Math.max(1, tag.getInt("MaxFuse")));
        this.entityData.set(POWER, tag.getFloat("Power"));
        if (tag.hasUUID("Owner")) {
            this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Fuse", getFuse());
        tag.putInt("MaxFuse", getMaxFuse());
        tag.putFloat("Power", getPower());
        getOwner().ifPresent(uuid -> tag.putUUID("Owner", uuid));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
