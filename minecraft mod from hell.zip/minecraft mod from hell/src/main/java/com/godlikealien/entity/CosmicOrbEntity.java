package com.godlikealien.entity;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.server.TimeFreeze;
import com.godlikealien.util.BlockBreaker;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;
import java.util.Optional;
import java.util.UUID;

/**
 * A Cosmic Barrage orb. Tier 0 orbs steer toward the owner's crosshair and burst into tier 1 bomblets
 * when they hit something; bomblets arc out under gravity and explode on contact or after a short fuse.
 */
public class CosmicOrbEntity extends Entity {
    private static final EntityDataAccessor<Float> POWER = SynchedEntityData.defineId(CosmicOrbEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Byte> TIER = SynchedEntityData.defineId(CosmicOrbEntity.class, EntityDataSerializers.BYTE);
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(CosmicOrbEntity.class, EntityDataSerializers.OPTIONAL_UUID);

    private static final int BOMBLET_ARM_TICKS = 5;
    /** Orbs closer than this to their owner never explode on blocks (and are skipped by remote detonation). */
    public static final double OWNER_SAFE_DISTANCE = 3.0;

    private int life;
    private int fuse = 200;
    private float formAngle;
    private float formRadius = 0.3f;
    private double speed = 1.3;
    private boolean exploded;

    public CosmicOrbEntity(EntityType<? extends CosmicOrbEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static CosmicOrbEntity launch(ServerLevel level, @Nullable UUID owner, Vec3 pos, Vec3 velocity, float power, int tier,
                                         int fuse, float formAngle, float formRadius, double speed) {
        CosmicOrbEntity orb = new CosmicOrbEntity(GodlikeEntities.COSMIC_ORB.get(), level);
        orb.setPos(pos.x, pos.y, pos.z);
        orb.setDeltaMovement(velocity);
        orb.entityData.set(POWER, power);
        orb.entityData.set(TIER, (byte) tier);
        orb.entityData.set(OWNER, Optional.ofNullable(owner));
        orb.fuse = fuse;
        orb.formAngle = formAngle;
        orb.formRadius = formRadius;
        orb.speed = speed;
        level.addFreshEntity(orb);
        return orb;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(POWER, 1.0f);
        this.entityData.define(TIER, (byte) 0);
        this.entityData.define(OWNER, Optional.empty());
    }

    public float getPower() {
        return this.entityData.get(POWER);
    }

    public int getTier() {
        return this.entityData.get(TIER);
    }

    public Optional<UUID> getOwner() {
        return this.entityData.get(OWNER);
    }

    @Nullable
    public Player getOwnerPlayer() {
        return getOwner().map(uuid -> this.level().getPlayerByUUID(uuid)).orElse(null);
    }

    public boolean isOwner(Entity e) {
        return getOwner().map(uuid -> uuid.equals(e.getUUID())).orElse(false);
    }

    private boolean canHit(Entity e) {
        return e.isAlive() && !e.isSpectator() && !(e instanceof CosmicOrbEntity) && !(e instanceof UnstableCoreEntity) && !isOwner(e);
    }

    @Override
    public void tick() {
        // Chaos Control: frozen orbs hang in the air and resume later
        if (this.level().isClientSide ? TimeFreeze.CLIENT_FROZEN.test(this) : TimeFreeze.isFrozen(this)) return;
        super.tick();
        if (this.level().isClientSide) {
            Vec3 v = getDeltaMovement();
            setPos(getX() + v.x, getY() + v.y, getZ() + v.z);
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.godlikealien.client.CosmicOrbClientFx.tick(this));
            return;
        }
        if (exploded) return;
        life++;
        ServerLevel level = (ServerLevel) this.level();
        if (life > fuse) {
            explode(false);
            return;
        }

        Vec3 vel = getDeltaMovement();
        if (getTier() == 0) {
            Player owner = getOwnerPlayer();
            if (owner != null && owner.isAlive() && owner.distanceToSqr(this) < 300.0 * 300.0) {
                Vec3 look = owner.getLookAngle().normalize();
                Vec3 u = GodlikeMath.perpendicular(look);
                Vec3 w = look.cross(u).normalize();
                Vec3 offset = u.scale(Math.cos(formAngle)).add(w.scale(Math.sin(formAngle))).scale(formRadius);
                Vec3 desired = look.add(offset).normalize();
                Vec3 dir = vel.lengthSqr() > 1.0E-6 ? vel.normalize() : desired;
                double steer = GodlikeConfig.COMMON.barrageSteering.get();
                Vec3 newDir = dir.add(desired.subtract(dir).scale(steer));
                if (newDir.lengthSqr() < 1.0E-6) newDir = desired;
                vel = newDir.normalize().scale(speed);
            }
        } else {
            vel = vel.add(0, -0.05, 0).scale(0.985);
        }
        setDeltaMovement(vel);

        Vec3 from = position();
        Vec3 to = from.add(vel);
        // Orbs arm a few ticks after launch and only once they are clear of their owner, so a wall or the ground
        // right next to the player never sets them off point-blank (they pass through it instead).
        boolean armed;
        if (getTier() == 0) {
            Player owner = getOwnerPlayer();
            double ownerDist2 = owner != null ? owner.distanceToSqr(this) : Double.MAX_VALUE;
            armed = life > 3 && ownerDist2 > OWNER_SAFE_DISTANCE * OWNER_SAFE_DISTANCE;
        } else {
            armed = life > BOMBLET_ARM_TICKS;
        }
        // living targets are always fair game (that is what you aimed at)
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(level, this, from, to,
                getBoundingBox().expandTowards(vel).inflate(1.0), this::canHit, 0.3f);
        if (entityHit != null) {
            setPos(entityHit.getLocation().x, entityHit.getLocation().y, entityHit.getLocation().z);
            explode(true);
            return;
        }
        if (armed) {
            BlockHitResult blockHit = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (blockHit.getType() == HitResult.Type.BLOCK) {
                Vec3 back = vel.lengthSqr() > 1.0E-6 ? vel.normalize().scale(0.35) : Vec3.ZERO;
                Vec3 p = blockHit.getLocation().subtract(back);
                setPos(p.x, p.y, p.z);
                explode(true);
                return;
            }
        }
        setPos(to.x, to.y, to.z);
        if (getY() < level.getMinBuildHeight() - 16 || getY() > level.getMaxBuildHeight() + 96) {
            discard();
        }
    }

    /** Remote detonation (the owner pressed the barrage key again). Orbs still next to the owner keep flying. */
    public boolean detonate() {
        if (this.level().isClientSide || exploded) return false;
        Player owner = getOwnerPlayer();
        if (owner != null && owner.distanceToSqr(this) < OWNER_SAFE_DISTANCE * OWNER_SAFE_DISTANCE) return false;
        explode(true);
        return true;
    }

    private void explode(boolean cluster) {
        exploded = true;
        ServerLevel level = (ServerLevel) this.level();
        int tier = getTier();
        float power = getPower();
        double radius = tier == 0
                ? GodlikeConfig.COMMON.barrageExplosionRadius.get() * (0.6 + 0.4 * power)
                : GodlikeConfig.COMMON.barrageClusterRadius.get();
        float damage = tier == 0
                ? (float) (GodlikeConfig.COMMON.barrageDamage.get() * (0.6 + 0.4 * power))
                : GodlikeConfig.COMMON.barrageClusterDamage.get().floatValue();
        Vec3 pos = position();
        Player owner = getOwnerPlayer();

        AABB box = new AABB(pos, pos).inflate(radius + 1.5);
        for (Entity e : level.getEntities(this, box, ent -> ent.isAlive() && !(ent instanceof CosmicOrbEntity) && !(ent instanceof UnstableCoreEntity))) {
            if (owner != null && e == owner) continue;
            Vec3 c = e.getBoundingBox().getCenter();
            double dist = c.distanceTo(pos);
            if (dist > radius + 1.0) continue;
            double falloff = 1.0 - Mth.clamp(dist / (radius + 1.5), 0.0, 0.7);
            if (e instanceof LivingEntity living) {
                DamageSource source = level.damageSources().indirectMagic(this, owner);
                living.hurt(source, (float) (damage * falloff));
                living.setSecondsOnFire(2);
            }
            Vec3 away = c.subtract(pos);
            if (away.lengthSqr() < 1.0E-4) away = new Vec3(0, 1, 0);
            Vec3 launch = away.normalize().scale(1.2 * falloff).add(0, 0.5 * falloff, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(launch));
            e.hurtMarked = true;
        }

        if (GodlikeConfig.COMMON.barrageBreaksBlocks.get()) {
            BlockBreaker.sphere(level, pos, radius * 0.85, 1500);
        }

        if (cluster && tier == 0) {
            spawnBomblets(level, pos, power);
        }

        GodlikeNetwork.sendNear(level, pos, 160.0, new FxPacket(FxPacket.ORB_EXPLOSION, pos, Vec3.ZERO, (float) radius, tier));
        if (tier == 0) {
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 3.0f, 1.1f);
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 3.0f, 0.8f);
        } else {
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 2.0f, 1.3f);
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 1.6f);
        }
        discard();
    }

    private void spawnBomblets(ServerLevel level, Vec3 pos, float power) {
        int n = Math.round(GodlikeConfig.COMMON.barrageClusterCount.get() * (0.6f + 0.4f * power));
        if (n <= 0) return;
        UUID owner = getOwner().orElse(null);
        Vec3 base = pos.add(0, 0.5, 0);
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n + (random.nextDouble() - 0.5) * 0.5;
            double h = 0.28 + random.nextDouble() * 0.3;
            Vec3 v = new Vec3(Math.cos(a) * h, 0.5 + random.nextDouble() * 0.4, Math.sin(a) * h);
            launch(level, owner, base, v, power * 0.7f, 1, 40 + random.nextInt(30), 0.0f, 0.0f, 0.0);
        }
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return distance < 256.0 * 256.0;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        life = tag.getInt("Life");
        fuse = tag.contains("Fuse") ? tag.getInt("Fuse") : 200;
        formAngle = tag.getFloat("FormAngle");
        formRadius = tag.getFloat("FormRadius");
        speed = tag.contains("Speed") ? tag.getDouble("Speed") : 1.3;
        this.entityData.set(POWER, tag.getFloat("Power"));
        this.entityData.set(TIER, tag.getByte("Tier"));
        if (tag.hasUUID("Owner")) {
            this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Life", life);
        tag.putInt("Fuse", fuse);
        tag.putFloat("FormAngle", formAngle);
        tag.putFloat("FormRadius", formRadius);
        tag.putDouble("Speed", speed);
        tag.putFloat("Power", getPower());
        tag.putByte("Tier", (byte) getTier());
        getOwner().ifPresent(uuid -> tag.putUUID("Owner", uuid));
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
