package com.godlikealien.entity;

import com.godlikealien.GodlikeAlien;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class GodlikeEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, GodlikeAlien.MODID);

    public static final RegistryObject<EntityType<UnstableCoreEntity>> UNSTABLE_CORE = ENTITIES.register("unstable_core",
            () -> EntityType.Builder.<UnstableCoreEntity>of(UnstableCoreEntity::new, MobCategory.MISC)
                    .sized(1.2f, 1.2f)
                    .clientTrackingRange(20)
                    .updateInterval(10)
                    .fireImmune()
                    .build("unstable_core"));

    public static final RegistryObject<EntityType<CosmicOrbEntity>> COSMIC_ORB = ENTITIES.register("cosmic_orb",
            () -> EntityType.Builder.<CosmicOrbEntity>of(CosmicOrbEntity::new, MobCategory.MISC)
                    .sized(0.5f, 0.5f)
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .setShouldReceiveVelocityUpdates(true)
                    .fireImmune()
                    .build("cosmic_orb"));

    private GodlikeEntities() {}
}
