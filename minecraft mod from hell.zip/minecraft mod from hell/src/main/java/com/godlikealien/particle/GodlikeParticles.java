package com.godlikealien.particle;

import com.godlikealien.GodlikeAlien;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class GodlikeParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, GodlikeAlien.MODID);

    /** Soft additive glow blob. */
    public static final RegistryObject<SimpleParticleType> GLOW = PARTICLES.register("glow", () -> new SimpleParticleType(true));
    /** Bright 4-point star spark. */
    public static final RegistryObject<SimpleParticleType> SPARK = PARTICLES.register("spark", () -> new SimpleParticleType(true));
    /** Flat expanding shockwave ring. */
    public static final RegistryObject<SimpleParticleType> RING = PARTICLES.register("ring", () -> new SimpleParticleType(true));
    /** Elongated light streak. */
    public static final RegistryObject<SimpleParticleType> STREAK = PARTICLES.register("streak", () -> new SimpleParticleType(true));

    private GodlikeParticles() {}
}
