package com.godlikealien;

import com.godlikealien.entity.GodlikeEntities;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.particle.GodlikeParticles;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Godlike Alien - an extension for ViltrumiteCore that adds a godlike power set:
 * Super Laser, Lightspeed Dash, Godlike Punch, Godlike Resistance and Sonic Flight.
 */
@Mod(GodlikeAlien.MODID)
public class GodlikeAlien {
    public static final String MODID = "godlikealien";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GodlikeAlien() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, GodlikeConfig.COMMON_SPEC, "godlikealien-common.toml");
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, GodlikeConfig.CLIENT_SPEC, "godlikealien-client.toml");

        GodlikeEntities.ENTITIES.register(modBus);
        GodlikeParticles.PARTICLES.register(modBus);

        modBus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            GodlikeNetwork.register();
            GodlikeAbilities.registerAll();
            LOGGER.info("[Godlike Alien] Registered {} godlike abilities into the Viltrumite ability registry", GodlikeAbilities.ALL_IDS.size());
        });
    }
}
