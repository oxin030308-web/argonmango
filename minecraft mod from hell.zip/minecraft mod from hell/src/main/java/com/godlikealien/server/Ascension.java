package com.godlikealien.server;

import com.baranhan123.viltrumitecore.util.ViltrumiteAbilityUser;
import com.baranhan123.viltrumitecore.util.ViltrumiteCorePlayer;
import com.godlikealien.GodlikeAbilities;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.state.GodlikeStateManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Becoming (and un-becoming) a Godlike Alien. */
public final class Ascension {
    private Ascension() {}

    public static void ascendFromRaceScreen(ServerPlayer player) {
        if (player instanceof ViltrumiteCorePlayer core) {
            core.setViltrumite(true);
            core.setChosenRace(true);
        }
        ascend(player, true);
    }

    public static void ascend(ServerPlayer player, boolean announce) {
        GodlikeState state = GodlikeStateManager.get(player);
        if (player instanceof ViltrumiteCorePlayer core && !core.isViltrumite()) {
            core.setViltrumite(true);
            core.setChosenRace(true);
        }
        boolean wasGodlike = state.godlike;
        state.godlike = true;
        state.resistance = true;
        state.sonicFlight = true;
        state.dirty = true;
        GodlikeStateManager.savePersisted(player, state);
        int page = equipAbilities(player);
        addMissingAbilities(player); // more abilities than one page holds: the rest go to free slots on other pages
        GodlikeServerEvents.sync(player, state);

        Vec3 pos = player.position();
        GodlikeNetwork.sendNear(player.serverLevel(), pos, 128.0, new FxPacket(FxPacket.ASCEND, pos, Vec3.ZERO, 1.0f, 0));
        player.serverLevel().playSound(null, pos.x, pos.y, pos.z, SoundEvents.TOTEM_USE, SoundSource.PLAYERS, 3.0f, 0.6f);
        player.serverLevel().playSound(null, pos.x, pos.y, pos.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 3.0f, 0.8f);
        player.serverLevel().playSound(null, pos.x, pos.y, pos.z, SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 2.0f, 1.2f);

        if (announce) {
            player.sendSystemMessage(Component.literal(wasGodlike ? "Your godlike power surges anew." : "You have ascended. You are a GODLIKE ALIEN.")
                    .withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD));
            if (page >= 0) {
                player.sendSystemMessage(Component.literal("Your godlike abilities were placed on ability page " + (page + 1)
                        + ". Press ALT to swap pages, K to rearrange them.").withStyle(ChatFormatting.GRAY));
            } else {
                player.sendSystemMessage(Component.literal("Open the ability menu (K) to equip your godlike abilities.")
                        .withStyle(ChatFormatting.GRAY));
            }
            player.sendSystemMessage(Component.literal("Nothing can harm you. Cruise past 80% throttle to fly at the speed of sound.")
                    .withStyle(ChatFormatting.DARK_AQUA));
        }
    }

    public static void descend(ServerPlayer player) {
        GodlikeState state = GodlikeStateManager.get(player);
        state.godlike = false;
        state.laserCharge = -1;
        state.punchPending = false;
        state.dirty = true;
        GodlikeStateManager.savePersisted(player, state);
        GodlikeServerEvents.sync(player, state);
        player.sendSystemMessage(Component.literal("Your godlike power fades. You are a regular Viltrumite again.").withStyle(ChatFormatting.GRAY));
    }

    /**
     * Puts the godlike abilities on the first fully empty hotbar page (pages 2 and 3 are usually empty).
     * @return the page index used, or -1 if nothing was equipped.
     */
    public static int equipAbilities(ServerPlayer player) {
        if (!(player instanceof ViltrumiteAbilityUser user)) return -1;
        // already equipped somewhere? then leave the player's layout alone
        for (int i = 0; i < 18; i++) {
            if (GodlikeAbilities.isGodlike(user.getAbilityInSlot(i))) return -1;
        }
        for (int page = 1; page <= 2; page++) {
            if (isPageEmpty(user, page)) {
                fillPage(user, page);
                return page;
            }
        }
        if (isPageEmpty(user, 0)) {
            fillPage(user, 0);
            return 0;
        }
        return -1;
    }

    /**
     * Newly added godlike abilities (from mod updates) get slotted into free slots on the page that already
     * holds the godlike set, so existing ascended players get them without touching the ability menu.
     */
    public static void addMissingAbilities(ServerPlayer player) {
        if (!(player instanceof ViltrumiteAbilityUser user)) return;
        List<String> equipped = new ArrayList<>();
        int godlikePage = -1;
        for (int i = 0; i < 18; i++) {
            String id = user.getAbilityInSlot(i);
            if (id != null && !id.isEmpty()) equipped.add(id);
            if (GodlikeAbilities.isGodlike(id) && godlikePage < 0) godlikePage = i / 6;
        }
        if (godlikePage < 0) return; // never equipped anything godlike: leave the layout alone
        for (String id : GodlikeAbilities.ALL_IDS) {
            if (equipped.contains(id)) continue;
            int slot = findEmptySlot(user, godlikePage);
            if (slot < 0) slot = findEmptySlot(user, -1);
            if (slot < 0) break;
            user.setAbilityInSlot(slot, id);
            equipped.add(id);
            player.sendSystemMessage(Component.literal("New godlike ability equipped: " + GodlikeAbilities.displayName(id)
                    + " (ability page " + (slot / 6 + 1) + ").").withStyle(ChatFormatting.AQUA));
        }
    }

    private static int findEmptySlot(ViltrumiteAbilityUser user, int page) {
        int start = page < 0 ? 0 : page * 6;
        int end = page < 0 ? 18 : page * 6 + 6;
        for (int i = start; i < end; i++) {
            String id = user.getAbilityInSlot(i);
            if (id == null || id.isEmpty()) return i;
        }
        return -1;
    }

    /** Force-equips the godlike abilities on the given page (used by the command). */
    public static void forceEquip(ServerPlayer player, int page) {
        if (!(player instanceof ViltrumiteAbilityUser user)) return;
        fillPage(user, page);
    }

    private static boolean isPageEmpty(ViltrumiteAbilityUser user, int page) {
        for (int i = 0; i < 6; i++) {
            String id = user.getAbilityInSlot(page * 6 + i);
            if (id != null && !id.isEmpty()) return false;
        }
        return true;
    }

    private static void fillPage(ViltrumiteAbilityUser user, int page) {
        for (int i = 0; i < 6; i++) {
            String id = i < GodlikeAbilities.ALL_IDS.size() ? GodlikeAbilities.ALL_IDS.get(i) : "";
            user.setAbilityInSlot(page * 6 + i, id);
        }
    }
}
