package com.godlikealien.server;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.entity.CosmicOrbEntity;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Server logic for the Cosmic Barrage: charge, launch the swarm, remote detonation. */
public final class BarrageAbility {
    private static final int MAX_LIVE_ORBS = 40;
    /** Presses within this many ticks after launch are ignored instead of detonating the swarm point-blank. */
    private static final int DETONATE_GRACE_TICKS = 15;

    private BarrageAbility() {}

    public static float chargePower(int charge) {
        int min = GodlikeConfig.COMMON.barrageMinChargeTicks.get();
        int max = GodlikeConfig.COMMON.barrageMaxChargeTicks.get();
        if (max <= min) return 1.0f;
        return Mth.clamp((charge - min) / (float) (max - min), 0.0f, 1.0f);
    }

    public static int orbCount(int charge) {
        float power = chargePower(charge);
        int min = GodlikeConfig.COMMON.barrageMinCount.get();
        int max = GodlikeConfig.COMMON.barrageMaxCount.get();
        return Math.max(1, Math.round(Mth.lerp(power, min, max)));
    }

    public static void press(ServerPlayer player, GodlikeState state) {
        if (!GodlikeGate.canUse(player, state)) return;
        pruneOrbs(player, state);
        if (state.orbsAlive) {
            // a press right after launching is almost always a double-tap, not a wish to blow up your own face
            if (player.tickCount - state.barrageLaunchTick >= DETONATE_GRACE_TICKS) {
                detonateAll(player, state);
            }
            return;
        }
        if (state.barrageCharge >= 0 || state.onCooldown(GodlikeAbilities.CD_BARRAGE)) return;
        if (!GodlikeGate.canAct(player)) return;
        state.barrageCharge = 0;
        state.dirty = true;
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RESPAWN_ANCHOR_CHARGE, SoundSource.PLAYERS, 1.5f, 1.2f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CONDUIT_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.6f);
    }

    public static void release(ServerPlayer player, GodlikeState state) {
        if (state.barrageCharge < 0) return;
        if (state.barrageCharge >= GodlikeConfig.COMMON.barrageMinChargeTicks.get()) {
            fire(player, state);
        } else {
            fizzle(player, state);
        }
    }

    public static void tick(ServerPlayer player, GodlikeState state) {
        pruneOrbs(player, state);
        if (state.barrageCharge < 0) return;
        if (!GodlikeGate.canAct(player) || player.isDeadOrDying()) {
            fizzle(player, state);
            return;
        }
        state.barrageCharge++;
        Vec3 v = player.getDeltaMovement();
        player.setDeltaMovement(v.x * 0.6, v.y * 0.8, v.z * 0.6);
        int max = GodlikeConfig.COMMON.barrageMaxChargeTicks.get();
        if (state.barrageCharge % 6 == 0) {
            float t = Mth.clamp(state.barrageCharge / (float) max, 0.0f, 1.0f);
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.2f, 1.0f + t * 1.0f);
        }
        if (state.barrageCharge >= max) {
            fire(player, state);
        }
        state.dirty = true;
    }

    private static void fizzle(ServerPlayer player, GodlikeState state) {
        state.barrageCharge = -1;
        state.dirty = true;
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RESPAWN_ANCHOR_DEPLETE.get(), SoundSource.PLAYERS, 1.2f, 1.6f);
        GodlikeNetwork.sendNear(level, player.position(), 64.0, new FxPacket(FxPacket.LASER_FIZZLE, player.getEyePosition(), player.getLookAngle(), 0, 0));
    }

    public static void fire(ServerPlayer player, GodlikeState state) {
        float power = chargePower(state.barrageCharge);
        int count = orbCount(state.barrageCharge);
        state.barrageCharge = -1;
        state.setCooldown(GodlikeAbilities.CD_BARRAGE, GodlikeConfig.COMMON.barrageCooldownTicks.get());

        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 eye = player.getEyePosition();
        Vec3 u = GodlikeMath.perpendicular(look);
        Vec3 w = look.cross(u).normalize();
        double speed = GodlikeConfig.COMMON.barrageSpeed.get();
        int lifetime = GodlikeConfig.COMMON.barrageLifetimeTicks.get();
        float orbPower = 0.45f + 0.55f * power;

        int room = Math.max(0, MAX_LIVE_ORBS - state.orbIds.size());
        count = Math.min(count, room);
        for (int i = 0; i < count; i++) {
            float angle = (float) (i * Math.PI * 2 / count + (level.random.nextDouble() - 0.5) * 0.4);
            float radius = (i % 2 == 0 ? 0.22f : 0.4f) + level.random.nextFloat() * 0.1f;
            Vec3 lateral = u.scale(Math.cos(angle)).add(w.scale(Math.sin(angle)));
            Vec3 dir = look.add(lateral.scale(radius * 0.9)).normalize();
            Vec3 pos = eye.add(look.scale(0.9)).add(lateral.scale(0.35)).subtract(0, 0.2, 0);
            // never spawn inside a wall / the floor: pull the spawn point back toward the eyes if a block is in the way
            BlockHitResult spawnHit = level.clip(new ClipContext(eye, pos, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (spawnHit.getType() == HitResult.Type.BLOCK) {
                pos = eye.add(spawnHit.getLocation().subtract(eye).scale(0.5));
            }
            Vec3 vel = dir.scale(speed * (0.85 + level.random.nextDouble() * 0.3));
            CosmicOrbEntity orb = CosmicOrbEntity.launch(level, player.getUUID(), pos, vel, orbPower, 0,
                    lifetime + level.random.nextInt(20), angle, radius, speed);
            state.orbIds.add(orb.getId());
        }
        state.orbsAlive = !state.orbIds.isEmpty();
        state.barrageLaunchTick = player.tickCount;

        GodlikeNetwork.sendNear(level, eye, 200.0, new FxPacket(FxPacket.BARRAGE_LAUNCH, eye.add(look.scale(1.2)), look, power, count));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.SHULKER_SHOOT, SoundSource.PLAYERS, 3.0f, 0.7f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WITHER_SHOOT, SoundSource.PLAYERS, 2.5f, 1.3f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 3.0f, 0.8f);
        player.setDeltaMovement(player.getDeltaMovement().subtract(look.scale(0.15 + 0.2 * power)));
        player.hurtMarked = true;
        state.dirty = true;
    }

    public static void detonateAll(ServerPlayer player, GodlikeState state) {
        ServerLevel level = player.serverLevel();
        List<Integer> ids = new ArrayList<>(state.orbIds);
        int n = 0;
        for (int id : ids) {
            Entity e = level.getEntity(id);
            if (e instanceof CosmicOrbEntity orb && orb.getTier() == 0) {
                if (orb.detonate()) {
                    n++;
                    state.orbIds.remove(Integer.valueOf(id));
                }
            }
        }
        pruneOrbs(player, state);
        state.dirty = true;
        if (n > 0) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 2.0f, 1.8f);
        }
    }

    private static void pruneOrbs(ServerPlayer player, GodlikeState state) {
        if (state.orbIds.isEmpty()) {
            if (state.orbsAlive) {
                state.orbsAlive = false;
                state.dirty = true;
            }
            return;
        }
        ServerLevel level = player.serverLevel();
        Iterator<Integer> it = state.orbIds.iterator();
        while (it.hasNext()) {
            Entity e = level.getEntity(it.next());
            if (!(e instanceof CosmicOrbEntity orb) || !orb.isAlive() || orb.getTier() != 0) it.remove();
        }
        boolean alive = !state.orbIds.isEmpty();
        if (alive != state.orbsAlive) {
            state.orbsAlive = alive;
            state.dirty = true;
        }
    }
}
