package com.godlikealien.server;

import com.godlikealien.GodlikeConfig;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/**
 * Chaos Control bookkeeping (server). Every player currently stopping time owns a bubble; inside it
 * <ul>
 *   <li>living entities (except players) have their tick cancelled (see the LivingTickEvent handlers), so they
 *       hang mid-air, mid-animation, and keep whatever momentum they had;</li>
 *   <li>everything else (arrows, fireballs, items, TNT, falling blocks, boats, our orbs) is pinned to the position
 *       it had when time stopped and gets its velocity back when time resumes;</li>
 *   <li>other players are pinned in place and their client zeroes their input.</li>
 * </ul>
 * The freezing player, spectators, other time-stoppers and anything a time-stopper rides are never frozen.
 */
public final class TimeFreeze {
    /** Client-side frozen check, installed by the client so shared entity code can ask without loading client classes. */
    public static Predicate<Entity> CLIENT_FROZEN = e -> false;

    private static final Map<UUID, Freezer> FREEZERS = new ConcurrentHashMap<>();
    private static final Map<Integer, Lock> LOCKS = new HashMap<>();

    private TimeFreeze() {}

    private record Freezer(ServerPlayer player, double radius) {}

    private static final class Lock {
        final ResourceKey<Level> dim;
        final Vec3 pos;
        final Vec3 vel;
        final float yRot, xRot;
        final int fuse;

        Lock(Entity e) {
            this.dim = e.level().dimension();
            this.pos = e.position();
            this.vel = e.getDeltaMovement();
            this.yRot = e.getYRot();
            this.xRot = e.getXRot();
            this.fuse = e instanceof PrimedTnt tnt ? tnt.getFuse() : 0;
        }

        /** Pins the entity. Before the entity ticks the TNT fuse gets one extra tick so the tick's decrement cannot fire it. */
        void apply(Entity e, boolean preTick) {
            if (e instanceof ServerPlayer sp) {
                if (sp.position().distanceToSqr(pos) > 0.09) {
                    sp.teleportTo(pos.x, pos.y, pos.z);
                }
                sp.setDeltaMovement(Vec3.ZERO);
                sp.fallDistance = 0;
                return;
            }
            e.setPos(pos.x, pos.y, pos.z);
            e.setDeltaMovement(Vec3.ZERO);
            e.setYRot(yRot);
            e.setXRot(xRot);
            e.fallDistance = 0;
            if (e instanceof PrimedTnt tnt) tnt.setFuse(preTick ? Math.max(2, fuse + 1) : Math.max(1, fuse));
        }

        void release(Entity e) {
            if (e instanceof ServerPlayer) return;
            e.setDeltaMovement(vel);
            e.hurtMarked = true;
            if (e instanceof PrimedTnt tnt) tnt.setFuse(Math.max(1, fuse));
        }
    }

    public static boolean anyActive() {
        return !FREEZERS.isEmpty();
    }

    public static void start(ServerPlayer player) {
        FREEZERS.put(player.getUUID(), new Freezer(player, GodlikeConfig.COMMON.chaosRadius.get()));
    }

    public static void stop(Player player) {
        FREEZERS.remove(player.getUUID());
    }

    public static void clear() {
        FREEZERS.clear();
        LOCKS.clear();
    }

    public static boolean isFreezer(Entity e) {
        return e instanceof Player && FREEZERS.containsKey(e.getUUID());
    }

    /** Server-side: is this entity currently inside somebody's stopped time? */
    public static boolean isFrozen(Entity e) {
        if (e == null || FREEZERS.isEmpty()) return false;
        if (e.isSpectator() || isFreezer(e)) return false;
        if (e instanceof Player && !GodlikeConfig.COMMON.chaosFreezesPlayers.get()) return false;
        for (Entity passenger : e.getPassengers()) {
            if (isFreezer(passenger)) return false;
        }
        for (Freezer f : FREEZERS.values()) {
            ServerPlayer p = f.player();
            if (p.isRemoved() || p.level() != e.level()) continue;
            if (p.distanceToSqr(e) <= f.radius() * f.radius()) return true;
        }
        return false;
    }

    /**
     * Housekeeping for a living entity whose tick was just cancelled (both sides): hit cooldowns keep running so a
     * frozen mob can be hit again, and a creeper's fuse stops (its swelling happens before the cancelled tick).
     */
    public static void holdLiving(LivingEntity e) {
        if (e.invulnerableTime > 0) e.invulnerableTime--;
        if (e.hurtTime > 0) e.hurtTime--;
        if (e instanceof Creeper creeper && creeper.getSwellDir() > 0) creeper.setSwellDir(-1);
    }

    /** Pins non-living entities and players inside bubbles; called before and after the entities of a level tick. */
    public static void tickLevel(ServerLevel level, boolean preTick) {
        boolean anyHere = false;
        for (Freezer f : FREEZERS.values()) {
            if (!f.player().isRemoved() && f.player().level() == level) {
                anyHere = true;
                break;
            }
        }
        if (!anyHere) {
            releaseAll(level);
            return;
        }
        Set<Integer> seen = new HashSet<>();
        for (Entity e : level.getAllEntities()) {
            if (e instanceof LivingEntity && !(e instanceof Player)) continue; // tick-cancelled instead
            if (e.isRemoved() || !isFrozen(e)) continue;
            seen.add(e.getId());
            Lock lock = LOCKS.get(e.getId());
            if (lock == null) {
                lock = new Lock(e);
                LOCKS.put(e.getId(), lock);
            }
            lock.apply(e, preTick);
        }
        Iterator<Map.Entry<Integer, Lock>> it = LOCKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Lock> en = it.next();
            if (en.getValue().dim != level.dimension()) continue;
            if (seen.contains(en.getKey())) continue;
            Entity e = level.getEntity(en.getKey());
            if (e != null) en.getValue().release(e);
            it.remove();
        }
    }

    private static void releaseAll(ServerLevel level) {
        if (LOCKS.isEmpty()) return;
        Iterator<Map.Entry<Integer, Lock>> it = LOCKS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Lock> en = it.next();
            if (en.getValue().dim != level.dimension()) continue;
            Entity e = level.getEntity(en.getKey());
            if (e != null) en.getValue().release(e);
            it.remove();
        }
    }
}
