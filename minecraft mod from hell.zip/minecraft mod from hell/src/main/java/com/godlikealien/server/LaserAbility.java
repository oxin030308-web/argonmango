package com.godlikealien.server;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.entity.UnstableCoreEntity;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.util.BlockBreaker;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Server logic for the Super Laser: charge, fire the beam, plant the unstable core. */
public final class LaserAbility {
    private LaserAbility() {}

    public static void press(ServerPlayer player, GodlikeState state) {
        if (state.laserCharge >= 0) return;
        if (state.onCooldown(GodlikeAbilities.CD_LASER)) return;
        if (!GodlikeGate.canUse(player, state) || !GodlikeGate.canAct(player)) return;
        state.laserCharge = 0;
        state.dirty = true;
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RESPAWN_ANCHOR_CHARGE, SoundSource.PLAYERS, 2.0f, 0.55f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.5f, 1.4f);
    }

    public static void release(ServerPlayer player, GodlikeState state) {
        if (state.laserCharge < 0) return;
        int min = GodlikeConfig.COMMON.laserMinChargeTicks.get();
        if (state.laserCharge >= min) {
            fire(player, state);
        } else {
            fizzle(player, state);
        }
    }

    public static void tick(ServerPlayer player, GodlikeState state) {
        if (state.laserCharge < 0) return;
        if (!GodlikeGate.canAct(player) || player.isDeadOrDying()) {
            fizzle(player, state);
            return;
        }
        state.laserCharge++;
        // gathering energy roots the player
        Vec3 v = player.getDeltaMovement();
        player.setDeltaMovement(v.x * 0.5, v.y * 0.7, v.z * 0.5);

        int max = GodlikeConfig.COMMON.laserMaxChargeTicks.get();
        if (state.laserCharge % 8 == 0) {
            float t = Mth.clamp(state.laserCharge / (float) max, 0.0f, 1.0f);
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.AMETHYST_BLOCK_CHIME,
                    SoundSource.PLAYERS, 1.5f + t, 0.5f + t * 1.2f);
        }
        if (state.laserCharge == GodlikeConfig.COMMON.laserMinChargeTicks.get()) {
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 2.0f, 1.2f);
        }
        if (state.laserCharge >= max) {
            fire(player, state);
        }
        state.dirty = true;
    }

    private static void fizzle(ServerPlayer player, GodlikeState state) {
        state.laserCharge = -1;
        state.dirty = true;
        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.RESPAWN_ANCHOR_DEPLETE.get(), SoundSource.PLAYERS, 1.5f, 1.5f);
        GodlikeNetwork.sendNear(level, player.position(), 64.0, new FxPacket(FxPacket.LASER_FIZZLE, player.getEyePosition(), player.getLookAngle(), 0, 0));
    }

    public static float chargePower(int charge) {
        int min = GodlikeConfig.COMMON.laserMinChargeTicks.get();
        int max = GodlikeConfig.COMMON.laserMaxChargeTicks.get();
        if (max <= min) return 1.0f;
        return Mth.clamp((charge - min) / (float) (max - min), 0.0f, 1.0f);
    }

    public static void fire(ServerPlayer player, GodlikeState state) {
        float power = chargePower(state.laserCharge);
        state.laserCharge = -1;
        state.setCooldown(GodlikeAbilities.CD_LASER, GodlikeConfig.COMMON.laserCooldownTicks.get());

        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 origin = player.getEyePosition().add(look.scale(0.6));
        double range = GodlikeConfig.COMMON.laserRange.get();
        Vec3 farEnd = origin.add(look.scale(range));

        // impact = first solid block the beam meets (or max range). Behind it the beam drills a limited hole;
        // the unstable core always stays at the impact point so the explosion happens where you aimed.
        boolean vaporize = GodlikeConfig.COMMON.laserVaporizesBlocks.get() && BlockBreaker.griefingAllowed(level);
        BlockHitResult hit = level.clip(new ClipContext(origin, farEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 impact = hit.getType() == HitResult.Type.BLOCK ? hit.getLocation() : farEnd;
        Vec3 end = impact;
        if (hit.getType() == HitResult.Type.BLOCK && vaporize) {
            double depth = GodlikeConfig.COMMON.laserPierceDepth.get() * (0.4 + 0.6 * power);
            end = marchThroughBlocks(level, impact, look, depth);
        }

        double beamRadius = 0.9 + 1.1 * power;
        double blockRadius = 0.7 + 1.3 * power;
        float damage = (float) Mth.lerp(power, GodlikeConfig.COMMON.laserMinDamage.get(), GodlikeConfig.COMMON.laserMaxDamage.get());

        // drill the hole behind the impact (queued: carved over a few ticks, front to back)
        if (vaporize && end.distanceToSqr(impact) > 0.25) {
            BlockBreaker.tunnel(level, impact, end, blockRadius, 12000);
        }

        // annihilate entities along the beam
        AABB box = new AABB(origin, end).inflate(beamRadius + 2.0);
        for (Entity e : level.getEntities(player, box, ent -> ent.isAlive() && ent != player)) {
            double half = Math.max(0.5, e.getBbWidth() * 0.5);
            Vec3 c = e.getBoundingBox().getCenter();
            if (GodlikeMath.segmentDistanceSqr(c, origin, end) > (beamRadius + half) * (beamRadius + half)) continue;
            if (e instanceof LivingEntity living) {
                living.hurt(level.damageSources().indirectMagic(player, player), damage);
                living.setSecondsOnFire(6);
                living.invulnerableTime = 0;
            } else if (!(e instanceof net.minecraft.world.entity.player.Player)) {
                e.hurt(level.damageSources().indirectMagic(player, player), damage);
            }
            Vec3 shove = look.scale(1.5 + power).add(0, 0.5, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(shove));
            e.hurtMarked = true;
        }

        // recoil for drama
        player.setDeltaMovement(player.getDeltaMovement().subtract(look.scale(0.35 + 0.4 * power)));
        player.hurtMarked = true;

        // plant the unstable core just before the impact point
        Vec3 corePos = impact.subtract(look.scale(0.8));
        UnstableCoreEntity.plant(level, corePos, player.getUUID(), power);

        // impact crater
        if (vaporize) {
            BlockBreaker.sphere(level, impact, 2.5 + 2.5 * power, 6000);
        }

        // effects & sounds
        GodlikeNetwork.sendNear(level, origin, 320.0, new FxPacket(FxPacket.BEAM, origin, end, power, 0));
        GodlikeNetwork.sendNear(level, impact, 320.0, new FxPacket(FxPacket.LASER_IMPACT, impact, look, power, 0));
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 6.0f, 0.55f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENDER_DRAGON_SHOOT, SoundSource.PLAYERS, 4.0f, 0.7f);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 5.0f, 1.3f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 6.0f, 0.7f);
        level.playSound(null, impact.x, impact.y, impact.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 6.0f, 0.8f);
        state.dirty = true;
    }

    /** Steps along the beam; stops at the first block that cannot be vaporized (or after the given distance). */
    private static Vec3 marchThroughBlocks(ServerLevel level, Vec3 origin, Vec3 dir, double range) {
        double step = 0.5;
        net.minecraft.core.BlockPos.MutableBlockPos pos = new net.minecraft.core.BlockPos.MutableBlockPos();
        for (double t = step; t <= range; t += step) {
            Vec3 p = origin.add(dir.scale(t));
            pos.set(Mth.floor(p.x), Mth.floor(p.y), Mth.floor(p.z));
            if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) {
                return p;
            }
            var stateAt = level.getBlockState(pos);
            if (!stateAt.isAir() && !BlockBreaker.canBreak(stateAt) && !stateAt.getCollisionShape(level, pos).isEmpty()) {
                return origin.add(dir.scale(Math.max(0, t - step)));
            }
        }
        return origin.add(dir.scale(range));
    }
}
