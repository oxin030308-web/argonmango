package com.godlikealien.server;

import com.godlikealien.GodlikeAlien;
import com.godlikealien.network.AbilityActionPacket;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.network.StateSyncPacket;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.state.GodlikeStateManager;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** All server-side event handling for the godlike abilities. */
@Mod.EventBusSubscriber(modid = GodlikeAlien.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class GodlikeServerEvents {
    private GodlikeServerEvents() {}

    // ------------------------------------------------------------ packets

    public static void handleAction(ServerPlayer player, AbilityActionPacket msg) {
        GodlikeState state = GodlikeStateManager.get(player);
        switch (msg.ability) {
            case AbilityActionPacket.ABILITY_LASER -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS) LaserAbility.press(player, state);
                else LaserAbility.release(player, state);
            }
            case AbilityActionPacket.ABILITY_DASH -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS) DashAbility.execute(player, state, msg.vec, msg.extra);
            }
            case AbilityActionPacket.ABILITY_PUNCH -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS) PunchAbility.press(player, state, msg.extra != 0);
            }
            case AbilityActionPacket.ABILITY_BARRAGE -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS) BarrageAbility.press(player, state);
                else BarrageAbility.release(player, state);
            }
            case AbilityActionPacket.ABILITY_CHAOS -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS) ChaosControlAbility.press(player, state);
            }
            case AbilityActionPacket.ABILITY_RESISTANCE -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS && GodlikeGate.canUse(player, state)) {
                    state.resistance = !state.resistance;
                    state.dirty = true;
                    GodlikeStateManager.savePersisted(player, state);
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                            state.resistance ? "Godlike Resistance: ON" : "Godlike Resistance: OFF"), true);
                    player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                            state.resistance ? SoundEvents.BEACON_ACTIVATE : SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.5f);
                }
            }
            case AbilityActionPacket.ABILITY_SONIC -> {
                if (msg.action == AbilityActionPacket.ACTION_PRESS && GodlikeGate.canUse(player, state)) {
                    state.sonicFlight = !state.sonicFlight;
                    state.dirty = true;
                    GodlikeStateManager.savePersisted(player, state);
                    player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                            state.sonicFlight ? "Sonic Flight: ON" : "Sonic Flight: OFF"), true);
                    player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                            state.sonicFlight ? SoundEvents.BEACON_POWER_SELECT : SoundEvents.BEACON_DEACTIVATE, SoundSource.PLAYERS, 1.0f, 1.2f);
                }
            }
            default -> {}
        }
        if (state.dirty) sync(player, state);
    }

    public static void sync(ServerPlayer player, GodlikeState state) {
        state.dirty = false;
        GodlikeNetwork.sendToTracking(player, StateSyncPacket.of(player.getId(), state));
    }

    // ------------------------------------------------------------ ticking

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.side != LogicalSide.SERVER || !(event.player instanceof ServerPlayer player)) return;
        GodlikeState state = GodlikeStateManager.get(player);

        if (event.phase == TickEvent.Phase.START) {
            // ViltrumiteFlight rewrites noPhysics at the head of every tick; keep the dash window authoritative
            if (state.dashTicks > 0) player.noPhysics = true;
            boolean usable = GodlikeGate.canUse(player, state);
            Passives.tickSonicFlight(player, usable && state.sonicFlight);
            Passives.tickResistance(player, usable && state.resistance);
            return;
        }

        boolean wasCharging = state.laserCharge >= 0;
        boolean wasDashing = state.dashTicks > 0;
        boolean smash = com.godlikealien.GodlikeConfig.COMMON.dashSmashesBlocks.get()
                && com.godlikealien.util.BlockBreaker.griefingAllowed(player.serverLevel());
        if (smash != state.smashAllowed) {
            state.smashAllowed = smash;
            state.dirty = true;
        }
        state.tickCooldowns();
        LaserAbility.tick(player, state);
        PunchAbility.tick(player, state);
        DashAbility.tick(player, state);
        BarrageAbility.tick(player, state);
        ChaosControlAbility.tick(player, state);

        state.syncTimer++;
        boolean periodic = ((state.laserCharge >= 0 || state.barrageCharge >= 0) && state.syncTimer % 4 == 0)
                || ((wasCharging && state.laserCharge < 0) || (wasDashing && state.dashTicks <= 0));
        if (state.dirty || periodic) {
            sync(player, state);
        }
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.side != LogicalSide.SERVER || !(event.level instanceof ServerLevel level)) return;
        if (event.phase == TickEvent.Phase.START) {
            if (TimeFreeze.anyActive()) TimeFreeze.tickLevel(level, true);
            return;
        }
        ExplosionManager.tick(level);
        TimeFreeze.tickLevel(level, false);
    }

    // ------------------------------------------------------------ chaos control (frozen entities)

    /** Frozen mobs skip their whole tick (no AI, no movement, no aging). Dying mobs still fall over and vanish. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide || entity instanceof Player) return;
        if (!TimeFreeze.anyActive() || entity.isDeadOrDying() || !TimeFreeze.isFrozen(entity)) return;
        event.setCanceled(true);
        TimeFreeze.holdLiving(entity);
    }

    private static boolean frozenPlayer(Player player) {
        return player != null && !player.level().isClientSide && TimeFreeze.anyActive() && TimeFreeze.isFrozen(player);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onAttackEntity(AttackEntityEvent event) {
        if (frozenPlayer(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        if (frozenPlayer(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onRightClickItem(PlayerInteractEvent.RightClickItem event) {
        if (frozenPlayer(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
        if (frozenPlayer(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock event) {
        if (frozenPlayer(event.getEntity())) event.setCanceled(true);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (frozenPlayer(event.getPlayer())) event.setCanceled(true);
    }

    // ------------------------------------------------------------ godlike resistance

    private static boolean resists(Player player, DamageSource source) {
        if (player.level().isClientSide) return false;
        GodlikeState state = GodlikeStateManager.getIfPresent(player);
        if (state == null || !state.resistance) return false;
        if (!GodlikeGate.canUse(player, state)) return false;
        return !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY);
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (!resists(player, event.getSource())) return;
        event.setCanceled(true);
        if (player.tickCount % 3 == 0) {
            Vec3 pos = player.position().add(0, player.getBbHeight() * 0.5, 0);
            GodlikeNetwork.sendNear(player.serverLevel(), pos, 48.0, new FxPacket(FxPacket.SHIELD, pos, Vec3.ZERO, event.getAmount(), 0));
            player.serverLevel().playSound(null, pos.x, pos.y, pos.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 0.5f);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (resists(player, event.getSource())) {
            event.setCanceled(true);
        }
    }

    // ------------------------------------------------------------ lifecycle

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        GodlikeStateManager.remove(player);
        GodlikeState state = GodlikeStateManager.get(player);
        if (state.godlike) {
            Ascension.addMissingAbilities(player);
        }
        sync(player, state);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        TimeFreeze.stop(player);
        GodlikeState state = GodlikeStateManager.getIfPresent(player);
        if (state != null) GodlikeStateManager.savePersisted(player, state);
        GodlikeStateManager.remove(player);
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        TimeFreeze.stop(event.getOriginal());
        GodlikeState old = GodlikeStateManager.getIfPresent(event.getOriginal());
        if (old != null) GodlikeStateManager.savePersisted(event.getOriginal(), old);
        GodlikeStateManager.copyPersisted(event.getOriginal(), player);
        GodlikeStateManager.remove(player);
        GodlikeState state = GodlikeStateManager.get(player);
        state.dirty = true;
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        sync(player, GodlikeStateManager.get(player));
    }

    @SubscribeEvent
    public static void onChangeDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        sync(player, GodlikeStateManager.get(player));
    }

    @SubscribeEvent
    public static void onStartTracking(PlayerEvent.StartTracking event) {
        if (!(event.getTarget() instanceof ServerPlayer target)) return;
        if (!(event.getEntity() instanceof ServerPlayer watcher)) return;
        GodlikeState state = GodlikeStateManager.get(target);
        GodlikeNetwork.sendToPlayer(watcher, StateSyncPacket.of(target.getId(), state));
    }

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        GodlikeCommands.register(event.getDispatcher());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        GodlikeStateManager.clearAll();
        ExplosionManager.clear();
        TimeFreeze.clear();
    }
}
