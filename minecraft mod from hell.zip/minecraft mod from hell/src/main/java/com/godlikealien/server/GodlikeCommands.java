package com.godlikealien.server;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.state.GodlikeStateManager;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collection;
import java.util.List;

public final class GodlikeCommands {
    private GodlikeCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("godlikealien")
                .then(Commands.literal("ascend")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> ascend(ctx, List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> ascend(ctx, EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("descend")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> descend(ctx, List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> descend(ctx, EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("equip")
                        .executes(ctx -> equip(ctx, -1))
                        .then(Commands.argument("page", IntegerArgumentType.integer(1, 3))
                                .executes(ctx -> equip(ctx, IntegerArgumentType.getInteger(ctx, "page") - 1))))
                .then(Commands.literal("reset")
                        .requires(src -> src.hasPermission(2))
                        .executes(ctx -> reset(ctx, List.of(ctx.getSource().getPlayerOrException())))
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(ctx -> reset(ctx, EntityArgument.getPlayers(ctx, "targets")))))
                .then(Commands.literal("toggle")
                        .then(Commands.literal("resistance").executes(ctx -> toggle(ctx, true)))
                        .then(Commands.literal("sonic").executes(ctx -> toggle(ctx, false))))
                .then(Commands.literal("status").executes(GodlikeCommands::status)));
    }

    private static int ascend(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        for (ServerPlayer p : targets) {
            Ascension.ascend(p, true);
        }
        ctx.getSource().sendSuccess(() -> Component.literal("Ascended " + targets.size() + " player(s) as Godlike Alien.").withStyle(ChatFormatting.AQUA), true);
        return targets.size();
    }

    private static int descend(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        for (ServerPlayer p : targets) {
            Ascension.descend(p);
        }
        ctx.getSource().sendSuccess(() -> Component.literal("Removed godlike power from " + targets.size() + " player(s).").withStyle(ChatFormatting.GRAY), true);
        return targets.size();
    }

    private static int equip(CommandContext<CommandSourceStack> ctx, int page) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        int used;
        if (page < 0) {
            used = Ascension.equipAbilities(p);
            if (used < 0) {
                Ascension.forceEquip(p, 2);
                used = 2;
            }
        } else {
            Ascension.forceEquip(p, page);
            used = page;
        }
        final int shown = used + 1;
        ctx.getSource().sendSuccess(() -> Component.literal("Godlike abilities equipped on ability page " + shown + " (ALT swaps pages).").withStyle(ChatFormatting.AQUA), false);
        return 1;
    }

    private static int reset(CommandContext<CommandSourceStack> ctx, Collection<ServerPlayer> targets) {
        for (ServerPlayer p : targets) {
            GodlikeState st = GodlikeStateManager.get(p);
            st.resetCooldowns();
            st.laserCharge = -1;
            st.barrageCharge = -1;
            st.punchPending = false;
            ChaosControlAbility.stop(p, st);
            st.resetCooldowns();
            GodlikeServerEvents.sync(p, st);
        }
        ctx.getSource().sendSuccess(() -> Component.literal("Godlike cooldowns reset.").withStyle(ChatFormatting.AQUA), true);
        return targets.size();
    }

    private static int toggle(CommandContext<CommandSourceStack> ctx, boolean resistance) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        GodlikeState st = GodlikeStateManager.get(p);
        boolean now;
        if (resistance) {
            st.resistance = !st.resistance;
            now = st.resistance;
        } else {
            st.sonicFlight = !st.sonicFlight;
            now = st.sonicFlight;
        }
        st.dirty = true;
        GodlikeStateManager.savePersisted(p, st);
        GodlikeServerEvents.sync(p, st);
        String name = resistance ? "Godlike Resistance" : "Sonic Flight";
        ctx.getSource().sendSuccess(() -> Component.literal(name + (now ? " enabled." : " disabled.")).withStyle(now ? ChatFormatting.AQUA : ChatFormatting.GRAY), false);
        return 1;
    }

    private static int status(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        GodlikeState st = GodlikeStateManager.get(p);
        ctx.getSource().sendSuccess(() -> Component.literal("Godlike Alien: " + (st.godlike ? "ASCENDED" : "not ascended")
                + " | Resistance: " + (st.resistance ? "on" : "off")
                + " | Sonic Flight: " + (st.sonicFlight ? "on" : "off")
                + " | Cooldowns: laser " + st.cooldown[GodlikeAbilities.CD_LASER] / 20 + "s, dash "
                + st.cooldown[GodlikeAbilities.CD_DASH] / 20 + "s, punch " + st.cooldown[GodlikeAbilities.CD_PUNCH] / 20 + "s, barrage "
                + st.cooldown[GodlikeAbilities.CD_BARRAGE] / 20 + "s, chaos " + st.cooldown[GodlikeAbilities.CD_CHAOS] / 20 + "s"
                + (st.timeStopTicks > 0 ? " | TIME FROZEN " + st.timeStopTicks / 20 + "s" : ""))
                .withStyle(ChatFormatting.AQUA), false);
        return 1;
    }
}
