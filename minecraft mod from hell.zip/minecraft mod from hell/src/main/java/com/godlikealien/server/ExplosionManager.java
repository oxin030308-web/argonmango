package com.godlikealien.server;

import com.godlikealien.GodlikeAlien;
import com.godlikealien.state.GodlikeStateManager;
import com.godlikealien.util.BlockBreaker;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Staged block destruction so godlike abilities never freeze the server.
 * <ul>
 *   <li><b>Block jobs</b>: ordered position lists (laser tunnels, punch cones, dash tunnels) vaporized a
 *       few thousand blocks per tick, nearest first.</li>
 *   <li><b>Waves</b>: the ginormous explosion - an expanding sphere, one shell per tick, that vaporizes
 *       blocks and hits entities the moment the front reaches them.</li>
 * </ul>
 */
public final class ExplosionManager {
    /** Real block removals per tick (air is skipped cheaply). Each removal costs lighting + neighbour updates. */
    private static final int WAVE_BUDGET_PER_TICK = 700;
    private static final int JOB_BUDGET_PER_TICK = 900;
    /** Upper bound on positions scanned per tick so huge air spheres cannot stall a tick either. */
    private static final int SCAN_CAP_PER_TICK = 24000;
    private static final Map<ResourceKey<Level>, List<Wave>> WAVES = new ConcurrentHashMap<>();
    private static final Map<ResourceKey<Level>, Deque<Job>> JOBS = new ConcurrentHashMap<>();

    private ExplosionManager() {}

    // ------------------------------------------------------------ block jobs

    public static void queueBlocks(ServerLevel level, LongArrayList positions) {
        if (positions == null || positions.isEmpty()) return;
        JOBS.computeIfAbsent(level.dimension(), k -> new ArrayDeque<>()).add(new Job(level, positions));
    }

    private static void tickJobs(ServerLevel level) {
        Deque<Job> jobs = JOBS.get(level.dimension());
        if (jobs == null || jobs.isEmpty()) return;
        int budget = JOB_BUDGET_PER_TICK;
        int scanned = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        while (budget > 0 && scanned < SCAN_CAP_PER_TICK && !jobs.isEmpty()) {
            Job job = jobs.peekFirst();
            if (job.level != level) {
                jobs.pollFirst();
                continue;
            }
            while (budget > 0 && scanned < SCAN_CAP_PER_TICK && job.index < job.positions.size()) {
                long key = job.positions.getLong(job.index++);
                pos.set(BlockPos.getX(key), BlockPos.getY(key), BlockPos.getZ(key));
                if (BlockBreaker.vaporize(level, pos)) budget--;
                scanned++;
            }
            if (job.index >= job.positions.size()) jobs.pollFirst();
        }
    }

    private static final class Job {
        final ServerLevel level;
        final LongArrayList positions;
        int index;

        Job(ServerLevel level, LongArrayList positions) {
            this.level = level;
            this.positions = positions;
        }
    }

    // ------------------------------------------------------------ waves

    public static void start(ServerLevel level, Vec3 center, int radius, UUID owner, float damage, boolean breakBlocks) {
        Wave wave = new Wave(level, center, Math.max(1, radius), owner, damage, breakBlocks && BlockBreaker.griefingAllowed(level));
        WAVES.computeIfAbsent(level.dimension(), k -> new ArrayList<>()).add(wave);
        GodlikeAlien.LOGGER.debug("[Godlike Alien] explosion wave started at {} radius {}", center, radius);
    }

    public static void tick(ServerLevel level) {
        tickJobs(level);
        List<Wave> waves = WAVES.get(level.dimension());
        if (waves == null || waves.isEmpty()) return;
        Iterator<Wave> it = waves.iterator();
        while (it.hasNext()) {
            Wave w = it.next();
            if (w.level != level || w.tick()) {
                it.remove();
            }
        }
    }

    public static void clear() {
        WAVES.clear();
        JOBS.clear();
    }

    private static final class Wave {
        final ServerLevel level;
        final Vec3 center;
        final int maxRadius;
        final UUID owner;
        final float damage;
        final boolean breakBlocks;
        int radius = 0;
        int frontRadius = 0;
        final Deque<Long> queue = new ArrayDeque<>();
        final Set<Integer> hitEntities = new HashSet<>();
        final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        Wave(ServerLevel level, Vec3 center, int maxRadius, UUID owner, float damage, boolean breakBlocks) {
            this.level = level;
            this.center = center;
            this.maxRadius = maxRadius;
            this.owner = owner;
            this.damage = damage;
            this.breakBlocks = breakBlocks;
        }

        /**
         * @return true when finished. Entities are hit as the (fast) front passes them; blocks dissolve behind the
         * front with a per-tick budget so the server keeps ticking even for a 32 block crater.
         */
        boolean tick() {
            // the damaging front races outward: several shells per tick until it has covered the whole radius
            for (int i = 0; i < 4 && frontRadius < maxRadius; i++) {
                frontRadius++;
                hitEntitiesInShell(frontRadius);
            }
            if (queue.isEmpty()) {
                if (radius >= maxRadius) return true;
                radius++;
                if (breakBlocks) fillShell(radius);
            }
            int budget = WAVE_BUDGET_PER_TICK;
            int scanned = 0;
            while (budget > 0 && scanned < SCAN_CAP_PER_TICK && !queue.isEmpty()) {
                long key = queue.pollFirst();
                pos.set(BlockPos.getX(key), BlockPos.getY(key), BlockPos.getZ(key));
                if (BlockBreaker.vaporize(level, pos)) budget--;
                scanned++;
            }
            return false;
        }

        private void fillShell(int r) {
            int cx = Mth.floor(center.x), cy = Mth.floor(center.y), cz = Mth.floor(center.z);
            int minY = level.getMinBuildHeight(), maxY = level.getMaxBuildHeight() - 1;
            int r2 = r * r;
            int inner = (r - 1) * (r - 1);
            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    int d2 = x * x + z * z;
                    if (d2 > r2) continue;
                    int yMax = Mth.floor(Math.sqrt(r2 - d2));
                    int yMinExcl = inner - d2 >= 0 ? Mth.floor(Math.sqrt(inner - d2)) : -1;
                    for (int y = yMinExcl + 1; y <= yMax; y++) {
                        int wy = cy + y;
                        if (wy >= minY && wy <= maxY) queue.add(BlockPos.asLong(cx + x, wy, cz + z));
                        if (y != 0) {
                            int wy2 = cy - y;
                            if (wy2 >= minY && wy2 <= maxY) queue.add(BlockPos.asLong(cx + x, wy2, cz + z));
                        }
                    }
                }
            }
        }

        private void hitEntitiesInShell(int shellRadius) {
            double r = shellRadius + 0.5;
            AABB box = new AABB(center.x - r, center.y - r, center.z - r, center.x + r, center.y + r, center.z + r);
            Entity ownerEntity = owner == null ? null : level.getEntity(owner);
            for (Entity e : level.getEntities((Entity) null, box, ent -> ent.isAlive() && !(ent instanceof com.godlikealien.entity.UnstableCoreEntity))) {
                if (hitEntities.contains(e.getId())) continue;
                double dist = e.position().distanceTo(center);
                if (dist > r) continue;
                hitEntities.add(e.getId());
                if (owner != null && owner.equals(e.getUUID())) continue; // the godlike alien is never hurt by its own core
                Vec3 away = e.position().subtract(center);
                if (away.lengthSqr() < 1.0E-4) away = new Vec3(0, 1, 0);
                away = away.normalize();
                double falloff = 1.0 - Mth.clamp(dist / (maxRadius + 4.0), 0.0, 0.85);
                if (e instanceof LivingEntity living) {
                    DamageSource source = ownerEntity != null
                            ? level.damageSources().explosion(ownerEntity, ownerEntity)
                            : level.damageSources().explosion(null, null);
                    living.hurt(source, (float) (damage * falloff));
                    living.setSecondsOnFire(4);
                }
                Vec3 launch = away.scale(3.5 * falloff).add(0, 1.4 * falloff + 0.4, 0);
                e.setDeltaMovement(e.getDeltaMovement().add(launch));
                e.hurtMarked = true;
                if (e instanceof ServerPlayer sp) {
                    sp.connection.send(new net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket(sp));
                }
                if (e instanceof Player p) {
                    var st = GodlikeStateManager.getIfPresent(p);
                    if (st != null) st.dirty = true;
                }
            }
        }
    }
}
