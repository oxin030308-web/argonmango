package com.godlikealien.server;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;

/** Chaos Control: stop time in a bubble around the player. */
public final class ChaosControlAbility {
    private ChaosControlAbility() {}

    public static void press(ServerPlayer player, GodlikeState state) {
        if (!GodlikeGate.canUse(player, state)) return;
        if (state.timeStopTicks > 0) {
            stop(player, state);
            return;
        }
        if (state.onCooldown(GodlikeAbilities.CD_CHAOS)) return;
        state.timeStopTicks = GodlikeConfig.COMMON.chaosDurationTicks.get();
        state.dirty = true;
        TimeFreeze.start(player);

        ServerLevel level = player.serverLevel();
        Vec3 pos = player.position();
        float radius = GodlikeConfig.COMMON.chaosRadius.get().floatValue();
        GodlikeNetwork.sendNear(level, pos, radius * 2.5, new FxPacket(FxPacket.CHAOS_START, pos, Vec3.ZERO, radius, 0));
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 3.0f, 1.8f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 2.5f, 1.6f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BELL_RESONATE, SoundSource.PLAYERS, 3.0f, 0.5f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.ENDER_EYE_DEATH, SoundSource.PLAYERS, 2.0f, 0.6f);
    }

    public static void tick(ServerPlayer player, GodlikeState state) {
        if (state.timeStopTicks <= 0) return;
        if (player.isDeadOrDying()) {
            stop(player, state);
            return;
        }
        state.timeStopTicks--;
        if (state.timeStopTicks % 20 == 0 && state.timeStopTicks > 0) {
            boolean tick = (state.timeStopTicks / 20) % 2 == 0;
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(),
                    tick ? SoundEvents.STONE_BUTTON_CLICK_ON : SoundEvents.STONE_BUTTON_CLICK_OFF, SoundSource.PLAYERS, 1.6f, 0.7f);
        }
        if (state.timeStopTicks % 4 == 0) state.dirty = true;
        if (state.timeStopTicks <= 0) {
            stop(player, state);
        }
    }

    public static void stop(ServerPlayer player, GodlikeState state) {
        boolean wasActive = state.timeStopTicks > 0 || TimeFreeze.isFreezer(player);
        state.timeStopTicks = 0;
        TimeFreeze.stop(player);
        if (!wasActive) return;
        state.setCooldown(GodlikeAbilities.CD_CHAOS, GodlikeConfig.COMMON.chaosCooldownTicks.get());
        state.dirty = true;

        ServerLevel level = player.serverLevel();
        Vec3 pos = player.position();
        float radius = GodlikeConfig.COMMON.chaosRadius.get().floatValue();
        GodlikeNetwork.sendNear(level, pos, radius * 2.5, new FxPacket(FxPacket.CHAOS_END, pos, Vec3.ZERO, radius, 0));
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 2.0f, 1.4f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.LIGHTNING_BOLT_IMPACT, SoundSource.PLAYERS, 2.0f, 1.5f);
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BELL_BLOCK, SoundSource.PLAYERS, 2.0f, 0.6f);
    }
}
