package com.godlikealien.server;

import com.baranhan123.viltrumitecore.util.ViltrumiteCorePlayer;
import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.util.BlockBreaker;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * The Godlike Punch rides on ViltrumiteCore's punch animation (punch ticks 20 -> 0, impact at 15) and adds
 * a lethal hit plus a huge shockwave on top of the core's own punch impact.
 */
public final class PunchAbility {
    /** The core's punch impact happens when its punch ticks hit this value. */
    private static final int CORE_IMPACT_TICK = 15;

    private PunchAbility() {}

    public static void press(ServerPlayer player, GodlikeState state, boolean leftArm) {
        if (state.onCooldown(GodlikeAbilities.CD_PUNCH) || state.punchPending) return;
        if (!GodlikeGate.canUse(player, state) || !GodlikeGate.canAct(player)) return;
        if (!(player instanceof ViltrumiteCorePlayer core)) return;
        if (core.getPunchTicks() > 0) return;

        core.setLeftArmPunch(leftArm);
        core.setPunchTicks(20);
        state.punchPending = true;
        state.punchFailsafe = 25;
        state.setCooldown(GodlikeAbilities.CD_PUNCH, GodlikeConfig.COMMON.punchCooldownTicks.get());
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 2.0f, 0.5f);
    }

    public static void tick(ServerPlayer player, GodlikeState state) {
        if (!state.punchPending) return;
        if (!(player instanceof ViltrumiteCorePlayer core)) {
            state.punchPending = false;
            return;
        }
        int ticks = core.getPunchTicks();
        if (ticks == CORE_IMPACT_TICK) {
            state.punchPending = false;
            impact(player);
            return;
        }
        if (ticks <= 0 || --state.punchFailsafe <= 0) {
            // animation was interrupted; still deliver the punch so the input never feels eaten
            state.punchPending = false;
            impact(player);
        }
    }

    public static void impact(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 dir = player.getLookAngle().normalize();
        Vec3 origin = player.getEyePosition();
        Vec3 fist = origin.add(dir.scale(1.6)).subtract(0, 0.3, 0);
        double reach = GodlikeConfig.COMMON.punchReach.get();
        double waveRadius = GodlikeConfig.COMMON.punchShockwaveRadius.get();
        float waveDamage = GodlikeConfig.COMMON.punchShockwaveDamage.get().floatValue();

        // find the primary target: first, an exact ray hit on a hitbox in front of the fist ...
        LivingEntity primary = null;
        AABB reachBox = new AABB(origin, origin.add(dir.scale(reach))).inflate(2.5);
        EntityHitResult ray = ProjectileUtil.getEntityHitResult(level, player, origin, origin.add(dir.scale(reach)), reachBox,
                ent -> ent.isAlive() && ent != player && ent instanceof LivingEntity, 0.6f);
        if (ray != null && ray.getEntity() instanceof LivingEntity hitEntity) {
            primary = hitEntity;
        }
        // ... otherwise the closest living thing roughly along the look direction
        if (primary == null) {
            double bestScore = Double.MAX_VALUE;
            for (Entity e : level.getEntities(player, reachBox, ent -> ent.isAlive() && ent != player && ent instanceof LivingEntity)) {
                Vec3 c = e.getBoundingBox().getCenter();
                Vec3 to = c.subtract(origin);
                double dist = to.length();
                if (dist > reach + e.getBbWidth()) continue;
                double along = to.dot(dir);
                if (along < 0) continue;
                double off = Math.sqrt(GodlikeMath.rayDistanceSqr(c.x, c.y, c.z, origin, dir));
                if (off > 2.0 + e.getBbWidth() * 0.6) continue;
                double score = dist + off * 2.0;
                if (score < bestScore) {
                    bestScore = score;
                    primary = (LivingEntity) e;
                }
            }
        }

        if (primary != null) {
            obliterate(player, primary);
            primary.setDeltaMovement(primary.getDeltaMovement().add(dir.scale(2.5)).add(0, 0.6, 0));
            primary.hurtMarked = true;
            level.playSound(null, primary.getX(), primary.getY(), primary.getZ(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.PLAYERS, 3.0f, 0.5f);
        }

        // shockwave: launch and damage everything around the impact point
        Vec3 waveCenter = fist;
        AABB waveBox = new AABB(waveCenter, waveCenter).inflate(waveRadius);
        for (Entity e : level.getEntities(player, waveBox, ent -> ent.isAlive() && ent != player)) {
            if (e == primary) continue;
            Vec3 c = e.getBoundingBox().getCenter();
            double dist = c.distanceTo(waveCenter);
            if (dist > waveRadius) continue;
            double falloff = 1.0 - dist / (waveRadius + 1.0);
            Vec3 away = c.subtract(waveCenter);
            if (away.lengthSqr() < 1.0E-4) away = dir;
            away = away.normalize();
            if (e instanceof LivingEntity living) {
                living.hurt(level.damageSources().playerAttack(player), (float) (waveDamage * falloff));
            }
            Vec3 launch = away.scale(2.2 * falloff).add(dir.scale(1.2 * falloff)).add(0, 0.8 * falloff + 0.2, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(launch));
            e.hurtMarked = true;
        }

        // pulverize the ground in a cone
        if (GodlikeConfig.COMMON.punchBreaksBlocks.get()) {
            double length = GodlikeConfig.COMMON.punchConeLength.get();
            BlockBreaker.cone(level, fist, dir, length, 28.0, 6000);
        }

        GodlikeNetwork.sendNear(level, fist, 200.0, new FxPacket(FxPacket.PUNCH, fist, dir, (float) waveRadius, primary != null ? 1 : 0));
        level.playSound(null, fist.x, fist.y, fist.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 5.0f, 0.55f);
        level.playSound(null, fist.x, fist.y, fist.z, SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 3.0f, 0.3f);
        level.playSound(null, fist.x, fist.y, fist.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 3.0f, 0.5f);
        level.playSound(null, fist.x, fist.y, fist.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 1.6f);
    }

    /** One shot, anything. The Warden takes two. Damage caps and immunities from other mods are overridden. */
    private static void obliterate(ServerPlayer player, LivingEntity target) {
        ServerLevel level = player.serverLevel();
        target.invulnerableTime = 0;
        if (target instanceof Warden warden) {
            warden.hurt(level.damageSources().playerAttack(player), warden.getMaxHealth() * 0.5f + 0.5f);
            return;
        }
        target.hurt(level.damageSources().playerAttack(player), 1.0E6f);
        if (target.isAlive() && !(target instanceof Player) && !target.isInvulnerable()) {
            // something (resistance V, damage caps, modded armour) ate the hit: godlike means godlike
            target.setLastHurtByMob(player);
            target.invulnerableTime = 0;
            target.hurt(level.damageSources().genericKill(), Float.MAX_VALUE);
        }
    }
}
