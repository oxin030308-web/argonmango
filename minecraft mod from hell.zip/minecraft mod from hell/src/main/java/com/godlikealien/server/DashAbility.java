package com.godlikealien.server;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.FxPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.util.BlockBreaker;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Server side of the Lightspeed Dash. The client moves itself (player movement is client-authoritative,
 * same as the core's dash); the server validates, carves the tunnel, hits everything in the path and keeps
 * the movement checks happy during the dash window.
 */
public final class DashAbility {
    private DashAbility() {}

    public static void execute(ServerPlayer player, GodlikeState state, Vec3 end, int distance) {
        if (state.onCooldown(GodlikeAbilities.CD_DASH)) return;
        if (!GodlikeGate.canUse(player, state) || !GodlikeGate.canAct(player)) return;
        int maxDistance = GodlikeConfig.COMMON.dashMaxDistance.get();
        Vec3 origin = player.position();
        Vec3 delta = end.subtract(origin);
        double len = delta.length();
        if (len < 0.5 || len > maxDistance + 4.0 || distance > maxDistance) return;
        Vec3 dir = delta.scale(1.0 / len);

        ServerLevel level = player.serverLevel();
        double blocksPerTick = GodlikeConfig.COMMON.dashBlocksPerTick.get();
        int ticks = Math.max(1, (int) Math.ceil(len / blocksPerTick));

        // carve the tunnel first so the incoming movement packets never collide with anything
        if (GodlikeConfig.COMMON.dashSmashesBlocks.get()) {
            double radius = GodlikeConfig.COMMON.dashTunnelRadius.get();
            Vec3 a = origin.add(0, 0.9, 0);
            Vec3 b = end.add(0, 0.9, 0);
            BlockBreaker.tunnel(level, a, b, radius, 40000);
        }

        // obliterate everything in the path
        float damage = GodlikeConfig.COMMON.dashDamage.get().floatValue();
        AABB box = new AABB(origin, end).inflate(3.0);
        for (Entity e : level.getEntities(player, box, ent -> ent.isAlive() && ent != player)) {
            Vec3 c = e.getBoundingBox().getCenter();
            double reach = 2.5 + e.getBbWidth() * 0.5;
            if (GodlikeMath.segmentDistanceSqr(c, origin.add(0, 0.9, 0), end.add(0, 0.9, 0)) > reach * reach) continue;
            if (e instanceof LivingEntity living) {
                living.hurt(level.damageSources().playerAttack(player), damage);
                living.invulnerableTime = 0;
            }
            Vec3 shove = dir.scale(3.0).add(0, 0.9, 0);
            e.setDeltaMovement(e.getDeltaMovement().add(shove));
            e.hurtMarked = true;
        }

        state.dashTicks = ticks + 20;
        state.dashDir = dir;
        state.dashStep = Math.min(len, blocksPerTick);
        state.setCooldown(GodlikeAbilities.CD_DASH, GodlikeConfig.COMMON.dashCooldownTicks.get());
        player.fallDistance = 0;
        // The client moves itself at light speed; with noPhysics the server accepts those positions instead of
        // re-simulating a 40-block step against blocks (which is what logs "moved wrongly" and rubber-bands).
        state.dashRestoreNoPhysics = player.noPhysics;
        player.noPhysics = true;

        GodlikeNetwork.sendNear(level, origin, 400.0, new FxPacket(FxPacket.DASH_STREAK, origin.add(0, 0.9, 0), end.add(0, 0.9, 0), (float) len, ticks));
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.WARDEN_SONIC_BOOM, SoundSource.PLAYERS, 4.0f, 1.7f);
        level.playSound(null, origin.x, origin.y, origin.z, SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 2.0f, 1.8f);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 3.0f, 0.6f);
        level.playSound(null, end.x, end.y, end.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 2.0f, 1.6f);
    }

    /** Keeps the server-side velocity in line with the dash so vanilla's "moved too quickly" check stays quiet. */
    public static void tick(ServerPlayer player, GodlikeState state) {
        if (state.dashTicks <= 0) return;
        state.dashTicks--;
        player.setDeltaMovement(state.dashDir.scale(state.dashStep));
        player.fallDistance = 0;
        player.noPhysics = true;
        if (state.dashTicks == 0) {
            player.noPhysics = state.dashRestoreNoPhysics;
            state.dirty = true;
        }
    }
}
