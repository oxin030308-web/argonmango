package com.godlikealien.server;

import com.baranhan123.viltrumiteflight.config.ViltrumiteConfig;
import com.baranhan123.viltrumiteflight.util.FlightState;
import com.baranhan123.viltrumiteflight.util.ViltrumiteFlightPlayer;
import com.godlikealien.GodlikeConfig;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Passive godlike traits shared by both sides: Sonic Flight speed and the resistance upkeep.
 */
public final class Passives {
    private Passives() {}

    /**
     * Sonic Flight. ViltrumiteFlight assigns look * throttle * maxFlightSpeed at the END of every player tick,
     * so we boost the velocity at the START of the next tick (before movement is applied).
     * Below 80% throttle the normal flight speed applies; from 80% to 100% the speed ramps up to the speed of sound.
     */
    public static void tickSonicFlight(Player player, boolean enabled) {
        if (!enabled) return;
        if (!(player instanceof ViltrumiteFlightPlayer flight)) return;
        FlightState fs = flight.getFlightState();
        if (fs != FlightState.SONIC && fs != FlightState.CRUISE) return;
        float throttle = flight.getFlightThrottle();
        if (throttle < 0.8f) return;
        ViltrumiteConfig flightConfig = ViltrumiteConfig.INSTANCE;
        double maxFlightSpeed = flightConfig != null ? flightConfig.maxFlightSpeed : 2.0;
        double normalSpeed = throttle * maxFlightSpeed;
        double sonicSpeed = GodlikeConfig.COMMON.sonicFlightSpeed.get();
        if (sonicSpeed <= normalSpeed) return;
        double t = Mth.clamp((throttle - 0.8) / 0.2, 0.0, 1.0);
        double speed = Mth.lerp(t * t, normalSpeed, sonicSpeed);
        Vec3 look = player.getLookAngle().normalize();
        Vec3 current = player.getDeltaMovement();
        if (current.lengthSqr() >= speed * speed) return;
        player.setDeltaMovement(look.scale(speed));
        player.fallDistance = 0;
    }

    /** Godlike Resistance upkeep: no fire, no drowning, no freezing. Damage itself is cancelled in the events. */
    public static void tickResistance(Player player, boolean enabled) {
        if (!enabled) return;
        if (player.isOnFire()) player.clearFire();
        if (player.getAirSupply() < player.getMaxAirSupply()) player.setAirSupply(player.getMaxAirSupply());
        if (player.getTicksFrozen() > 0) player.setTicksFrozen(0);
        player.fallDistance = 0;
    }
}
