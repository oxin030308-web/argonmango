package com.godlikealien.state;

import com.godlikealien.GodlikeAlien;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-side registry of godlike states, keyed by player UUID. Persisted flags live in the player's
 * Forge "PlayerPersisted" NBT so they survive death and relogs.
 */
public final class GodlikeStateManager {
    private static final Map<UUID, GodlikeState> STATES = new ConcurrentHashMap<>();
    private static final String NBT_KEY = GodlikeAlien.MODID;

    private GodlikeStateManager() {}

    public static GodlikeState get(Player player) {
        return STATES.computeIfAbsent(player.getUUID(), uuid -> {
            GodlikeState state = new GodlikeState();
            loadPersisted(player, state);
            return state;
        });
    }

    public static GodlikeState getIfPresent(Player player) {
        return STATES.get(player.getUUID());
    }

    public static void remove(Player player) {
        STATES.remove(player.getUUID());
    }

    public static void clearAll() {
        STATES.clear();
    }

    public static void loadPersisted(Player player, GodlikeState state) {
        CompoundTag persisted = player.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        if (persisted.contains(NBT_KEY)) {
            state.readPersisted(persisted.getCompound(NBT_KEY));
        }
    }

    public static void savePersisted(Player player, GodlikeState state) {
        CompoundTag root = player.getPersistentData();
        CompoundTag persisted = root.getCompound(Player.PERSISTED_NBT_TAG);
        CompoundTag mine = new CompoundTag();
        state.writePersisted(mine);
        persisted.put(NBT_KEY, mine);
        root.put(Player.PERSISTED_NBT_TAG, persisted);
    }

    /** Copies the persisted tag from one player entity to another (death / dimension clone). */
    public static void copyPersisted(Player from, Player to) {
        CompoundTag src = from.getPersistentData().getCompound(Player.PERSISTED_NBT_TAG);
        if (!src.contains(NBT_KEY)) return;
        CompoundTag dstRoot = to.getPersistentData();
        CompoundTag dst = dstRoot.getCompound(Player.PERSISTED_NBT_TAG);
        dst.put(NBT_KEY, src.getCompound(NBT_KEY).copy());
        dstRoot.put(Player.PERSISTED_NBT_TAG, dst);
    }
}
