package com.godlikealien.state;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Per-player godlike state. The server owns the authoritative copy; a subset is synced to clients.
 */
public class GodlikeState {
    public static final int COOLDOWN_SLOTS = 5;

    public static final int FLAG_GODLIKE = 1;
    public static final int FLAG_RESISTANCE = 2;
    public static final int FLAG_SONIC = 4;
    public static final int FLAG_CHARGING = 8;
    public static final int FLAG_DASHING = 16;
    /** The server allows the dash / laser to smash blocks right now (config + mobGriefing). */
    public static final int FLAG_SMASH = 32;
    public static final int FLAG_BARRAGE_CHARGING = 64;
    /** The player has cosmic orbs in flight (pressing the barrage key detonates them). */
    public static final int FLAG_ORBS = 128;
    /** The player is currently freezing time (Chaos Control). */
    public static final int FLAG_TIMESTOP = 256;

    public final int[] cooldown = new int[COOLDOWN_SLOTS];
    public final int[] cooldownMax = new int[COOLDOWN_SLOTS];

    /** -1 = not charging, otherwise the number of ticks the laser has been charging. */
    public int laserCharge = -1;

    /** -1 = not charging, otherwise the number of ticks the barrage has been charging. */
    public int barrageCharge = -1;
    /** Entity ids of this player's live cosmic orbs (server only). */
    public final List<Integer> orbIds = new ArrayList<>();
    public boolean orbsAlive;
    public int barrageLaunchTick = -1000;

    /** Remaining ticks of Chaos Control (0 = time runs normally). */
    public int timeStopTicks;

    /** Set while a godlike punch impact is scheduled on the core's punch animation. */
    public boolean punchPending;
    public int punchFailsafe;

    /** Remaining ticks of the server-side dash window (used to keep the movement checks happy). */
    public int dashTicks;
    public Vec3 dashDir = Vec3.ZERO;
    public double dashStep;
    public boolean dashRestoreNoPhysics;

    /** Server-side: whether block smashing is currently allowed in the player's level. */
    public boolean smashAllowed = true;

    // persisted
    public boolean godlike;
    public boolean resistance = true;
    public boolean sonicFlight = true;

    /** Marks that the synced part changed and should be re-sent. */
    public boolean dirty = true;
    public int syncTimer;

    public int flags() {
        int f = 0;
        if (godlike) f |= FLAG_GODLIKE;
        if (resistance) f |= FLAG_RESISTANCE;
        if (sonicFlight) f |= FLAG_SONIC;
        if (laserCharge >= 0) f |= FLAG_CHARGING;
        if (dashTicks > 0) f |= FLAG_DASHING;
        if (smashAllowed) f |= FLAG_SMASH;
        if (barrageCharge >= 0) f |= FLAG_BARRAGE_CHARGING;
        if (orbsAlive) f |= FLAG_ORBS;
        if (timeStopTicks > 0) f |= FLAG_TIMESTOP;
        return f;
    }

    public void applyFlags(int f) {
        godlike = (f & FLAG_GODLIKE) != 0;
        resistance = (f & FLAG_RESISTANCE) != 0;
        sonicFlight = (f & FLAG_SONIC) != 0;
    }

    public void setCooldown(int slot, int ticks) {
        cooldown[slot] = ticks;
        cooldownMax[slot] = Math.max(1, ticks);
        dirty = true;
    }

    public boolean onCooldown(int slot) {
        return cooldown[slot] > 0;
    }

    public void tickCooldowns() {
        for (int i = 0; i < COOLDOWN_SLOTS; i++) {
            if (cooldown[i] > 0) cooldown[i]--;
        }
    }

    public void resetCooldowns() {
        for (int i = 0; i < COOLDOWN_SLOTS; i++) cooldown[i] = 0;
        dirty = true;
    }

    // ------------------------------------------------------------ persistence (only the flags persist)

    public void writePersisted(CompoundTag tag) {
        tag.putBoolean("godlike", godlike);
        tag.putBoolean("resistance", resistance);
        tag.putBoolean("sonicFlight", sonicFlight);
    }

    public void readPersisted(CompoundTag tag) {
        godlike = tag.getBoolean("godlike");
        resistance = !tag.contains("resistance") || tag.getBoolean("resistance");
        sonicFlight = !tag.contains("sonicFlight") || tag.getBoolean("sonicFlight");
        dirty = true;
    }
}
