package com.godlikealien.state;

import com.baranhan123.viltrumitecore.util.ViltrumiteAbilityUser;
import com.baranhan123.viltrumitecore.util.ViltrumiteCorePlayer;
import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.loading.FMLEnvironment;

/**
 * Shared "can this player use godlike stuff" logic + the greyed-out predicates for the ability icons.
 * The grey predicates run on the client, where the synced client state is consulted.
 */
public final class GodlikeGate {
    private GodlikeGate() {}

    /** Server-side: may this player use the godlike abilities at all? */
    public static boolean canUse(Player player, GodlikeState state) {
        if (!(player instanceof ViltrumiteCorePlayer core) || !core.isViltrumite()) return false;
        if (GodlikeConfig.COMMON.requireAscension.get() && !state.godlike) return false;
        return true;
    }

    /** Server-side: is the player free to start an active ability (not blocking / grabbing / mid-action)? */
    public static boolean canAct(Player player) {
        if (!(player instanceof ViltrumiteCorePlayer core)) return false;
        if (core.isBlocking()) return false;
        if (core.isTryingToGrab() || core.getGrabbedTarget() != null) return false;
        if (core.getChopTicks() > 0 || core.getThunderclapTicks() > 0) return false;
        if (core.isBarraging() || core.getBarrageTicks() != 0) return false;
        return true;
    }

    public static boolean hasAnyGodlikeAbilityEquipped(Player player) {
        if (!(player instanceof ViltrumiteAbilityUser user)) return false;
        for (int i = 0; i < 18; i++) {
            if (GodlikeAbilities.isGodlike(user.getAbilityInSlot(i))) return true;
        }
        return false;
    }

    // ------------------------------------------------------------ grey predicates (client)

    public static boolean isGreyLaser(Player player) {
        return isGreyActive(player, GodlikeAbilities.CD_LASER);
    }

    public static boolean isGreyDash(Player player) {
        return isGreyActive(player, GodlikeAbilities.CD_DASH);
    }

    public static boolean isGreyPunch(Player player) {
        return isGreyActive(player, GodlikeAbilities.CD_PUNCH);
    }

    public static boolean isGreyBarrage(Player player) {
        return isGreyActive(player, GodlikeAbilities.CD_BARRAGE);
    }

    public static boolean isGreyChaos(Player player) {
        return isGreyActive(player, GodlikeAbilities.CD_CHAOS);
    }

    public static boolean isGreyResistance(Player player) {
        return isGreyToggle(player, GodlikeState.FLAG_RESISTANCE);
    }

    public static boolean isGreySonic(Player player) {
        return isGreyToggle(player, GodlikeState.FLAG_SONIC);
    }

    private static boolean isGreyActive(Player player, int cooldownSlot) {
        if (FMLEnvironment.dist != Dist.CLIENT) return false;
        return ClientGateBridge.isGreyActive(player, cooldownSlot);
    }

    private static boolean isGreyToggle(Player player, int flag) {
        if (FMLEnvironment.dist != Dist.CLIENT) return false;
        return ClientGateBridge.isGreyToggle(player, flag);
    }

    /** Filled in by the client side (avoids loading client classes on a dedicated server). */
    public static final class ClientGateBridge {
        public static java.util.function.BiPredicate<Player, Integer> ACTIVE = (p, slot) -> false;
        public static java.util.function.BiPredicate<Player, Integer> TOGGLE = (p, flag) -> false;

        static boolean isGreyActive(Player player, int slot) {
            return ACTIVE.test(player, slot);
        }

        static boolean isGreyToggle(Player player, int flag) {
            return TOGGLE.test(player, flag);
        }
    }
}
