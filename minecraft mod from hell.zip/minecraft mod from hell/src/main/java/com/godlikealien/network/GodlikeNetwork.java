package com.godlikealien.network;

import com.godlikealien.GodlikeAlien;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class GodlikeNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GodlikeAlien.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private GodlikeNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.messageBuilder(AbilityActionPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .decoder(AbilityActionPacket::decode).encoder(AbilityActionPacket::encode)
                .consumerMainThread(AbilityActionPacket::handle).add();
        CHANNEL.messageBuilder(AscendPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .decoder(AscendPacket::decode).encoder(AscendPacket::encode)
                .consumerMainThread(AscendPacket::handle).add();
        CHANNEL.messageBuilder(StateSyncPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .decoder(StateSyncPacket::decode).encoder(StateSyncPacket::encode)
                .consumerMainThread(StateSyncPacket::handle).add();
        CHANNEL.messageBuilder(FxPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .decoder(FxPacket::decode).encoder(FxPacket::encode)
                .consumerMainThread(FxPacket::handle).add();
    }

    public static void sendToServer(Object msg) {
        CHANNEL.sendToServer(msg);
    }

    public static void sendToPlayer(ServerPlayer player, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    public static void sendToTracking(Entity entity, Object msg) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> entity), msg);
    }

    public static void sendNear(ServerLevel level, Vec3 pos, double radius, Object msg) {
        CHANNEL.send(PacketDistributor.NEAR.with(
                () -> new PacketDistributor.TargetPoint(pos.x, pos.y, pos.z, radius, level.dimension())), msg);
    }
}
