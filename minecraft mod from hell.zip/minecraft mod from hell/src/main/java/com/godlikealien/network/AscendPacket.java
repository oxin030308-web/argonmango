package com.godlikealien.network;

import com.godlikealien.server.Ascension;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> Server: the player picked "Godlike Alien" on the race selection screen. */
public class AscendPacket {
    public AscendPacket() {}

    public static void encode(AscendPacket msg, FriendlyByteBuf buf) {}

    public static AscendPacket decode(FriendlyByteBuf buf) {
        return new AscendPacket();
    }

    public static void handle(AscendPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender != null) {
            Ascension.ascendFromRaceScreen(sender);
        }
        ctx.get().setPacketHandled(true);
    }
}
