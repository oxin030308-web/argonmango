package com.godlikealien.network;

import com.godlikealien.server.GodlikeServerEvents;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Client -> Server: the player pressed / released a godlike ability key. */
public class AbilityActionPacket {
    public static final int ABILITY_LASER = 0;
    public static final int ABILITY_DASH = 1;
    public static final int ABILITY_PUNCH = 2;
    public static final int ABILITY_RESISTANCE = 3;
    public static final int ABILITY_SONIC = 4;
    public static final int ABILITY_BARRAGE = 5;
    public static final int ABILITY_CHAOS = 6;

    public static final int ACTION_PRESS = 0;
    public static final int ACTION_RELEASE = 1;

    public final int ability;
    public final int action;
    public final Vec3 vec;
    public final int extra;

    public AbilityActionPacket(int ability, int action, Vec3 vec, int extra) {
        this.ability = ability;
        this.action = action;
        this.vec = vec == null ? Vec3.ZERO : vec;
        this.extra = extra;
    }

    public static AbilityActionPacket press(int ability) {
        return new AbilityActionPacket(ability, ACTION_PRESS, Vec3.ZERO, 0);
    }

    public static AbilityActionPacket release(int ability) {
        return new AbilityActionPacket(ability, ACTION_RELEASE, Vec3.ZERO, 0);
    }

    public static void encode(AbilityActionPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.ability);
        buf.writeByte(msg.action);
        buf.writeDouble(msg.vec.x);
        buf.writeDouble(msg.vec.y);
        buf.writeDouble(msg.vec.z);
        buf.writeVarInt(msg.extra);
    }

    public static AbilityActionPacket decode(FriendlyByteBuf buf) {
        int ability = buf.readByte();
        int action = buf.readByte();
        Vec3 vec = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        int extra = buf.readVarInt();
        return new AbilityActionPacket(ability, action, vec, extra);
    }

    public static void handle(AbilityActionPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer sender = ctx.get().getSender();
        if (sender != null) {
            GodlikeServerEvents.handleAction(sender, msg);
        }
        ctx.get().setPacketHandled(true);
    }
}
