package com.godlikealien.network;

import com.godlikealien.state.GodlikeState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> Client: synced slice of a player's godlike state (sent to the player and everyone tracking them). */
public class StateSyncPacket {
    public final int entityId;
    public final int[] cooldown;
    public final int[] cooldownMax;
    public final int laserCharge;
    public final int barrageCharge;
    public final int timeStopTicks;
    public final int flags;

    public StateSyncPacket(int entityId, int[] cooldown, int[] cooldownMax, int laserCharge, int barrageCharge, int timeStopTicks, int flags) {
        this.entityId = entityId;
        this.cooldown = cooldown;
        this.cooldownMax = cooldownMax;
        this.laserCharge = laserCharge;
        this.barrageCharge = barrageCharge;
        this.timeStopTicks = timeStopTicks;
        this.flags = flags;
    }

    public static StateSyncPacket of(int entityId, GodlikeState state) {
        return new StateSyncPacket(entityId, state.cooldown.clone(), state.cooldownMax.clone(), state.laserCharge, state.barrageCharge,
                state.timeStopTicks, state.flags());
    }

    public static void encode(StateSyncPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.entityId);
        buf.writeByte(msg.cooldown.length);
        for (int i = 0; i < msg.cooldown.length; i++) {
            buf.writeVarInt(msg.cooldown[i]);
            buf.writeVarInt(msg.cooldownMax[i]);
        }
        buf.writeVarInt(msg.laserCharge + 1);
        buf.writeVarInt(msg.barrageCharge + 1);
        buf.writeVarInt(msg.timeStopTicks);
        buf.writeVarInt(msg.flags);
    }

    public static StateSyncPacket decode(FriendlyByteBuf buf) {
        int entityId = buf.readVarInt();
        int n = buf.readByte();
        int[] cd = new int[GodlikeState.COOLDOWN_SLOTS];
        int[] cdMax = new int[GodlikeState.COOLDOWN_SLOTS];
        for (int i = 0; i < n; i++) {
            int a = buf.readVarInt();
            int b = buf.readVarInt();
            if (i < cd.length) {
                cd[i] = a;
                cdMax[i] = b;
            }
        }
        int charge = buf.readVarInt() - 1;
        int barrage = buf.readVarInt() - 1;
        int timeStop = buf.readVarInt();
        int flags = buf.readVarInt();
        return new StateSyncPacket(entityId, cd, cdMax, charge, barrage, timeStop, flags);
    }

    public static void handle(StateSyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.godlikealien.client.ClientPacketHandler.handleStateSync(msg));
        ctx.get().setPacketHandled(true);
    }
}
