package com.godlikealien.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> Client: play a godlike visual effect. */
public class FxPacket {
    public static final int BEAM = 0;            // a = start, b = end, power
    public static final int LASER_IMPACT = 1;    // a = pos, power
    public static final int MEGA_EXPLOSION = 2;  // a = pos, power = radius
    public static final int PUNCH = 3;           // a = pos, b = direction
    public static final int DASH_STREAK = 4;     // a = start, b = end
    public static final int ASCEND = 5;          // a = pos
    public static final int LASER_FIZZLE = 6;    // a = pos
    public static final int SHIELD = 7;          // a = pos
    public static final int LASER_CHARGE_STEP = 8; // a = pos, extra = charge
    public static final int CORE_WARNING = 9;    // a = pos, extra = fuse
    public static final int ORB_EXPLOSION = 10;  // a = pos, power = radius, extra = tier (0 orb, 1 bomblet)
    public static final int BARRAGE_LAUNCH = 11; // a = pos, b = direction, extra = count
    public static final int CHAOS_START = 12;    // a = pos, power = radius
    public static final int CHAOS_END = 13;      // a = pos, power = radius

    public final int type;
    public final Vec3 a;
    public final Vec3 b;
    public final float power;
    public final int extra;

    public FxPacket(int type, Vec3 a, Vec3 b, float power, int extra) {
        this.type = type;
        this.a = a == null ? Vec3.ZERO : a;
        this.b = b == null ? Vec3.ZERO : b;
        this.power = power;
        this.extra = extra;
    }

    public static void encode(FxPacket msg, FriendlyByteBuf buf) {
        buf.writeByte(msg.type);
        buf.writeDouble(msg.a.x);
        buf.writeDouble(msg.a.y);
        buf.writeDouble(msg.a.z);
        buf.writeDouble(msg.b.x);
        buf.writeDouble(msg.b.y);
        buf.writeDouble(msg.b.z);
        buf.writeFloat(msg.power);
        buf.writeVarInt(msg.extra);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        int type = buf.readByte();
        Vec3 a = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        Vec3 b = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
        float power = buf.readFloat();
        int extra = buf.readVarInt();
        return new FxPacket(type, a, b, power, extra);
    }

    public static void handle(FxPacket msg, Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.godlikealien.client.ClientPacketHandler.handleFx(msg));
        ctx.get().setPacketHandled(true);
    }
}
