package com.godlikealien;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

public final class GodlikeConfig {
    public static final Common COMMON;
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final Client CLIENT;
    public static final ForgeConfigSpec CLIENT_SPEC;

    static {
        Pair<Common, ForgeConfigSpec> c = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = c.getLeft();
        COMMON_SPEC = c.getRight();
        Pair<Client, ForgeConfigSpec> cl = new ForgeConfigSpec.Builder().configure(Client::new);
        CLIENT = cl.getLeft();
        CLIENT_SPEC = cl.getRight();
    }

    private GodlikeConfig() {}

    public static final class Common {
        // general
        public final ForgeConfigSpec.BooleanValue requireAscension;
        public final ForgeConfigSpec.BooleanValue respectMobGriefing;
        public final ForgeConfigSpec.DoubleValue maxBreakResistance;
        public final ForgeConfigSpec.BooleanValue godlikeAura;

        // laser
        public final ForgeConfigSpec.IntValue laserMinChargeTicks;
        public final ForgeConfigSpec.IntValue laserMaxChargeTicks;
        public final ForgeConfigSpec.IntValue laserCooldownTicks;
        public final ForgeConfigSpec.DoubleValue laserRange;
        public final ForgeConfigSpec.DoubleValue laserMinDamage;
        public final ForgeConfigSpec.DoubleValue laserMaxDamage;
        public final ForgeConfigSpec.BooleanValue laserVaporizesBlocks;
        public final ForgeConfigSpec.IntValue laserPierceDepth;
        public final ForgeConfigSpec.IntValue laserDetonationDelayTicks;
        public final ForgeConfigSpec.IntValue laserExplosionMinRadius;
        public final ForgeConfigSpec.IntValue laserExplosionMaxRadius;
        public final ForgeConfigSpec.DoubleValue laserExplosionDamage;
        public final ForgeConfigSpec.BooleanValue laserExplosionBreaksBlocks;

        // dash
        public final ForgeConfigSpec.IntValue dashMaxDistance;
        public final ForgeConfigSpec.IntValue dashDefaultDistance;
        public final ForgeConfigSpec.IntValue dashCooldownTicks;
        public final ForgeConfigSpec.DoubleValue dashDamage;
        public final ForgeConfigSpec.BooleanValue dashSmashesBlocks;
        public final ForgeConfigSpec.DoubleValue dashTunnelRadius;
        public final ForgeConfigSpec.DoubleValue dashBlocksPerTick;

        // punch
        public final ForgeConfigSpec.IntValue punchCooldownTicks;
        public final ForgeConfigSpec.DoubleValue punchReach;
        public final ForgeConfigSpec.DoubleValue punchShockwaveRadius;
        public final ForgeConfigSpec.DoubleValue punchShockwaveDamage;
        public final ForgeConfigSpec.BooleanValue punchBreaksBlocks;
        public final ForgeConfigSpec.DoubleValue punchConeLength;

        // cosmic barrage
        public final ForgeConfigSpec.IntValue barrageMinChargeTicks;
        public final ForgeConfigSpec.IntValue barrageMaxChargeTicks;
        public final ForgeConfigSpec.IntValue barrageCooldownTicks;
        public final ForgeConfigSpec.IntValue barrageMinCount;
        public final ForgeConfigSpec.IntValue barrageMaxCount;
        public final ForgeConfigSpec.DoubleValue barrageSpeed;
        public final ForgeConfigSpec.DoubleValue barrageSteering;
        public final ForgeConfigSpec.IntValue barrageLifetimeTicks;
        public final ForgeConfigSpec.DoubleValue barrageExplosionRadius;
        public final ForgeConfigSpec.DoubleValue barrageDamage;
        public final ForgeConfigSpec.IntValue barrageClusterCount;
        public final ForgeConfigSpec.DoubleValue barrageClusterRadius;
        public final ForgeConfigSpec.DoubleValue barrageClusterDamage;
        public final ForgeConfigSpec.BooleanValue barrageBreaksBlocks;

        // chaos control
        public final ForgeConfigSpec.IntValue chaosDurationTicks;
        public final ForgeConfigSpec.IntValue chaosCooldownTicks;
        public final ForgeConfigSpec.DoubleValue chaosRadius;
        public final ForgeConfigSpec.BooleanValue chaosFreezesPlayers;

        // passives
        public final ForgeConfigSpec.DoubleValue sonicFlightSpeed;

        Common(ForgeConfigSpec.Builder b) {
            b.push("general");
            requireAscension = b.comment("If true, only players who ascended as a Godlike Alien (race screen or /godlikealien ascend) can use the godlike abilities. If false, any Viltrumite can.")
                    .define("requireAscension", true);
            respectMobGriefing = b.comment("If true, godlike block destruction respects the mobGriefing gamerule.")
                    .define("respectMobGriefing", true);
            maxBreakResistance = b.comment("Blocks with an explosion resistance at or above this value survive godlike destruction (obsidian is 1200, bedrock is 3600000).")
                    .defineInRange("maxBreakResistance", 1000.0, 0.0, 1.0E9);
            godlikeAura = b.comment("Show a subtle cosmic aura around ascended players.")
                    .define("godlikeAura", true);
            b.pop();

            b.push("laser");
            laserMinChargeTicks = b.comment("Minimum charge (ticks) before the Super Laser can fire.")
                    .defineInRange("minChargeTicks", 20, 1, 200);
            laserMaxChargeTicks = b.comment("Charge (ticks) for full power. The laser fires automatically when fully charged.")
                    .defineInRange("maxChargeTicks", 60, 2, 400);
            laserCooldownTicks = b.comment("Cooldown in ticks after firing.")
                    .defineInRange("cooldownTicks", 400, 0, 72000);
            laserRange = b.comment("Maximum beam length in blocks.")
                    .defineInRange("range", 160.0, 8.0, 512.0);
            laserMinDamage = b.comment("Beam damage at minimum charge.")
                    .defineInRange("minDamage", 300.0, 0.0, 1.0E7);
            laserMaxDamage = b.comment("Beam damage at full charge.")
                    .defineInRange("maxDamage", 1200.0, 0.0, 1.0E7);
            laserVaporizesBlocks = b.comment("The beam vaporizes blocks: a crater at the impact point plus a drilled hole behind it.")
                    .define("vaporizesBlocks", true);
            laserPierceDepth = b.comment("How many blocks the beam drills into solid ground behind the impact point at full charge (the unstable core stays at the impact point).")
                    .defineInRange("pierceDepth", 24, 0, 256);
            laserDetonationDelayTicks = b.comment("Delay (ticks) between the beam impact and the ginormous explosion. 300 = 15 seconds.")
                    .defineInRange("detonationDelayTicks", 300, 1, 72000);
            laserExplosionMinRadius = b.comment("Explosion radius at minimum charge.")
                    .defineInRange("explosionMinRadius", 12, 1, 96);
            laserExplosionMaxRadius = b.comment("Explosion radius at full charge (ginormous).")
                    .defineInRange("explosionMaxRadius", 32, 1, 128);
            laserExplosionDamage = b.comment("Damage dealt to entities caught in the explosion wave.")
                    .defineInRange("explosionDamage", 800.0, 0.0, 1.0E7);
            laserExplosionBreaksBlocks = b.comment("The explosion destroys blocks.")
                    .define("explosionBreaksBlocks", true);
            b.pop();

            b.push("dash");
            dashMaxDistance = b.comment("Maximum Lightspeed Dash distance in blocks (adjusted with the scroll wheel while holding the ability key).")
                    .defineInRange("maxDistance", 256, 4, 1024);
            dashDefaultDistance = b.comment("Default dash distance for players who never scrolled.")
                    .defineInRange("defaultDistance", 32, 4, 1024);
            dashCooldownTicks = b.comment("Cooldown in ticks.")
                    .defineInRange("cooldownTicks", 20, 0, 72000);
            dashDamage = b.comment("Damage dealt to anything caught in the dash path.")
                    .defineInRange("damage", 100.0, 0.0, 1.0E7);
            dashSmashesBlocks = b.comment("The dash smashes through blocks in its path instead of stopping at them.")
                    .define("smashesBlocks", true);
            dashTunnelRadius = b.comment("Radius of the tunnel carved by the dash.")
                    .defineInRange("tunnelRadius", 1.5, 0.5, 4.0);
            dashBlocksPerTick = b.comment("How many blocks the dash travels per tick (higher = closer to light speed).")
                    .defineInRange("blocksPerTick", 40.0, 4.0, 1024.0);
            b.pop();

            b.push("punch");
            punchCooldownTicks = b.comment("Cooldown in ticks.")
                    .defineInRange("cooldownTicks", 30, 0, 72000);
            punchReach = b.comment("Reach of the lethal punch in blocks.")
                    .defineInRange("reach", 5.5, 1.0, 32.0);
            punchShockwaveRadius = b.comment("Radius of the shockwave that launches everything nearby.")
                    .defineInRange("shockwaveRadius", 12.0, 1.0, 64.0);
            punchShockwaveDamage = b.comment("Damage dealt by the shockwave to entities that were not the primary target.")
                    .defineInRange("shockwaveDamage", 40.0, 0.0, 1.0E7);
            punchBreaksBlocks = b.comment("The punch pulverizes blocks in a cone in front of the player.")
                    .define("breaksBlocks", true);
            punchConeLength = b.comment("Length of the pulverized cone.")
                    .defineInRange("coneLength", 12.0, 1.0, 64.0);
            b.pop();

            b.push("barrage");
            barrageMinChargeTicks = b.comment("Minimum charge (ticks) before the Cosmic Barrage can be released.")
                    .defineInRange("minChargeTicks", 12, 1, 200);
            barrageMaxChargeTicks = b.comment("Charge (ticks) for the maximum number of orbs. Fires automatically when reached.")
                    .defineInRange("maxChargeTicks", 50, 2, 400);
            barrageCooldownTicks = b.comment("Cooldown in ticks after launching.")
                    .defineInRange("cooldownTicks", 140, 0, 72000);
            barrageMinCount = b.comment("Orbs launched at minimum charge.")
                    .defineInRange("minCount", 4, 1, 64);
            barrageMaxCount = b.comment("Orbs launched at full charge.")
                    .defineInRange("maxCount", 12, 1, 64);
            barrageSpeed = b.comment("Orb speed in blocks per tick.")
                    .defineInRange("speed", 1.35, 0.1, 10.0);
            barrageSteering = b.comment("How hard the orbs steer toward where you look (0 = dumb-fire, 1 = instant).")
                    .defineInRange("steering", 0.14, 0.0, 1.0);
            barrageLifetimeTicks = b.comment("Orbs detonate on their own after this many ticks.")
                    .defineInRange("lifetimeTicks", 200, 20, 6000);
            barrageExplosionRadius = b.comment("Explosion radius of a full-power orb.")
                    .defineInRange("explosionRadius", 3.5, 0.5, 16.0);
            barrageDamage = b.comment("Damage of a full-power orb explosion.")
                    .defineInRange("damage", 60.0, 0.0, 1.0E7);
            barrageClusterCount = b.comment("Bomblets released when an orb hits something.")
                    .defineInRange("clusterCount", 7, 0, 32);
            barrageClusterRadius = b.comment("Explosion radius of a bomblet.")
                    .defineInRange("clusterRadius", 2.0, 0.5, 8.0);
            barrageClusterDamage = b.comment("Damage of a bomblet explosion.")
                    .defineInRange("clusterDamage", 24.0, 0.0, 1.0E7);
            barrageBreaksBlocks = b.comment("Orb and bomblet explosions destroy blocks.")
                    .define("breaksBlocks", true);
            b.pop();

            b.push("chaos");
            chaosDurationTicks = b.comment("How long Chaos Control freezes time, in ticks (160 = 8 seconds).")
                    .defineInRange("durationTicks", 160, 20, 72000);
            chaosCooldownTicks = b.comment("Cooldown in ticks after time resumes.")
                    .defineInRange("cooldownTicks", 600, 0, 72000);
            chaosRadius = b.comment("Radius of the frozen bubble around the player, in blocks.")
                    .defineInRange("radius", 96.0, 8.0, 512.0);
            chaosFreezesPlayers = b.comment("Other players inside the bubble are frozen too (they cannot move, attack or interact).")
                    .define("freezesPlayers", true);
            b.pop();

            b.push("passives");
            sonicFlightSpeed = b.comment("Sonic Flight top speed in blocks per tick at full throttle. 17.15 blocks/tick is the speed of sound (343 m/s).")
                    .defineInRange("sonicFlightSpeed", 17.15, 1.0, 200.0);
            b.pop();
        }
    }

    public static final class Client {
        public final ForgeConfigSpec.IntValue dashDistance;
        public final ForgeConfigSpec.DoubleValue particleDensity;
        public final ForgeConfigSpec.BooleanValue cameraShake;
        public final ForgeConfigSpec.BooleanValue screenFlash;
        public final ForgeConfigSpec.BooleanValue showHud;
        public final ForgeConfigSpec.BooleanValue chaosDesaturate;

        Client(ForgeConfigSpec.Builder b) {
            b.push("client");
            dashDistance = b.comment("Last used Lightspeed Dash distance (saved automatically when you scroll).")
                    .defineInRange("dashDistance", 32, 4, 1024);
            particleDensity = b.comment("Multiplier for the amount of godlike particles (lower this on weaker PCs).")
                    .defineInRange("particleDensity", 1.0, 0.05, 4.0);
            cameraShake = b.comment("Camera shake on big impacts.").define("cameraShake", true);
            screenFlash = b.comment("Screen flash on the ginormous explosion.").define("screenFlash", true);
            showHud = b.comment("Show godlike cooldown / charge overlays on the Viltrumite ability hotbar.").define("showHud", true);
            chaosDesaturate = b.comment("Desaturate the world (grey/blue time-stop look) while Chaos Control is active around you.").define("chaosDesaturate", true);
            b.pop();
        }
    }
}
