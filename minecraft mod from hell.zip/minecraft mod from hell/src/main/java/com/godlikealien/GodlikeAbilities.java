package com.godlikealien;

import com.baranhan123.viltrumitecore.ability.ViltrumiteAbilities;
import com.baranhan123.viltrumitecore.ability.ViltrumiteAbility;
import com.godlikealien.state.GodlikeGate;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;

import java.util.List;

/**
 * The godlike ability set. Abilities are registered into ViltrumiteCore's ability registry so they show up in the
 * Viltrumite ability menu (K) and can be dragged into the ability hotbar like any core ability.
 */
public final class GodlikeAbilities {
    public static final String LASER = "godlikealien:laser";
    public static final String DASH = "godlikealien:lightspeed_dash";
    public static final String PUNCH = "godlikealien:godlike_punch";
    public static final String RESISTANCE = "godlikealien:resistance";
    public static final String SONIC_FLIGHT = "godlikealien:sonic_flight";
    public static final String BARRAGE = "godlikealien:cosmic_barrage";
    public static final String CHAOS = "godlikealien:chaos_control";

    /** Order matters: this is the order used when auto-equipping a hotbar page. */
    public static final List<String> ALL_IDS = List.of(LASER, DASH, PUNCH, BARRAGE, CHAOS, RESISTANCE, SONIC_FLIGHT);

    /** Cooldown slot indices (see GodlikeState). */
    public static final int CD_LASER = 0;
    public static final int CD_DASH = 1;
    public static final int CD_PUNCH = 2;
    public static final int CD_BARRAGE = 3;
    public static final int CD_CHAOS = 4;

    private GodlikeAbilities() {}

    public static boolean isGodlike(String id) {
        return id != null && id.startsWith("godlikealien:");
    }

    public static int cooldownIndex(String id) {
        if (LASER.equals(id)) return CD_LASER;
        if (DASH.equals(id)) return CD_DASH;
        if (PUNCH.equals(id)) return CD_PUNCH;
        if (BARRAGE.equals(id)) return CD_BARRAGE;
        if (CHAOS.equals(id)) return CD_CHAOS;
        return -1;
    }

    private static ResourceLocation icon(String name) {
        return new ResourceLocation(GodlikeAlien.MODID, "textures/gui/ability/" + name + ".png");
    }

    public static void registerAll() {
        register(new ViltrumiteAbility(LASER, icon("laser"),
                "<aqua>Super Laser",
                "<grey>Cooldown: <lime>20s\n<grey>Charge: <lime>1s - 3s\n<grey>Type: <red>Hold\n\n"
                        + "<grey>Hold the key to gather cosmic energy, release to fire\n"
                        + "<grey>a devastating beam that vaporizes everything in its path.\n\n"
                        + "<grey>The impact point becomes an <aqua>unstable core<grey> that\n"
                        + "<grey>detonates in a <red>ginormous explosion<grey> after <lime>15 seconds<grey>.\n"
                        + "<grey>Longer charge = bigger beam and bigger boom.\n\n"
                        + "<red>Cannot be used while blocking or grabbing.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyLaser));

        register(new ViltrumiteAbility(DASH, icon("lightspeed_dash"),
                "<aqua>Lightspeed Dash",
                "<grey>Cooldown: <lime>1s\n<grey>Type: <red>Hold + Scroll\n\n"
                        + "<grey>Hold the key to aim, use the <yellow>scroll wheel<grey> to set the\n"
                        + "<grey>distance and release to move faster than light.\n"
                        + "<grey>Tap the key to dash instantly at the last distance.\n\n"
                        + "<grey>Anything in your path is obliterated and blocks are\n"
                        + "<grey>smashed straight through.\n\n"
                        + "<red>Cannot be used while blocking or grabbing.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyDash));

        register(new ViltrumiteAbility(PUNCH, icon("godlike_punch"),
                "<aqua>Godlike Punch",
                "<grey>Cooldown: <lime>1.5s\n<grey>Type: <aqua>Instant\n\n"
                        + "<grey>A punch of unimaginable weight. Whatever it hits\n"
                        + "<grey>dies in <lime>one shot<grey> - only the <red>Warden<grey> survives\n"
                        + "<grey>a single blow and dies to the second.\n\n"
                        + "<grey>The impact releases a shockwave that pulverizes the\n"
                        + "<grey>ground and launches everything nearby.\n\n"
                        + "<red>Cannot be used while blocking or grabbing.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyPunch));

        register(new ViltrumiteAbility(BARRAGE, icon("cosmic_barrage"),
                "<aqua>Cosmic Barrage",
                "<grey>Cooldown: <lime>7s\n<grey>Charge: <lime>0.6s - 2.5s\n<grey>Type: <red>Hold\n\n"
                        + "<grey>Hold the key to gather a swarm of cosmic orbs\n"
                        + "<grey>(<lime>4<grey> to <lime>12<grey>, more the longer you charge), release\n"
                        + "<grey>to launch them. The swarm <yellow>follows your crosshair<grey>.\n\n"
                        + "<grey>Every orb that hits a block or a mob explodes and\n"
                        + "<grey>bursts into a <lime>cluster of bomblets<grey> that scatter\n"
                        + "<grey>and explode again.\n\n"
                        + "<grey>Press the key again while orbs are flying to\n"
                        + "<grey><yellow>detonate them all<grey> on the spot.\n\n"
                        + "<red>Cannot be used while blocking or grabbing.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyBarrage));

        register(new ViltrumiteAbility(CHAOS, icon("chaos_control"),
                "<aqua>Chaos Control",
                "<grey>Cooldown: <lime>30s\n<grey>Duration: <lime>8s\n<grey>Type: <yellow>Toggle\n\n"
                        + "<grey>Stop time itself. Everything within <lime>96 blocks<grey>\n"
                        + "<grey>freezes in place: mobs, players, arrows, TNT, falling\n"
                        + "<grey>blocks, even your own cosmic orbs. You keep moving.\n\n"
                        + "<grey>Frozen enemies can still be hit. When time resumes,\n"
                        + "<grey>everything continues exactly where it left off.\n\n"
                        + "<grey>Press again to resume time early.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyChaos));

        register(new ViltrumiteAbility(RESISTANCE, icon("resistance"),
                "<aqua>Godlike Resistance",
                "<grey>Cooldown: <lime>-\n<grey>Type: <yellow>Toggle\n\n"
                        + "<grey>Your body is beyond harm. While active, <lime>nothing\n"
                        + "<grey>can damage you<grey>: not weapons, not explosions, not fire,\n"
                        + "<grey>not the Warden, not even the void of space.\n\n"
                        + "<grey>Enabled by default for ascended Godlike Aliens.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreyResistance));

        register(new ViltrumiteAbility(SONIC_FLIGHT, icon("sonic_flight"),
                "<aqua>Sonic Flight",
                "<grey>Cooldown: <lime>-\n<grey>Type: <yellow>Toggle\n\n"
                        + "<grey>Push your cruise flight past <lime>80%<grey> throttle to break\n"
                        + "<grey>the sound barrier and fly at the <lime>speed of sound<grey>\n"
                        + "<grey>(343 m/s).\n\n"
                        + "<grey>Enabled by default for ascended Godlike Aliens.\n\n<blue>Godlike Alien",
                0, GodlikeGate::isGreySonic));
    }

    private static void register(ViltrumiteAbility ability) {
        ViltrumiteAbilities.REGISTRY.put(ability.getId(), ability);
    }

    /** Convenience for tooltips / commands. */
    public static String displayName(String id) {
        return switch (id) {
            case LASER -> "Super Laser";
            case DASH -> "Lightspeed Dash";
            case PUNCH -> "Godlike Punch";
            case BARRAGE -> "Cosmic Barrage";
            case CHAOS -> "Chaos Control";
            case RESISTANCE -> "Godlike Resistance";
            case SONIC_FLIGHT -> "Sonic Flight";
            default -> id;
        };
    }

    /** Used by the core's ability screen predicate on the client. */
    public static boolean anyEquipped(Player player) {
        return GodlikeGate.hasAnyGodlikeAbilityEquipped(player);
    }
}
