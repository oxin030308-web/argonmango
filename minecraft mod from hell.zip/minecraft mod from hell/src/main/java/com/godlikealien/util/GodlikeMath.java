package com.godlikealien.util;

import net.minecraft.world.phys.Vec3;

public final class GodlikeMath {
    private GodlikeMath() {}

    /** Squared distance from point p to the segment a-b. */
    public static double segmentDistanceSqr(double px, double py, double pz, Vec3 a, Vec3 b) {
        double vx = b.x - a.x, vy = b.y - a.y, vz = b.z - a.z;
        double l2 = vx * vx + vy * vy + vz * vz;
        double t;
        if (l2 < 1.0E-9) {
            t = 0;
        } else {
            t = ((px - a.x) * vx + (py - a.y) * vy + (pz - a.z) * vz) / l2;
            t = Math.max(0, Math.min(1, t));
        }
        double cx = a.x + vx * t - px, cy = a.y + vy * t - py, cz = a.z + vz * t - pz;
        return cx * cx + cy * cy + cz * cz;
    }

    public static double segmentDistanceSqr(Vec3 p, Vec3 a, Vec3 b) {
        return segmentDistanceSqr(p.x, p.y, p.z, a, b);
    }

    /** Squared distance from point p to the infinite ray origin + t*dir (t >= 0). dir must be normalized. */
    public static double rayDistanceSqr(double px, double py, double pz, Vec3 origin, Vec3 dir) {
        double dx = px - origin.x, dy = py - origin.y, dz = pz - origin.z;
        double t = Math.max(0, dx * dir.x + dy * dir.y + dz * dir.z);
        double cx = dx - dir.x * t, cy = dy - dir.y * t, cz = dz - dir.z * t;
        return cx * cx + cy * cy + cz * cz;
    }

    /** Parameter t (0..1) of the closest point on a-b to p. */
    public static double segmentT(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 v = b.subtract(a);
        double l2 = v.lengthSqr();
        if (l2 < 1.0E-9) return 0;
        return Math.max(0, Math.min(1, p.subtract(a).dot(v) / l2));
    }

    /** Returns any unit vector perpendicular to dir. */
    public static Vec3 perpendicular(Vec3 dir) {
        Vec3 up = Math.abs(dir.y) < 0.9 ? new Vec3(0, 1, 0) : new Vec3(1, 0, 0);
        return dir.cross(up).normalize();
    }

    public static double easeOutCubic(double t) {
        double u = 1 - t;
        return 1 - u * u * u;
    }

    public static double easeInCubic(double t) {
        return t * t * t;
    }

    public static float clamp01(float v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
