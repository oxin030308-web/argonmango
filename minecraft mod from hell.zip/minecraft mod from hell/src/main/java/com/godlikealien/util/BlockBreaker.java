package com.godlikealien.util;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.server.ExplosionManager;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.Arrays;

/**
 * Godlike block destruction. Shapes are collected as ordered position lists (nearest first) and handed to
 * {@link ExplosionManager}, which vaporizes them a few thousand blocks per tick so even a 256-block tunnel
 * never freezes the server. Unbreakable rules: bedrock, wither-immune blocks, high blast resistance.
 */
public final class BlockBreaker {
    private BlockBreaker() {}

    public static boolean griefingAllowed(ServerLevel level) {
        if (!GodlikeConfig.COMMON.respectMobGriefing.get()) return true;
        return level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING);
    }

    public static boolean canBreak(BlockState state) {
        if (state.isAir()) return false;
        if (state.is(BlockTags.WITHER_IMMUNE)) return false;
        return state.getBlock().getExplosionResistance() < GodlikeConfig.COMMON.maxBreakResistance.get();
    }

    /** Removes a block without drops, returns true if something was removed. */
    public static boolean vaporize(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (!canBreak(state)) return false;
        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
        return true;
    }

    // ------------------------------------------------------------ queued shapes

    /** Carves a capsule between two points, front to back. */
    public static void tunnel(ServerLevel level, Vec3 from, Vec3 to, double radius, int maxBlocks) {
        if (!griefingAllowed(level)) return;
        ExplosionManager.queueBlocks(level, collectTunnel(level, from, to, radius, maxBlocks));
    }

    /** Vaporizes a sphere, center outward. */
    public static void sphere(ServerLevel level, Vec3 center, double radius, int maxBlocks) {
        if (!griefingAllowed(level)) return;
        ExplosionManager.queueBlocks(level, collectSphere(level, center, radius, maxBlocks));
    }

    /** Pulverizes a cone starting at origin along dir, near to far. */
    public static void cone(ServerLevel level, Vec3 origin, Vec3 dir, double length, double halfAngleDeg, int maxBlocks) {
        if (!griefingAllowed(level)) return;
        ExplosionManager.queueBlocks(level, collectCone(level, origin, dir, length, halfAngleDeg, maxBlocks));
    }

    // ------------------------------------------------------------ collectors (pure geometry, no world access)

    public static LongArrayList collectTunnel(ServerLevel level, Vec3 from, Vec3 to, double radius, int maxBlocks) {
        LongArrayList out = new LongArrayList();
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 1.0E-3) return collectSphere(level, from, radius, maxBlocks);
        Vec3 dir = d.scale(1.0 / len);
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 1;
        double r2 = radius * radius;
        int rr = Mth.ceil(radius);
        double step = Math.max(0.5, radius * 0.6);
        int steps = (int) Math.ceil(len / step);
        java.util.HashSet<Long> visited = new java.util.HashSet<>();
        for (int s = 0; s <= steps && out.size() < maxBlocks; s++) {
            Vec3 c = from.add(dir.scale(Math.min(len, s * step)));
            int cx = Mth.floor(c.x), cy = Mth.floor(c.y), cz = Mth.floor(c.z);
            for (int x = cx - rr; x <= cx + rr; x++) {
                for (int y = Math.max(minY, cy - rr); y <= Math.min(maxY, cy + rr); y++) {
                    for (int z = cz - rr; z <= cz + rr; z++) {
                        if (GodlikeMath.segmentDistanceSqr(x + 0.5, y + 0.5, z + 0.5, from, to) > r2) continue;
                        long key = BlockPos.asLong(x, y, z);
                        if (visited.add(key)) out.add(key);
                    }
                }
            }
        }
        return out;
    }

    public static LongArrayList collectSphere(ServerLevel level, Vec3 center, double radius, int maxBlocks) {
        int rr = Mth.ceil(radius);
        int cx = Mth.floor(center.x), cy = Mth.floor(center.y), cz = Mth.floor(center.z);
        double r2 = radius * radius;
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 1;
        Sorter sorter = new Sorter();
        for (int x = cx - rr; x <= cx + rr; x++) {
            for (int y = Math.max(minY, cy - rr); y <= Math.min(maxY, cy + rr); y++) {
                for (int z = cz - rr; z <= cz + rr; z++) {
                    double dx = x + 0.5 - center.x, dy = y + 0.5 - center.y, dz = z + 0.5 - center.z;
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) continue;
                    sorter.add(d2, BlockPos.asLong(x, y, z));
                }
            }
        }
        return sorter.sorted(maxBlocks);
    }

    public static LongArrayList collectCone(ServerLevel level, Vec3 origin, Vec3 dir, double length, double halfAngleDeg, int maxBlocks) {
        Vec3 d = dir.normalize();
        double cosHalf = Math.cos(Math.toRadians(halfAngleDeg));
        int rr = Mth.ceil(length);
        int cx = Mth.floor(origin.x), cy = Mth.floor(origin.y), cz = Mth.floor(origin.z);
        int minY = level.getMinBuildHeight();
        int maxY = level.getMaxBuildHeight() - 1;
        Sorter sorter = new Sorter();
        for (int x = cx - rr; x <= cx + rr; x++) {
            for (int y = Math.max(minY, cy - rr); y <= Math.min(maxY, cy + rr); y++) {
                for (int z = cz - rr; z <= cz + rr; z++) {
                    double dx = x + 0.5 - origin.x, dy = y + 0.5 - origin.y, dz = z + 0.5 - origin.z;
                    double dist2 = dx * dx + dy * dy + dz * dz;
                    if (dist2 > length * length || dist2 < 0.25) continue;
                    double dist = Math.sqrt(dist2);
                    double cos = (dx * d.x + dy * d.y + dz * d.z) / dist;
                    if (cos < 0) continue;
                    // the cone widens with distance but always includes a 1.5 block core around the ray
                    if (cos < cosHalf && GodlikeMath.rayDistanceSqr(x + 0.5, y + 0.5, z + 0.5, origin, d) > 2.25) continue;
                    sorter.add(dist2, BlockPos.asLong(x, y, z));
                }
            }
        }
        return sorter.sorted(maxBlocks);
    }

    /** Collects (distance, key) pairs and returns the keys ordered by distance. */
    private static final class Sorter {
        private double[] dist = new double[256];
        private long[] keys = new long[256];
        private int size;

        void add(double d2, long key) {
            if (size == keys.length) {
                dist = Arrays.copyOf(dist, size * 2);
                keys = Arrays.copyOf(keys, size * 2);
            }
            dist[size] = d2;
            keys[size] = key;
            size++;
        }

        LongArrayList sorted(int max) {
            Integer[] idx = new Integer[size];
            for (int i = 0; i < size; i++) idx[i] = i;
            Arrays.sort(idx, (a, b) -> Double.compare(dist[a], dist[b]));
            int n = Math.min(size, max);
            LongArrayList out = new LongArrayList(n);
            for (int i = 0; i < n; i++) out.add(keys[idx[i]]);
            return out;
        }
    }
}
