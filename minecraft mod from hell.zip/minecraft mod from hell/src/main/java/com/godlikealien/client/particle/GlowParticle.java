package com.godlikealien.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** Soft additive glow blob with size/alpha animation. */
public class GlowParticle extends TextureSheetParticle {
    protected float startSize = 0.3f;
    protected float endSize = 0.0f;
    protected float startAlpha = 1.0f;
    protected float drag = 0.96f;
    protected float gravityAccel = 0.0f;
    protected int fadeInTicks = 0;

    protected GlowParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.pickSprite(sprites);
        this.hasPhysics = false;
        this.gravity = 0;
        this.friction = 1.0f;
        this.lifetime = 20;
        this.quadSize = startSize;
        this.setColor(0.4f, 0.9f, 1.0f);
        this.alpha = 1.0f;
    }

    public GlowParticle setup(float r, float g, float b, float size0, float size1, int life, float drag, float gravity) {
        this.setColor(r, g, b);
        this.startSize = size0;
        this.endSize = size1;
        this.quadSize = size0;
        this.lifetime = Math.max(1, life);
        this.drag = drag;
        this.gravityAccel = gravity;
        return this;
    }

    public GlowParticle fadeIn(int ticks) {
        this.fadeInTicks = ticks;
        return this;
    }

    public GlowParticle alpha(float a) {
        this.startAlpha = a;
        this.alpha = a;
        return this;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.yd -= gravityAccel;
        this.move(this.xd, this.yd, this.zd);
        this.xd *= drag;
        this.yd *= drag;
        this.zd *= drag;
        float t = this.age / (float) this.lifetime;
        float fade = fadeInTicks > 0 && this.age < fadeInTicks ? this.age / (float) fadeInTicks : 1.0f;
        this.alpha = startAlpha * fade * (1.0f - t * t);
    }

    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((this.age + partialTick) / this.lifetime, 0.0f, 1.0f);
        return Mth.lerp(t, startSize, endSize);
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return GodlikeParticleRenderTypes.ADDITIVE;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new GlowParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
