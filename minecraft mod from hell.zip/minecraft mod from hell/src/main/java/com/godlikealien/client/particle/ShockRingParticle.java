package com.godlikealien.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** A flat ring lying on the XZ plane that expands outward - the classic shockwave. */
public class ShockRingParticle extends TextureSheetParticle {
    protected float startRadius = 0.5f;
    protected float endRadius = 6.0f;
    protected float startAlpha = 1.0f;
    protected float tiltX = 0.0f;
    protected float tiltZ = 0.0f;

    protected ShockRingParticle(ClientLevel level, double x, double y, double z, SpriteSet sprites) {
        super(level, x, y, z, 0, 0, 0);
        this.xd = 0;
        this.yd = 0;
        this.zd = 0;
        this.pickSprite(sprites);
        this.hasPhysics = false;
        this.gravity = 0;
        this.lifetime = 16;
        this.setColor(0.5f, 0.95f, 1.0f);
        this.alpha = 1.0f;
    }

    public ShockRingParticle setup(float r, float g, float b, float radius0, float radius1, int life, float alpha) {
        this.setColor(r, g, b);
        this.startRadius = radius0;
        this.endRadius = radius1;
        this.lifetime = Math.max(1, life);
        this.startAlpha = alpha;
        this.alpha = alpha;
        return this;
    }

    public ShockRingParticle tilt(float tiltX, float tiltZ) {
        this.tiltX = tiltX;
        this.tiltZ = tiltZ;
        return this;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        float t = this.age / (float) this.lifetime;
        this.alpha = startAlpha * (1.0f - t) * (1.0f - t);
    }

    private float radius(float partialTick) {
        float t = Mth.clamp((this.age + partialTick) / this.lifetime, 0.0f, 1.0f);
        float eased = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
        return Mth.lerp(eased, startRadius, endRadius);
    }

    @Override
    public void render(VertexConsumer consumer, Camera camera, float partialTick) {
        Vec3 cam = camera.getPosition();
        float cx = (float) (Mth.lerp(partialTick, this.xo, this.x) - cam.x);
        float cy = (float) (Mth.lerp(partialTick, this.yo, this.y) - cam.y);
        float cz = (float) (Mth.lerp(partialTick, this.zo, this.z) - cam.z);
        float r = radius(partialTick);
        float a = Mth.clamp(this.alpha, 0.0f, 1.0f);
        float u0 = getU0(), u1 = getU1(), v0 = getV0(), v1 = getV1();
        int light = 0xF000F0;

        float x0 = cx - r, x1 = cx + r, z0 = cz - r, z1 = cz + r;
        // tilt lets rings sit on slopes / walls a bit; y offsets per corner
        float y00 = cy - tiltX * r - tiltZ * r, y01 = cy - tiltX * r + tiltZ * r;
        float y11 = cy + tiltX * r + tiltZ * r, y10 = cy + tiltX * r - tiltZ * r;

        // top face
        consumer.vertex(x0, y00, z0).uv(u0, v0).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x0, y01, z1).uv(u0, v1).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x1, y11, z1).uv(u1, v1).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x1, y10, z0).uv(u1, v0).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        // bottom face (so it is visible from below too)
        consumer.vertex(x1, y10, z0).uv(u1, v0).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x1, y11, z1).uv(u1, v1).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x0, y01, z1).uv(u0, v1).color(rCol, gCol, bCol, a).uv2(light).endVertex();
        consumer.vertex(x0, y00, z0).uv(u0, v0).color(rCol, gCol, bCol, a).uv2(light).endVertex();
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return GodlikeParticleRenderTypes.ADDITIVE;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new ShockRingParticle(level, x, y, z, sprites);
        }
    }
}
