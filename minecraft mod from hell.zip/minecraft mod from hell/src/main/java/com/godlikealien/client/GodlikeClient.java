package com.godlikealien.client;

import com.godlikealien.GodlikeAlien;
import com.godlikealien.client.particle.GlowParticle;
import com.godlikealien.client.particle.ShockRingParticle;
import com.godlikealien.client.particle.SparkParticle;
import com.godlikealien.client.particle.StreakParticle;
import com.godlikealien.client.render.CosmicOrbRenderer;
import com.godlikealien.client.render.UnstableCoreRenderer;
import com.godlikealien.entity.GodlikeEntities;
import com.godlikealien.particle.GodlikeParticles;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Mod-bus client registration. */
@Mod.EventBusSubscriber(modid = GodlikeAlien.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class GodlikeClient {
    private GodlikeClient() {}

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            TimeFreezeClient.install();
            GodlikeGate.ClientGateBridge.ACTIVE = (player, slot) -> {
                Minecraft mc = Minecraft.getInstance();
                if (player != mc.player) return false;
                if (!ClientState.usable()) return true;
                return slot >= 0 && slot < ClientState.cooldown.length && ClientState.cooldown[slot] > 0;
            };
            GodlikeGate.ClientGateBridge.TOGGLE = (player, flag) -> {
                Minecraft mc = Minecraft.getInstance();
                if (player != mc.player) return false;
                if (!ClientState.usable()) return true;
                if (flag == GodlikeState.FLAG_RESISTANCE) return !ClientState.resistance;
                if (flag == GodlikeState.FLAG_SONIC) return !ClientState.sonic;
                return false;
            };
        });
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(GodlikeEntities.UNSTABLE_CORE.get(), UnstableCoreRenderer::new);
        event.registerEntityRenderer(GodlikeEntities.COSMIC_ORB.get(), CosmicOrbRenderer::new);
    }

    @SubscribeEvent
    public static void onRegisterParticles(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(GodlikeParticles.GLOW.get(), GlowParticle.Provider::new);
        event.registerSpriteSet(GodlikeParticles.SPARK.get(), SparkParticle.Provider::new);
        event.registerSpriteSet(GodlikeParticles.RING.get(), ShockRingParticle.Provider::new);
        event.registerSpriteSet(GodlikeParticles.STREAK.get(), StreakParticle.Provider::new);
    }
}
