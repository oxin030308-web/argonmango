package com.godlikealien.client;

import com.baranhan123.viltrumitecore.util.ViltrumiteCorePlayer;
import com.godlikealien.state.GodlikeState;
import com.godlikealien.util.GodlikeMath;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * World-space additive geometry: laser beams, charge orbs, light-speed streaks and the dash aim marker.
 * Everything is drawn with RenderType.lightning() (position+color, additive) so it glows over the world.
 */
public final class BeamRenderer {
    private static final List<Beam> BEAMS = new ArrayList<>();
    private static final List<Streak> STREAKS = new ArrayList<>();

    private BeamRenderer() {}

    public static void clear() {
        BEAMS.clear();
        STREAKS.clear();
    }

    public static void addBeam(Vec3 start, Vec3 end, float power) {
        BEAMS.add(new Beam(start, end, power));
    }

    public static void addStreak(Vec3 start, Vec3 end, int travelTicks) {
        STREAKS.add(new Streak(start, end, Math.max(1, travelTicks)));
    }

    public static void tick() {
        Iterator<Beam> it = BEAMS.iterator();
        while (it.hasNext()) {
            if (++it.next().life > Beam.MAX_LIFE) it.remove();
        }
        Iterator<Streak> st = STREAKS.iterator();
        while (st.hasNext()) {
            if (++st.next().life > Streak.MAX_LIFE) st.remove();
        }
    }

    // ------------------------------------------------------------ render entry

    public static void render(RenderLevelStageEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (BEAMS.isEmpty() && STREAKS.isEmpty() && !anyCharging(mc) && !ClientState.aiming) return;

        PoseStack ps = event.getPoseStack();
        Camera camera = event.getCamera();
        Vec3 cam = camera.getPosition();
        float pt = event.getPartialTick();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());

        ps.pushPose();
        ps.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f m = ps.last().pose();

        for (Beam b : BEAMS) b.render(vc, m, pt);
        for (Streak s : STREAKS) s.render(vc, m, pt);
        renderChargeOrbs(mc, vc, m, camera, pt);
        renderAimMarker(mc, vc, m, camera, pt);

        ps.popPose();
        buffers.endBatch(RenderType.lightning());
    }

    private static boolean anyCharging(Minecraft mc) {
        if (ClientState.laserCharge >= 0) return true;
        for (ClientState.RemoteState rs : ClientState.REMOTE.values()) {
            if ((rs.flags & GodlikeState.FLAG_CHARGING) != 0) return true;
        }
        return false;
    }

    // ------------------------------------------------------------ charge orbs

    private static void renderChargeOrbs(Minecraft mc, VertexConsumer vc, Matrix4f m, Camera camera, float pt) {
        for (Player p : mc.level.players()) {
            int charge;
            if (p == mc.player) {
                charge = ClientState.laserCharge;
            } else {
                ClientState.RemoteState rs = ClientState.REMOTE.get(p.getId());
                if (rs == null || (rs.flags & GodlikeState.FLAG_CHARGING) == 0) continue;
                charge = Math.max(0, rs.laserCharge) + (ClientState.clientTicks - rs.lastUpdate);
            }
            if (charge < 0) continue;
            if (p == mc.player && mc.options.getCameraType().isFirstPerson() && !(p instanceof ViltrumiteCorePlayer)) {
                // (always render; the orb sits in front of the camera and reads as a charging effect)
            }
            float power = GodlikeFx.LaserChargeHelper.power(charge);
            float frac = GodlikeFx.LaserChargeHelper.chargeFraction(charge);
            Vec3 look = p.getViewVector(pt).normalize();
            Vec3 eye = p.getEyePosition(pt);
            Vec3 orb = eye.add(look.scale(1.1)).subtract(0, 0.35, 0);
            float time = ClientState.clientTicks + pt;
            float pulse = 0.5f + 0.5f * Mth.sin(time * (0.4f + 0.6f * frac));
            float base = 0.12f + 0.45f * frac + 0.08f * pulse;
            float[] col = power >= 1.0f ? GodlikeFx.WHITE : (frac > 0.35f ? GodlikeFx.CYAN : GodlikeFx.VIOLET);
            disc(vc, m, camera, orb, base * 0.55f, GodlikeFx.WHITE, 1.0f);
            disc(vc, m, camera, orb, base * 1.3f, col, 0.75f);
            disc(vc, m, camera, orb, base * 2.6f + 0.3f * pulse, GodlikeFx.VIOLET, 0.35f);
            // spinning ring around the orb
            ring3d(vc, m, orb, look, base * 2.2f, 0.06f, col, 0.8f, time * 0.25f);
            ring3d(vc, m, orb, GodlikeMath.perpendicular(look), base * 1.8f, 0.05f, GodlikeFx.CYAN, 0.6f, -time * 0.31f);
        }
    }

    // ------------------------------------------------------------ dash aim marker

    private static void renderAimMarker(Minecraft mc, VertexConsumer vc, Matrix4f m, Camera camera, float pt) {
        if (!ClientState.aiming || ClientState.aimTarget == null) return;
        Vec3 target = ClientState.aimTarget;
        Vec3 from = mc.player.getEyePosition(pt).subtract(0, 0.4, 0);
        float[] col = ClientState.aimBlocked ? GodlikeFx.MAGENTA : GodlikeFx.CYAN;
        float time = ClientState.clientTicks + pt;
        float pulse = 0.5f + 0.5f * Mth.sin(time * 0.5f);
        // guide line
        cylinder(vc, m, from, target.add(0, 0.9, 0), 0.03f, col, 0.45f, col, 0.15f);
        // destination pillar + discs
        Vec3 base = target;
        cylinder(vc, m, base, base.add(0, 2.2, 0), 0.08f + 0.04f * pulse, GodlikeFx.WHITE, 0.8f, col, 0.0f);
        disc(vc, m, camera, base.add(0, 0.9, 0), 0.6f + 0.15f * pulse, col, 0.6f);
        ring3d(vc, m, base.add(0, 0.05, 0), new Vec3(0, 1, 0), 0.9f + 0.2f * pulse, 0.08f, col, 0.9f, time * 0.2f);
        ring3d(vc, m, base.add(0, 1.8, 0), new Vec3(0, 1, 0), 0.5f, 0.05f, GodlikeFx.WHITE, 0.7f, -time * 0.3f);
    }

    // ------------------------------------------------------------ geometry helpers

    /** Camera-facing radial-gradient disc (bright center, transparent edge). */
    public static void disc(VertexConsumer vc, Matrix4f m, Camera camera, Vec3 center, float radius, float[] col, float alpha) {
        Vector3f left = camera.getLeftVector();
        Vector3f up = camera.getUpVector();
        Vec3 right = new Vec3(-left.x(), -left.y(), -left.z());
        Vec3 upv = new Vec3(up.x(), up.y(), up.z());
        int n = 20;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n;
            double a1 = (i + 1) * Math.PI * 2 / n;
            Vec3 p0 = center.add(right.scale(Math.cos(a0) * radius)).add(upv.scale(Math.sin(a0) * radius));
            Vec3 p1 = center.add(right.scale(Math.cos(a1) * radius)).add(upv.scale(Math.sin(a1) * radius));
            vertex(vc, m, center, col, alpha);
            vertex(vc, m, center, col, alpha);
            vertex(vc, m, p0, col, 0.0f);
            vertex(vc, m, p1, col, 0.0f);
        }
    }

    /** A thin ring (flat annulus) around an axis, rotated by phase. */
    public static void ring3d(VertexConsumer vc, Matrix4f m, Vec3 center, Vec3 axis, float radius, float thickness, float[] col, float alpha, float phase) {
        Vec3 ax = axis.normalize();
        Vec3 u = GodlikeMath.perpendicular(ax);
        Vec3 v = ax.cross(u).normalize();
        int n = 32;
        for (int i = 0; i < n; i++) {
            double a0 = phase + i * Math.PI * 2 / n;
            double a1 = phase + (i + 1) * Math.PI * 2 / n;
            Vec3 d0 = u.scale(Math.cos(a0)).add(v.scale(Math.sin(a0)));
            Vec3 d1 = u.scale(Math.cos(a1)).add(v.scale(Math.sin(a1)));
            Vec3 i0 = center.add(d0.scale(radius - thickness));
            Vec3 o0 = center.add(d0.scale(radius + thickness));
            Vec3 i1 = center.add(d1.scale(radius - thickness));
            Vec3 o1 = center.add(d1.scale(radius + thickness));
            quad(vc, m, i0, o0, o1, i1, col, alpha);
        }
    }

    /** A glowing cylinder between two points with per-end colour/alpha. */
    public static void cylinder(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, float radius, float[] colA, float alphaA, float[] colB, float alphaB) {
        Vec3 d = b.subtract(a);
        if (d.lengthSqr() < 1.0E-6) return;
        Vec3 dir = d.normalize();
        Vec3 u = GodlikeMath.perpendicular(dir);
        Vec3 v = dir.cross(u).normalize();
        int n = 12;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n;
            double a1 = (i + 1) * Math.PI * 2 / n;
            Vec3 o0 = u.scale(Math.cos(a0) * radius).add(v.scale(Math.sin(a0) * radius));
            Vec3 o1 = u.scale(Math.cos(a1) * radius).add(v.scale(Math.sin(a1) * radius));
            Vec3 p0 = a.add(o0), p1 = a.add(o1), q1 = b.add(o1), q0 = b.add(o0);
            vertex(vc, m, p0, colA, alphaA);
            vertex(vc, m, p1, colA, alphaA);
            vertex(vc, m, q1, colB, alphaB);
            vertex(vc, m, q0, colB, alphaB);
            vertex(vc, m, q0, colB, alphaB);
            vertex(vc, m, q1, colB, alphaB);
            vertex(vc, m, p1, colA, alphaA);
            vertex(vc, m, p0, colA, alphaA);
        }
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float[] col, float alpha) {
        vertex(vc, m, a, col, alpha);
        vertex(vc, m, b, col, alpha);
        vertex(vc, m, c, col, alpha);
        vertex(vc, m, d, col, alpha);
        vertex(vc, m, d, col, alpha);
        vertex(vc, m, c, col, alpha);
        vertex(vc, m, b, col, alpha);
        vertex(vc, m, a, col, alpha);
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, Vec3 p, float[] col, float alpha) {
        vc.vertex(m, (float) p.x, (float) p.y, (float) p.z).color(col[0], col[1], col[2], alpha).endVertex();
    }

    // ------------------------------------------------------------ instances

    private static final class Beam {
        static final int MAX_LIFE = 18;
        final Vec3 start, end;
        final float power;
        int life = 0;

        Beam(Vec3 start, Vec3 end, float power) {
            this.start = start;
            this.end = end;
            this.power = power;
        }

        void render(VertexConsumer vc, Matrix4f m, float pt) {
            float t = (life + pt) / MAX_LIFE;
            float grow = Mth.clamp((life + pt) / 2.5f, 0.0f, 1.0f);
            float fade = (float) Math.pow(1.0f - Mth.clamp(t, 0.0f, 1.0f), 1.4);
            float flicker = 0.85f + 0.15f * Mth.sin((life + pt) * 3.1f);
            float k = (0.6f + 0.9f * power) * grow * flicker;
            cylinder(vc, m, start, end, 0.14f * k, GodlikeFx.WHITE, fade, GodlikeFx.WHITE, fade * 0.9f);
            cylinder(vc, m, start, end, 0.42f * k, GodlikeFx.CYAN, fade * 0.7f, GodlikeFx.CYAN, fade * 0.55f);
            cylinder(vc, m, start, end, 0.95f * k, GodlikeFx.VIOLET, fade * 0.3f, GodlikeFx.DEEP, fade * 0.2f);
            cylinder(vc, m, start, end, 1.7f * k, GodlikeFx.VIOLET, fade * 0.08f, GodlikeFx.VIOLET, fade * 0.05f);
        }
    }

    private static final class Streak {
        static final int MAX_LIFE = 16;
        final Vec3 start, end;
        final int travelTicks;
        int life = 0;

        Streak(Vec3 start, Vec3 end, int travelTicks) {
            this.start = start;
            this.end = end;
            this.travelTicks = travelTicks;
        }

        void render(VertexConsumer vc, Matrix4f m, float pt) {
            float age = life + pt;
            float head = Mth.clamp(age / travelTicks, 0.0f, 1.0f);
            Vec3 headPos = start.lerp(end, head);
            float fade = (float) Math.pow(1.0f - Mth.clamp(age / MAX_LIFE, 0.0f, 1.0f), 1.2);
            cylinder(vc, m, start, headPos, 0.07f, GodlikeFx.WHITE, fade * 0.35f, GodlikeFx.WHITE, fade);
            cylinder(vc, m, start, headPos, 0.22f, GodlikeFx.CYAN, fade * 0.15f, GodlikeFx.CYAN, fade * 0.6f);
            cylinder(vc, m, start, headPos, 0.5f, GodlikeFx.VIOLET, fade * 0.04f, GodlikeFx.VIOLET, fade * 0.2f);
        }
    }

    /** Unused helper kept for renderers that want to reuse the entity-space helpers. */
    static Entity dummy() {
        return null;
    }
}
