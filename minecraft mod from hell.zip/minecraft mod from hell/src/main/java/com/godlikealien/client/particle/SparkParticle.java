package com.godlikealien.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;

/** Small bright star spark; optionally affected by gravity and drag. */
public class SparkParticle extends TextureSheetParticle {
    protected float startSize = 0.12f;
    protected float drag = 0.94f;
    protected float gravityAccel = 0.0f;
    protected boolean collide = false;

    protected SparkParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.pickSprite(sprites);
        this.hasPhysics = false;
        this.gravity = 0;
        this.friction = 1.0f;
        this.lifetime = 16;
        this.quadSize = startSize;
        this.setColor(1.0f, 1.0f, 1.0f);
        this.roll = (float) (Math.random() * Math.PI * 2);
        this.oRoll = this.roll;
    }

    public SparkParticle setup(float r, float g, float b, float size, int life, float drag, float gravity, boolean collide) {
        this.setColor(r, g, b);
        this.startSize = size;
        this.quadSize = size;
        this.lifetime = Math.max(1, life);
        this.drag = drag;
        this.gravityAccel = gravity;
        this.collide = collide;
        this.hasPhysics = collide;
        return this;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        this.oRoll = this.roll;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.yd -= gravityAccel;
        this.move(this.xd, this.yd, this.zd);
        if (this.onGround && collide) {
            this.xd *= 0.6;
            this.zd *= 0.6;
        }
        this.xd *= drag;
        this.yd *= drag;
        this.zd *= drag;
        this.roll += 0.25f;
        float t = this.age / (float) this.lifetime;
        this.alpha = 1.0f - t * t * t;
    }

    @Override
    public float getQuadSize(float partialTick) {
        float t = Mth.clamp((this.age + partialTick) / this.lifetime, 0.0f, 1.0f);
        return startSize * (1.0f - 0.6f * t);
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return GodlikeParticleRenderTypes.ADDITIVE;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new SparkParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
