package com.godlikealien.client;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.state.GodlikeState;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Client-side copy of the local player's godlike state plus purely visual state. */
public final class ClientState {
    private ClientState() {}

    // ---- synced from the server (local player)
    public static final int[] cooldown = new int[GodlikeState.COOLDOWN_SLOTS];
    public static final int[] cooldownMax = new int[GodlikeState.COOLDOWN_SLOTS];
    public static int laserCharge = -1;
    public static int barrageCharge = -1;
    public static boolean orbsAlive;
    public static int timeStopTicks;
    public static boolean godlike;
    public static boolean resistance = true;
    public static boolean sonic = true;
    public static boolean smashAllowed = true;
    public static boolean synced;

    // ---- input
    public static boolean laserKeyHeld;
    public static boolean barrageKeyHeld;
    public static boolean aiming;
    public static int aimTicks;
    public static int dashDistance = -1;
    public static Vec3 aimTarget;
    public static boolean aimBlocked;

    // ---- visuals
    public static float flash;
    public static int shakeTicks;
    public static int shakeMax = 1;
    public static float shakeStrength;
    public static int clientTicks;

    /** Other players' synced flags (entity id -> state). */
    public static final Map<Integer, RemoteState> REMOTE = new HashMap<>();
    /** Multi-tick visual sequences (explosion waves, ascension spirals...). */
    public static final List<FxSequence> SEQUENCES = new ArrayList<>();

    public static final class RemoteState {
        public int laserCharge = -1;
        public int barrageCharge = -1;
        public int flags;
        public int lastUpdate;
    }

    /** Returns false when finished. */
    public interface FxSequence {
        boolean tick();
    }

    public static boolean usable() {
        return godlike || !GodlikeConfig.COMMON.requireAscension.get();
    }

    public static int dashDistance() {
        if (dashDistance < 0) {
            try {
                dashDistance = GodlikeConfig.CLIENT.dashDistance.get();
            } catch (Exception e) {
                dashDistance = 32;
            }
        }
        return dashDistance;
    }

    public static void shake(float strength, int ticks) {
        if (!GodlikeConfig.CLIENT.cameraShake.get()) return;
        if (strength > shakeStrength || shakeTicks <= 0) {
            shakeStrength = strength;
            shakeTicks = ticks;
            shakeMax = Math.max(1, ticks);
        }
    }

    public static void flash(float strength) {
        if (!GodlikeConfig.CLIENT.screenFlash.get()) return;
        flash = Math.max(flash, Math.min(1.0f, strength));
    }

    public static void tick() {
        clientTicks++;
        for (int i = 0; i < cooldown.length; i++) {
            if (cooldown[i] > 0) cooldown[i]--;
        }
        if (laserCharge >= 0) laserCharge++;
        if (barrageCharge >= 0) barrageCharge++;
        if (timeStopTicks > 0) timeStopTicks--;
        if (flash > 0) flash = Math.max(0, flash - 0.045f);
        if (shakeTicks > 0) shakeTicks--;

        Iterator<Map.Entry<Integer, RemoteState>> it = REMOTE.entrySet().iterator();
        while (it.hasNext()) {
            if (clientTicks - it.next().getValue().lastUpdate > 600) it.remove();
        }
        Iterator<FxSequence> seq = SEQUENCES.iterator();
        while (seq.hasNext()) {
            boolean alive;
            try {
                alive = seq.next().tick();
            } catch (Exception e) {
                alive = false;
            }
            if (!alive) seq.remove();
        }
    }

    public static void reset() {
        for (int i = 0; i < cooldown.length; i++) {
            cooldown[i] = 0;
            cooldownMax[i] = 1;
        }
        laserCharge = -1;
        laserKeyHeld = false;
        barrageCharge = -1;
        barrageKeyHeld = false;
        orbsAlive = false;
        timeStopTicks = 0;
        TimeFreezeClient.reset();
        aiming = false;
        aimTicks = 0;
        aimTarget = null;
        flash = 0;
        shakeTicks = 0;
        synced = false;
        REMOTE.clear();
        SEQUENCES.clear();
        BeamRenderer.clear();
        DashController.reset();
    }
}
