package com.godlikealien.client.render;

import com.godlikealien.GodlikeAlien;
import com.godlikealien.client.BeamRenderer;
import com.godlikealien.client.GodlikeFx;
import com.godlikealien.entity.UnstableCoreEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Pulsing orb with rotating energy rings. All geometry is procedural, additive and unlit. */
public class UnstableCoreRenderer extends EntityRenderer<UnstableCoreEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GodlikeAlien.MODID, "textures/misc/orb.png");

    public UnstableCoreRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0f;
    }

    @Override
    public boolean shouldRender(UnstableCoreEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        return frustum.isVisible(entity.getBoundingBox().inflate(6.0));
    }

    @Override
    public void render(UnstableCoreEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
        float progress = entity.getProgress(partialTick);
        float time = entity.tickCount + partialTick;
        float pulse = 0.5f + 0.5f * Mth.sin(time * (0.25f + progress * 1.4f));
        float[] hot = progress > 0.7f ? GodlikeFx.MAGENTA : GodlikeFx.CYAN;

        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());
        poseStack.pushPose();
        poseStack.translate(0.0, 0.6, 0.0);

        // rings in entity space (rotating)
        Matrix4f m = poseStack.last().pose();
        Vec3 c = Vec3.ZERO;
        float ringR = 1.0f + 0.9f * progress + 0.15f * pulse;
        BeamRenderer.ring3d(vc, m, c, new Vec3(0, 1, 0), ringR, 0.05f + 0.03f * progress, hot, 0.9f, time * 0.12f);
        BeamRenderer.ring3d(vc, m, c, new Vec3(1, 0.3, 0).normalize(), ringR * 0.8f, 0.04f, GodlikeFx.VIOLET, 0.8f, -time * 0.17f);
        BeamRenderer.ring3d(vc, m, c, new Vec3(0.2, 0.4, 1).normalize(), ringR * 0.65f, 0.035f, GodlikeFx.WHITE, 0.7f, time * 0.23f);

        // camera-facing orb
        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        Matrix4f bm = poseStack.last().pose();
        float core = 0.22f + 0.1f * pulse + 0.1f * progress;
        flatDisc(vc, bm, core, GodlikeFx.WHITE, 1.0f);
        flatDisc(vc, bm, core * 2.4f, hot, 0.7f);
        flatDisc(vc, bm, core * 5.0f + 0.4f * pulse, GodlikeFx.VIOLET, 0.3f);
        poseStack.popPose();

        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
    }

    /** Disc in the local XY plane (used after applying the camera orientation). */
    private static void flatDisc(VertexConsumer vc, Matrix4f m, float radius, float[] col, float alpha) {
        int n = 20;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n;
            double a1 = (i + 1) * Math.PI * 2 / n;
            float x0 = (float) (Math.cos(a0) * radius), y0 = (float) (Math.sin(a0) * radius);
            float x1 = (float) (Math.cos(a1) * radius), y1 = (float) (Math.sin(a1) * radius);
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, x0, y0, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x1, y1, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x1, y1, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x0, y0, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
        }
    }

    @Override
    public ResourceLocation getTextureLocation(UnstableCoreEntity entity) {
        return TEXTURE;
    }
}
