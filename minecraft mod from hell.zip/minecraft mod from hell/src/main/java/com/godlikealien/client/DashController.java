package com.godlikealien.client;

import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.AbilityActionPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.util.BlockBreaker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Client side of the Lightspeed Dash: path preview while aiming, and the actual movement
 * (player movement is client-authoritative, the server carves the tunnel and hits things).
 */
public final class DashController {
    private static boolean active;
    private static Vec3 origin;
    private static Vec3 end;
    private static Vec3 dir = Vec3.ZERO;
    private static int totalTicks;
    private static int tick;
    private static boolean restoreNoPhysics;

    private DashController() {}

    public static boolean isActive() {
        return active;
    }

    public static void reset() {
        active = false;
        tick = 0;
    }

    /** Computes where a dash of the given distance would end (used for the preview and the launch). */
    public static Vec3 computeTarget(LocalPlayer player, int distance) {
        Level level = player.level();
        Vec3 start = player.position();
        Vec3 look = player.getLookAngle().normalize();
        Vec3 eyeStart = start.add(0, 0.9, 0);
        Vec3 target;
        if (ClientState.smashAllowed && GodlikeConfig.COMMON.dashSmashesBlocks.get()) {
            target = marchUnbreakable(level, eyeStart, look, distance).subtract(0, 0.9, 0);
            ClientState.aimBlocked = target.distanceTo(start) < distance - 1.0;
        } else {
            Vec3 farEnd = eyeStart.add(look.scale(distance));
            BlockHitResult hit = level.clip(new ClipContext(eyeStart, farEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (hit.getType() == HitResult.Type.BLOCK) {
                double d = Math.max(0.0, hit.getLocation().distanceTo(eyeStart) - 1.2);
                target = start.add(look.scale(d));
                ClientState.aimBlocked = true;
            } else {
                target = farEnd.subtract(0, 0.9, 0);
                ClientState.aimBlocked = false;
            }
        }
        // stay inside the world
        double minY = level.getMinBuildHeight() + 1.0;
        double maxY = level.getMaxBuildHeight() - 3.0;
        if (target.y < minY || target.y > maxY) {
            double cy = Mth.clamp(target.y, minY, maxY);
            target = new Vec3(target.x, cy, target.z);
        }
        return target;
    }

    private static Vec3 marchUnbreakable(Level level, Vec3 origin, Vec3 dir, double range) {
        double step = 0.5;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (double t = 0; t <= range; t += step) {
            Vec3 p = origin.add(dir.scale(t));
            pos.set(Mth.floor(p.x), Mth.floor(p.y), Mth.floor(p.z));
            if (pos.getY() < level.getMinBuildHeight() || pos.getY() >= level.getMaxBuildHeight()) {
                return origin.add(dir.scale(Math.max(0, t - step)));
            }
            BlockState state = level.getBlockState(pos);
            if (!state.isAir() && !BlockBreaker.canBreak(state) && !state.getCollisionShape(level, pos).isEmpty()) {
                return origin.add(dir.scale(Math.max(0, t - 1.5)));
            }
        }
        return origin.add(dir.scale(range));
    }

    /** Fires the dash at the given distance. */
    public static void launch(Minecraft mc, int distance) {
        LocalPlayer player = mc.player;
        if (player == null || active) return;
        Vec3 start = player.position();
        Vec3 target = computeTarget(player, distance);
        double len = target.distanceTo(start);
        if (len < 1.0) {
            GodlikeFx.uiSound(SoundEvents.BEACON_DEACTIVATE, 0.6f, 1.6f);
            return;
        }
        GodlikeNetwork.sendToServer(new AbilityActionPacket(AbilityActionPacket.ABILITY_DASH, AbilityActionPacket.ACTION_PRESS, target, distance));

        double blocksPerTick = GodlikeConfig.COMMON.dashBlocksPerTick.get();
        active = true;
        origin = start;
        end = target;
        dir = target.subtract(start).normalize();
        totalTicks = Math.max(1, (int) Math.ceil(len / blocksPerTick));
        tick = 0;
        restoreNoPhysics = player.noPhysics;
        player.noPhysics = true;
        player.setDeltaMovement(Vec3.ZERO);
        ClientState.cooldown[GodlikeAbilities.CD_DASH] = GodlikeConfig.COMMON.dashCooldownTicks.get();
        ClientState.cooldownMax[GodlikeAbilities.CD_DASH] = Math.max(1, ClientState.cooldown[GodlikeAbilities.CD_DASH]);
        ClientState.shake(1.5f, 6);
    }

    public static void tick(Minecraft mc) {
        if (!active) return;
        LocalPlayer player = mc.player;
        if (player == null || !player.isAlive()) {
            active = false;
            return;
        }
        tick++;
        double t = Math.min(1.0, tick / (double) totalTicks);
        Vec3 pos = origin.lerp(end, t);
        player.setPos(pos.x, pos.y, pos.z);
        player.setDeltaMovement(dir.scale(0.05));
        player.fallDistance = 0;
        if (tick >= totalTicks) {
            active = false;
            player.noPhysics = restoreNoPhysics;
            player.setPos(end.x, end.y, end.z);
            player.setDeltaMovement(dir.scale(0.2));
        }
    }
}
