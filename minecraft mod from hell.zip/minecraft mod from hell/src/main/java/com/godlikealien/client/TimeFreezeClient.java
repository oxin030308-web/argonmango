package com.godlikealien.client;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.server.TimeFreeze;
import com.godlikealien.state.GodlikeState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Client view of Chaos Control: which entities are frozen (tick cancelling, position locks, shimmer), whether the
 * local player is inside a stopped-time bubble (post effect + tint) or frozen by someone else (input lock).
 */
public final class TimeFreezeClient {
    private static final ResourceLocation DESATURATE = new ResourceLocation("shaders/post/desaturate.json");
    /** Client-side pins for non-living entities (and the local player when frozen), so nothing drifts between server updates. */
    private static final Map<Integer, Vec3> LOCKS = new HashMap<>();
    private static boolean postEffectActive;
    public static boolean inBubble;
    public static boolean frozenByOther;

    private TimeFreezeClient() {}

    public static void install() {
        TimeFreeze.CLIENT_FROZEN = TimeFreezeClient::isFrozen;
    }

    private static boolean isFreezer(Minecraft mc, Entity e) {
        if (e == mc.player) return ClientState.timeStopTicks > 0;
        ClientState.RemoteState rs = ClientState.REMOTE.get(e.getId());
        return rs != null && (rs.flags & GodlikeState.FLAG_TIMESTOP) != 0;
    }

    public static boolean anyBubble() {
        if (ClientState.timeStopTicks > 0) return true;
        for (ClientState.RemoteState rs : ClientState.REMOTE.values()) {
            if ((rs.flags & GodlikeState.FLAG_TIMESTOP) != 0) return true;
        }
        return false;
    }

    /** Is this entity inside somebody's stopped time (client view)? */
    public static boolean isFrozen(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (e == null || mc.level == null || mc.player == null) return false;
        if (e.isSpectator()) return false;
        if (e instanceof Player && isFreezer(mc, e)) return false;
        if (e instanceof Player && !GodlikeConfig.COMMON.chaosFreezesPlayers.get()) return false;
        for (Entity passenger : e.getPassengers()) {
            if (passenger instanceof Player && isFreezer(mc, passenger)) return false;
        }
        double r = GodlikeConfig.COMMON.chaosRadius.get();
        double r2 = r * r;
        if (ClientState.timeStopTicks > 0 && e != mc.player && mc.player.distanceToSqr(e) <= r2) return true;
        for (Map.Entry<Integer, ClientState.RemoteState> en : ClientState.REMOTE.entrySet()) {
            if ((en.getValue().flags & GodlikeState.FLAG_TIMESTOP) == 0) continue;
            Entity freezer = mc.level.getEntity(en.getKey());
            if (freezer == null || freezer == e) continue;
            if (freezer.distanceToSqr(e) <= r2) return true;
        }
        return false;
    }

    /** Is the local player inside any bubble (including its own)? */
    private static boolean computeInBubble(Minecraft mc) {
        if (ClientState.timeStopTicks > 0) return true;
        double r = GodlikeConfig.COMMON.chaosRadius.get();
        for (Map.Entry<Integer, ClientState.RemoteState> en : ClientState.REMOTE.entrySet()) {
            if ((en.getValue().flags & GodlikeState.FLAG_TIMESTOP) == 0) continue;
            Entity freezer = mc.level.getEntity(en.getKey());
            if (freezer != null && freezer.distanceToSqr(mc.player) <= r * r) return true;
        }
        return false;
    }

    /** Runs at the END of every client tick (after all entities, including the local player, have ticked). */
    public static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) {
            reset();
            return;
        }
        boolean any = anyBubble();
        inBubble = any && computeInBubble(mc);
        frozenByOther = any && ClientState.timeStopTicks <= 0 && isFrozen(mc.player);
        updatePostEffect(mc, inBubble);
        if (any) {
            pinEntities(mc);
        } else if (!LOCKS.isEmpty()) {
            LOCKS.clear();
        }
        if (inBubble) {
            GodlikeFx.timeDustTick(mc.player.position());
            if (ClientState.clientTicks % 3 == 0) {
                Vec3 c = mc.player.position();
                AABB box = new AABB(c, c).inflate(28.0);
                for (Entity e : mc.level.getEntities(mc.player, box, ent -> ent instanceof LivingEntity && ent.isAlive())) {
                    if (isFrozen(e)) GodlikeFx.frozenShimmer(e);
                }
            }
        }
    }

    /**
     * Non-living entities keep ticking on the client (there is no event to stop them), so they are pulled back to
     * where they froze every tick. A jump larger than one tick of physics means the server corrected the position:
     * the lock then moves with it instead of fighting it.
     */
    private static void pinEntities(Minecraft mc) {
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.level.entitiesForRendering()) {
            boolean local = e == mc.player;
            if (e instanceof LivingEntity && !local) continue;   // living: tick cancelled; other players: server-driven
            if (local ? !frozenByOther : !isFrozen(e)) continue;
            Vec3 now = e.position();
            Vec3 lock = LOCKS.get(e.getId());
            if (lock == null || now.distanceToSqr(lock) > 0.35 * 0.35) {
                lock = now;
                LOCKS.put(e.getId(), lock);
            } else {
                e.setPos(lock.x, lock.y, lock.z);
            }
            e.setDeltaMovement(Vec3.ZERO);
            e.fallDistance = 0;
            seen.add(e.getId());
        }
        LOCKS.keySet().retainAll(seen);
    }

    private static void updatePostEffect(Minecraft mc, boolean want) {
        boolean allowed = true;
        try {
            allowed = GodlikeConfig.CLIENT.chaosDesaturate.get();
        } catch (Exception ignored) {
        }
        want = want && allowed;
        try {
            PostChain current = mc.gameRenderer.currentEffect();
            boolean ours = current != null && DESATURATE.toString().equals(current.getName());
            if (want) {
                if (current == null) {
                    mc.gameRenderer.loadEffect(DESATURATE);
                    postEffectActive = true;
                }
            } else if (postEffectActive) {
                if (ours) mc.gameRenderer.shutdownEffect();
                postEffectActive = false;
            }
        } catch (Exception e) {
            postEffectActive = false;
        }
    }

    public static void reset() {
        inBubble = false;
        frozenByOther = false;
        LOCKS.clear();
        if (postEffectActive) {
            try {
                Minecraft mc = Minecraft.getInstance();
                PostChain current = mc.gameRenderer.currentEffect();
                if (current != null && DESATURATE.toString().equals(current.getName())) mc.gameRenderer.shutdownEffect();
            } catch (Exception ignored) {
            }
            postEffectActive = false;
        }
    }
}
