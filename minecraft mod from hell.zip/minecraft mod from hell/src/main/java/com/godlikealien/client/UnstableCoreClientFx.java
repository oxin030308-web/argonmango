package com.godlikealien.client;

import com.godlikealien.entity.UnstableCoreEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** Per-tick client particles for the unstable core (kept out of the entity class so servers never load client code). */
public final class UnstableCoreClientFx {
    private UnstableCoreClientFx() {}

    public static void tick(UnstableCoreEntity core) {
        float progress = core.getProgress(0);
        Vec3 c = core.position().add(0, 0.6, 0);
        int t = core.tickCount;
        float speed = 0.08f + progress * 0.35f;
        // orbiting sparks
        for (int k = 0; k < 3; k++) {
            double ang = t * speed + k * (Math.PI * 2 / 3);
            double r = 1.1 + 0.6 * progress + 0.2 * Math.sin(t * 0.2 + k);
            double tilt = Math.sin(t * 0.05 + k) * 0.6;
            Vec3 p = c.add(Math.cos(ang) * r, Math.sin(ang * 1.7 + k) * tilt, Math.sin(ang) * r);
            GodlikeFx.spark(p, Vec3.ZERO, k == 0 ? GodlikeFx.WHITE : (k == 1 ? GodlikeFx.CYAN : GodlikeFx.VIOLET), 0.12f + 0.05f * progress, 8, 0.9f, 0.0f, false);
        }
        // energy spiralling inward
        if (t % 2 == 0) {
            double ang = Math.random() * Math.PI * 2;
            double r = 3.0 + Math.random() * 3.0;
            double y = (Math.random() - 0.5) * 3.0;
            Vec3 p = c.add(Math.cos(ang) * r, y, Math.sin(ang) * r);
            Vec3 v = c.subtract(p).scale(1.0 / 12.0);
            GodlikeFx.spark(p, v, progress > 0.7f ? GodlikeFx.MAGENTA : GodlikeFx.CYAN, 0.1f, 12, 1.0f, 0.0f, false);
        }
        // core glow pulse
        float pulse = 0.5f + 0.5f * Mth.sin(t * (0.3f + progress * 1.2f));
        if (t % 3 == 0) {
            GodlikeFx.glow(c, Vec3.ZERO, progress > 0.7f ? GodlikeFx.MAGENTA : GodlikeFx.CYAN, 1.2f + 1.5f * progress + 0.5f * pulse, 0.2f, 6, 1.0f);
        }
        // ground ring
        if (t % Math.max(4, 24 - (int) (progress * 20)) == 0) {
            GodlikeFx.ring(core.position().add(0, 0.05, 0), progress > 0.7f ? GodlikeFx.MAGENTA : GodlikeFx.VIOLET, 0.3f, 3.0f + 5.0f * progress, 14, 0.8f);
        }
    }
}
