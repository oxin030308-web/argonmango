package com.godlikealien.client.render;

import com.godlikealien.GodlikeAlien;
import com.godlikealien.client.BeamRenderer;
import com.godlikealien.client.GodlikeFx;
import com.godlikealien.entity.CosmicOrbEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Glowing orb with two spinning rings; bomblets are smaller and gold. */
public class CosmicOrbRenderer extends EntityRenderer<CosmicOrbEntity> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(GodlikeAlien.MODID, "textures/misc/orb.png");

    public CosmicOrbRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.0f;
    }

    @Override
    public boolean shouldRender(CosmicOrbEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        return frustum.isVisible(entity.getBoundingBox().inflate(3.0));
    }

    @Override
    public void render(CosmicOrbEntity entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource buffers, int packedLight) {
        float power = entity.getPower();
        int tier = entity.getTier();
        float time = entity.tickCount + partialTick;
        float pulse = 0.5f + 0.5f * Mth.sin(time * 0.7f);
        float base = tier == 0 ? 0.16f + 0.2f * power : 0.09f;
        float[] hot = tier == 0 ? GodlikeFx.CYAN : GodlikeFx.GOLD;
        float[] halo = tier == 0 ? GodlikeFx.VIOLET : GodlikeFx.ORANGE;

        VertexConsumer vc = buffers.getBuffer(RenderType.lightning());
        poseStack.pushPose();
        poseStack.translate(0.0, entity.getBbHeight() * 0.5, 0.0);

        Matrix4f m = poseStack.last().pose();
        if (tier == 0) {
            BeamRenderer.ring3d(vc, m, Vec3.ZERO, new Vec3(0, 1, 0), base * 2.3f, 0.03f, hot, 0.85f, time * 0.35f);
            BeamRenderer.ring3d(vc, m, Vec3.ZERO, new Vec3(1, 0.4, 0.3).normalize(), base * 1.9f, 0.025f, GodlikeFx.WHITE, 0.6f, -time * 0.45f);
        }

        poseStack.pushPose();
        poseStack.mulPose(this.entityRenderDispatcher.cameraOrientation());
        Matrix4f bm = poseStack.last().pose();
        GlowGeometry.flatDisc(vc, bm, base * (0.85f + 0.2f * pulse), GodlikeFx.WHITE, 1.0f);
        GlowGeometry.flatDisc(vc, bm, base * 2.1f, hot, 0.75f);
        GlowGeometry.flatDisc(vc, bm, base * 4.2f + 0.08f * pulse, halo, 0.3f);
        poseStack.popPose();

        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffers, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(CosmicOrbEntity entity) {
        return TEXTURE;
    }
}
