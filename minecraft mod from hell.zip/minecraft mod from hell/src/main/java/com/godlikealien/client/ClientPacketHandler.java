package com.godlikealien.client;

import com.godlikealien.network.FxPacket;
import com.godlikealien.network.StateSyncPacket;
import com.godlikealien.state.GodlikeState;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Client-side packet handling (only ever loaded on the client). */
public final class ClientPacketHandler {
    private ClientPacketHandler() {}

    public static void handleStateSync(StateSyncPacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (msg.entityId == mc.player.getId()) {
            for (int i = 0; i < GodlikeState.COOLDOWN_SLOTS && i < msg.cooldown.length; i++) {
                ClientState.cooldown[i] = msg.cooldown[i];
                ClientState.cooldownMax[i] = Math.max(1, msg.cooldownMax[i]);
            }
            boolean wasCharging = ClientState.laserCharge >= 0;
            ClientState.laserCharge = msg.laserCharge;
            if (wasCharging && msg.laserCharge < 0) {
                ClientState.laserKeyHeld = false;
            }
            boolean wasBarrage = ClientState.barrageCharge >= 0;
            ClientState.barrageCharge = msg.barrageCharge;
            if (wasBarrage && msg.barrageCharge < 0) {
                ClientState.barrageKeyHeld = false;
            }
            ClientState.orbsAlive = (msg.flags & GodlikeState.FLAG_ORBS) != 0;
            ClientState.timeStopTicks = msg.timeStopTicks;
            ClientState.godlike = (msg.flags & GodlikeState.FLAG_GODLIKE) != 0;
            ClientState.resistance = (msg.flags & GodlikeState.FLAG_RESISTANCE) != 0;
            ClientState.sonic = (msg.flags & GodlikeState.FLAG_SONIC) != 0;
            ClientState.smashAllowed = (msg.flags & GodlikeState.FLAG_SMASH) != 0;
            ClientState.synced = true;
        } else {
            ClientState.RemoteState rs = ClientState.REMOTE.computeIfAbsent(msg.entityId, k -> new ClientState.RemoteState());
            rs.laserCharge = msg.laserCharge;
            rs.barrageCharge = msg.barrageCharge;
            rs.flags = msg.flags;
            rs.lastUpdate = ClientState.clientTicks;
        }
    }

    public static void handleFx(FxPacket msg) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        double dist = mc.player.position().distanceTo(msg.a);
        switch (msg.type) {
            case FxPacket.BEAM -> {
                BeamRenderer.addBeam(msg.a, msg.b, msg.power);
                GodlikeFx.beam(msg.a, msg.b, msg.power);
                ClientState.shake(1.2f + msg.power, 10);
            }
            case FxPacket.LASER_IMPACT -> {
                GodlikeFx.laserImpact(msg.a, msg.b, msg.power);
                if (dist < 60) ClientState.shake((float) (3.0 * (1 - dist / 60.0)), 14);
            }
            case FxPacket.MEGA_EXPLOSION -> {
                float radius = msg.power;
                GodlikeFx.megaExplosion(msg.a, radius);
                double range = radius * 6.0;
                if (dist < range) {
                    float k = (float) (1.0 - dist / range);
                    ClientState.shake(2.0f + 10.0f * k, 40);
                    ClientState.flash(0.35f + 0.65f * k);
                }
            }
            case FxPacket.PUNCH -> {
                GodlikeFx.punch(msg.a, msg.b, msg.power, msg.extra != 0);
                if (dist < 40) ClientState.shake((float) (4.0 * (1 - dist / 40.0)), 12);
            }
            case FxPacket.DASH_STREAK -> {
                BeamRenderer.addStreak(msg.a, msg.b, msg.extra);
                GodlikeFx.dashStreak(msg.a, msg.b);
                if (dist < 30) ClientState.shake(1.0f, 6);
            }
            case FxPacket.ASCEND -> GodlikeFx.ascend(msg.a);
            case FxPacket.LASER_FIZZLE -> GodlikeFx.laserFizzle(msg.a, msg.b);
            case FxPacket.SHIELD -> GodlikeFx.shield(msg.a, msg.power);
            case FxPacket.CORE_WARNING -> GodlikeFx.coreWarning(msg.a, msg.extra, msg.power);
            case FxPacket.ORB_EXPLOSION -> {
                GodlikeFx.orbExplosion(msg.a, msg.power, msg.extra);
                double reach = msg.extra == 0 ? 24.0 : 12.0;
                if (dist < reach) ClientState.shake((float) ((msg.extra == 0 ? 1.6 : 0.7) * (1 - dist / reach)), 8);
            }
            case FxPacket.BARRAGE_LAUNCH -> GodlikeFx.barrageLaunch(msg.a, msg.b, msg.extra);
            case FxPacket.CHAOS_START -> {
                GodlikeFx.chaosStart(msg.a, msg.power);
                if (dist < msg.power) {
                    ClientState.flash(0.55f);
                    ClientState.shake(1.2f, 8);
                }
            }
            case FxPacket.CHAOS_END -> {
                GodlikeFx.chaosEnd(msg.a, msg.power);
                if (dist < msg.power) {
                    ClientState.flash(0.25f);
                    ClientState.shake(0.8f, 6);
                }
            }
            default -> {}
        }
    }

    static Vec3 vec(double x, double y, double z) {
        return new Vec3(x, y, z);
    }
}
