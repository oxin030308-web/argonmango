package com.godlikealien.client;

import com.baranhan123.viltrumitecore.client.AbilityInputManager;
import com.baranhan123.viltrumitecore.client.gui.RaceSelectionScreen;
import com.baranhan123.viltrumitecore.util.ViltrumiteAbilityUser;
import com.baranhan123.viltrumitecore.util.ViltrumiteCorePlayer;
import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeAlien;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.network.AbilityActionPacket;
import com.godlikealien.network.AscendPacket;
import com.godlikealien.network.GodlikeNetwork;
import com.godlikealien.server.TimeFreeze;
import com.godlikealien.server.Passives;
import com.godlikealien.state.GodlikeGate;
import com.godlikealien.state.GodlikeState;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.Input;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

/** All Forge-bus client events: input, per-tick visuals, HUD, camera shake, world rendering, race screen hook. */
@Mod.EventBusSubscriber(modid = GodlikeAlien.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class GodlikeClientEvents {
    private static boolean hudErrorLogged;
    private static boolean levelErrorLogged;

    private GodlikeClientEvents() {}

    // ------------------------------------------------------------ ticking & input

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            if (ClientState.synced || ClientState.aiming || ClientState.laserKeyHeld) ClientState.reset();
            return;
        }
        if (mc.isPaused()) return;
        ClientState.tick();
        BeamRenderer.tick();
        DashController.tick(mc);
        try {
            TimeFreezeClient.tick(mc);
            handleInput(mc, mc.player);
            ambientVisuals(mc, mc.player);
        } catch (Exception e) {
            GodlikeAlien.LOGGER.error("[Godlike Alien] client tick error", e);
        }
    }

    // ------------------------------------------------------------ chaos control (client side of frozen time)

    /** Frozen entities stop animating on the client too (their tick is skipped); the local player is never skipped. */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onLivingTickClient(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (!entity.level().isClientSide) return;
        Minecraft mc = Minecraft.getInstance();
        if (entity == mc.player || entity.isDeadOrDying()) return;
        if (TimeFreezeClient.anyBubble() && TimeFreezeClient.isFrozen(entity)) {
            event.setCanceled(true);
            TimeFreeze.holdLiving(entity);
        }
    }

    /** A player frozen by somebody else's Chaos Control cannot move. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (!TimeFreezeClient.frozenByOther) return;
        Input input = event.getInput();
        input.forwardImpulse = 0;
        input.leftImpulse = 0;
        input.up = false;
        input.down = false;
        input.left = false;
        input.right = false;
        input.jumping = false;
        input.shiftKeyDown = false;
    }

    /** ...nor attack or use anything. */
    @SubscribeEvent
    public static void onInteractionKey(InputEvent.InteractionKeyMappingTriggered event) {
        if (!TimeFreezeClient.frozenByOther) return;
        event.setSwingHand(false);
        event.setCanceled(true);
    }

    private static void handleInput(Minecraft mc, LocalPlayer player) {
        if (mc.screen != null) {
            if (ClientState.aiming) {
                ClientState.aiming = false;
                ClientState.aimTarget = null;
            }
            if (ClientState.laserKeyHeld) {
                ClientState.laserKeyHeld = false;
                GodlikeNetwork.sendToServer(AbilityActionPacket.release(AbilityActionPacket.ABILITY_LASER));
            }
            if (ClientState.barrageKeyHeld) {
                ClientState.barrageKeyHeld = false;
                GodlikeNetwork.sendToServer(AbilityActionPacket.release(AbilityActionPacket.ABILITY_BARRAGE));
            }
            return;
        }
        boolean usable = ClientState.usable();
        boolean isViltrumite = player instanceof ViltrumiteCorePlayer core && core.isViltrumite();
        boolean canAct = usable && isViltrumite && GodlikeGate.canAct(player) && !DashController.isActive();

        // ---- Super Laser: hold to charge, release to fire
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.LASER)) {
            if (!ClientState.laserKeyHeld && canAct && ClientState.cooldown[GodlikeAbilities.CD_LASER] == 0 && ClientState.laserCharge < 0) {
                ClientState.laserKeyHeld = true;
                ClientState.laserCharge = 0;
                GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_LASER));
            } else if (!ClientState.laserKeyHeld) {
                deny();
            }
        }
        if (ClientState.laserKeyHeld && !AbilityInputManager.isAbilityKeyDown(player, GodlikeAbilities.LASER)) {
            ClientState.laserKeyHeld = false;
            GodlikeNetwork.sendToServer(AbilityActionPacket.release(AbilityActionPacket.ABILITY_LASER));
        }

        // ---- Cosmic Barrage: hold to charge, release to launch; press again while orbs fly to detonate them
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.BARRAGE)) {
            if (ClientState.orbsAlive && ClientState.barrageCharge < 0 && usable && isViltrumite) {
                GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_BARRAGE));
                GodlikeFx.uiSound(SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.9f);
            } else if (!ClientState.barrageKeyHeld && canAct && ClientState.cooldown[GodlikeAbilities.CD_BARRAGE] == 0 && ClientState.barrageCharge < 0) {
                ClientState.barrageKeyHeld = true;
                ClientState.barrageCharge = 0;
                GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_BARRAGE));
            } else if (!ClientState.barrageKeyHeld) {
                deny();
            }
        }
        if (ClientState.barrageKeyHeld && !AbilityInputManager.isAbilityKeyDown(player, GodlikeAbilities.BARRAGE)) {
            ClientState.barrageKeyHeld = false;
            GodlikeNetwork.sendToServer(AbilityActionPacket.release(AbilityActionPacket.ABILITY_BARRAGE));
        }

        // ---- Chaos Control: press to stop time, press again to resume
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.CHAOS)) {
            if (usable && isViltrumite && (ClientState.timeStopTicks > 0 || ClientState.cooldown[GodlikeAbilities.CD_CHAOS] == 0)) {
                GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_CHAOS));
            } else {
                deny();
            }
        }

        // ---- Lightspeed Dash: hold to aim (scroll = distance), release to go
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.DASH)) {
            if (!ClientState.aiming && canAct && ClientState.cooldown[GodlikeAbilities.CD_DASH] == 0) {
                ClientState.aiming = true;
                ClientState.aimTicks = 0;
                GodlikeFx.uiSound(SoundEvents.BEACON_POWER_SELECT, 0.5f, 1.7f);
            } else if (!ClientState.aiming) {
                deny();
            }
        }
        if (ClientState.aiming) {
            ClientState.aimTicks++;
            ClientState.aimTarget = DashController.computeTarget(player, ClientState.dashDistance());
            GodlikeFx.aimMarkerTick(ClientState.aimTarget, ClientState.aimBlocked);
            if (!AbilityInputManager.isAbilityKeyDown(player, GodlikeAbilities.DASH)) {
                ClientState.aiming = false;
                ClientState.aimTarget = null;
                saveDashDistance();
                DashController.launch(mc, ClientState.dashDistance());
            }
        }

        // ---- Godlike Punch
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.PUNCH)) {
            if (canAct && ClientState.cooldown[GodlikeAbilities.CD_PUNCH] == 0
                    && player instanceof ViltrumiteCorePlayer core && core.getPunchTicks() == 0) {
                boolean left = mc.level.random.nextBoolean();
                core.setLeftArmPunch(left);
                core.setPunchTicks(20);
                int cd = GodlikeConfig.COMMON.punchCooldownTicks.get();
                ClientState.cooldown[GodlikeAbilities.CD_PUNCH] = cd;
                ClientState.cooldownMax[GodlikeAbilities.CD_PUNCH] = Math.max(1, cd);
                GodlikeNetwork.sendToServer(new AbilityActionPacket(AbilityActionPacket.ABILITY_PUNCH, AbilityActionPacket.ACTION_PRESS, Vec3.ZERO, left ? 1 : 0));
            } else {
                deny();
            }
        }

        // ---- toggles
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.RESISTANCE)) {
            if (usable && isViltrumite) GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_RESISTANCE));
            else deny();
        }
        if (AbilityInputManager.consumeAbilityKeyPress(player, GodlikeAbilities.SONIC_FLIGHT)) {
            if (usable && isViltrumite) GodlikeNetwork.sendToServer(AbilityActionPacket.press(AbilityActionPacket.ABILITY_SONIC));
            else deny();
        }
    }

    private static void deny() {
        GodlikeFx.uiSound(SoundEvents.BEACON_DEACTIVATE, 0.35f, 1.9f);
    }

    private static void saveDashDistance() {
        try {
            int d = ClientState.dashDistance();
            if (GodlikeConfig.CLIENT.dashDistance.get() != d) {
                GodlikeConfig.CLIENT.dashDistance.set(d);
                GodlikeConfig.CLIENT_SPEC.save();
            }
        } catch (Exception ignored) {
        }
    }

    private static void ambientVisuals(Minecraft mc, LocalPlayer localPlayer) {
        boolean aura = GodlikeConfig.COMMON.godlikeAura.get();
        for (Player p : mc.level.players()) {
            if (p == localPlayer) {
                if (ClientState.laserCharge >= 0) GodlikeFx.chargeTick(p, ClientState.laserCharge, 0);
                if (ClientState.barrageCharge >= 0) GodlikeFx.barrageChargeTick(p, ClientState.barrageCharge);
                if (aura && ClientState.godlike) GodlikeFx.auraTick(p);
            } else {
                ClientState.RemoteState rs = ClientState.REMOTE.get(p.getId());
                if (rs == null) continue;
                if ((rs.flags & GodlikeState.FLAG_CHARGING) != 0) {
                    int charge = Math.max(0, rs.laserCharge) + (ClientState.clientTicks - rs.lastUpdate);
                    GodlikeFx.chargeTick(p, charge, 0);
                }
                if ((rs.flags & GodlikeState.FLAG_BARRAGE_CHARGING) != 0) {
                    int charge = Math.max(0, rs.barrageCharge) + (ClientState.clientTicks - rs.lastUpdate);
                    GodlikeFx.barrageChargeTick(p, charge);
                }
                if (aura && (rs.flags & GodlikeState.FLAG_GODLIKE) != 0) GodlikeFx.auraTick(p);
            }
        }
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.side != LogicalSide.CLIENT || event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        if (event.player != mc.player) return;
        // keep the light-speed dash clipping through blocks even if another mod resets noPhysics at tick head
        if (DashController.isActive()) event.player.noPhysics = true;
        if (!ClientState.usable()) return;
        if (!(event.player instanceof ViltrumiteCorePlayer core) || !core.isViltrumite()) return;
        Passives.tickSonicFlight(event.player, ClientState.sonic);
        if (ClientState.laserCharge >= 0 && !DashController.isActive()) {
            Vec3 v = event.player.getDeltaMovement();
            event.player.setDeltaMovement(v.x * 0.5, v.y * 0.7, v.z * 0.5);
        } else if (ClientState.barrageCharge >= 0 && !DashController.isActive()) {
            Vec3 v = event.player.getDeltaMovement();
            event.player.setDeltaMovement(v.x * 0.6, v.y * 0.8, v.z * 0.6);
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.aiming || mc.player == null || mc.screen != null) return;
        double delta = event.getScrollDelta();
        if (delta == 0) return;
        int step = Screen.hasShiftDown() ? 16 : 4;
        int max = GodlikeConfig.COMMON.dashMaxDistance.get();
        int nd = Mth.clamp(ClientState.dashDistance() + (delta > 0 ? step : -step), 4, max);
        if (nd != ClientState.dashDistance) {
            ClientState.dashDistance = nd;
            GodlikeFx.uiSound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.5f, 0.7f + 1.3f * nd / (float) max);
        }
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.reset();
    }

    // ------------------------------------------------------------ camera & rendering

    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (ClientState.shakeTicks <= 0) return;
        float t = ClientState.shakeTicks / (float) Math.max(1, ClientState.shakeMax);
        float s = ClientState.shakeStrength * t * t;
        double time = (System.nanoTime() % 1_000_000_000_000L) / 1.0e7;
        event.setPitch(event.getPitch() + (float) (Math.sin(time * 1.7) * s));
        event.setYaw(event.getYaw() + (float) (Math.cos(time * 2.3) * s));
        event.setRoll(event.getRoll() + (float) (Math.sin(time * 1.1) * s * 0.4));
    }

    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        try {
            BeamRenderer.render(event);
        } catch (Exception e) {
            if (!levelErrorLogged) {
                levelErrorLogged = true;
                GodlikeAlien.LOGGER.error("[Godlike Alien] world render error", e);
            }
        }
    }

    @SubscribeEvent
    public static void onRenderGui(RenderGuiEvent.Post event) {
        GuiGraphics g = event.getGuiGraphics();
        int w = event.getWindow().getGuiScaledWidth();
        int h = event.getWindow().getGuiScaledHeight();
        if (TimeFreezeClient.inBubble) {
            // cold, still air: blue tint + darker edges
            g.fill(0, 0, w, h, 0x1E9AC4FF);
            g.fillGradient(0, 0, w, h / 3, 0x70203050, 0x00000000);
            g.fillGradient(0, h - h / 3, w, h, 0x00000000, 0x70203050);
            if (TimeFreezeClient.frozenByOther) {
                float pulse = 0.5f + 0.5f * Mth.sin((ClientState.clientTicks + event.getPartialTick()) * 0.2f);
                int col = 0xFF000000 | (Mth.floor(0x80 + 0x7F * pulse) << 16) | (Mth.floor(0xC0 + 0x3F * pulse) << 8) | 0xFF;
                g.drawCenteredString(Minecraft.getInstance().font, "TIME IS FROZEN", w / 2, h / 2 - 30, col);
            }
        }
        if (ClientState.flash <= 0) return;
        int a = Mth.clamp((int) (ClientState.flash * 255), 0, 255);
        g.fill(0, 0, w, h, (a << 24) | 0xF0F8FF);
    }

    /**
     * ViltrumiteCore draws its ability hotbar at the very end of the GUI render (a mixin tail), so anything we
     * want on top of the icons has to be drawn after the whole GUI: the end of the render tick. We rebuild the
     * same GUI projection/model-view setup the game renderer uses.
     */
    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.screen != null || mc.options.hideGui || mc.noRender) return;
        if (!GodlikeHud.enabled()) return;
        if (!(mc.player instanceof ViltrumiteAbilityUser user)) return;
        if (!(mc.player instanceof ViltrumiteCorePlayer core) || !core.isViltrumite()) return;

        PoseStack mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.setIdentity();
        mv.translate(0.0f, 0.0f, 1000.0f - ForgeHooksClient.getGuiFarPlane());
        RenderSystem.applyModelViewMatrix();
        RenderSystem.disableDepthTest();
        GuiGraphics g = new GuiGraphics(mc, mc.renderBuffers().bufferSource());
        try {
            GodlikeHud.render(g, mc, user, event.renderTickTime);
        } catch (Exception e) {
            if (!hudErrorLogged) {
                hudErrorLogged = true;
                GodlikeAlien.LOGGER.error("[Godlike Alien] HUD render error", e);
            }
        }
        g.flush();
        RenderSystem.enableDepthTest();
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
    }

    // ------------------------------------------------------------ race screen

    @SubscribeEvent
    public static void onScreenInit(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof RaceSelectionScreen screen)) return;
        int cx = screen.width / 2;
        int cy = screen.height / 2;
        Button button = Button.builder(Component.literal("Ascend: GODLIKE ALIEN").withStyle(ChatFormatting.AQUA, ChatFormatting.BOLD), b -> {
            GodlikeNetwork.sendToServer(new AscendPacket());
            Minecraft.getInstance().setScreen(null);
        }).bounds(cx - 105, cy + 8, 210, 20)
                .tooltip(Tooltip.create(Component.literal(
                        "Become a Viltrumite with godlike power: the Super Laser, the Lightspeed Dash, the one-shot Godlike Punch, "
                                + "total invulnerability and speed-of-sound flight.")))
                .build();
        event.addListener(button);
    }
}
