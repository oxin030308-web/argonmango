package com.godlikealien.client.particle;

import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** A light streak stretched along a direction and turned towards the camera (light-speed trails, beam sparks). */
public class StreakParticle extends TextureSheetParticle {
    protected Vec3 axis = new Vec3(1, 0, 0);
    protected float length = 1.0f;
    protected float width = 0.15f;
    protected float startAlpha = 1.0f;
    protected float drag = 0.9f;

    protected StreakParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, SpriteSet sprites) {
        super(level, x, y, z, vx, vy, vz);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.pickSprite(sprites);
        this.hasPhysics = false;
        this.gravity = 0;
        this.lifetime = 12;
        this.setColor(0.7f, 0.95f, 1.0f);
        double l = Math.sqrt(vx * vx + vy * vy + vz * vz);
        if (l > 1.0E-4) this.axis = new Vec3(vx / l, vy / l, vz / l);
    }

    public StreakParticle setup(float r, float g, float b, Vec3 axis, float length, float width, int life, float alpha, float drag) {
        this.setColor(r, g, b);
        if (axis.lengthSqr() > 1.0E-6) this.axis = axis.normalize();
        this.length = length;
        this.width = width;
        this.lifetime = Math.max(1, life);
        this.startAlpha = alpha;
        this.alpha = alpha;
        this.drag = drag;
        return this;
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.move(this.xd, this.yd, this.zd);
        this.xd *= drag;
        this.yd *= drag;
        this.zd *= drag;
        float t = this.age / (float) this.lifetime;
        this.alpha = startAlpha * (1.0f - t * t);
    }

    @Override
    public void render(VertexConsumer consumer, Camera camera, float partialTick) {
        Vec3 cam = camera.getPosition();
        double px = Mth.lerp(partialTick, this.xo, this.x);
        double py = Mth.lerp(partialTick, this.yo, this.y);
        double pz = Mth.lerp(partialTick, this.zo, this.z);
        Vec3 center = new Vec3(px - cam.x, py - cam.y, pz - cam.z);
        Vec3 toCam = center.scale(-1);
        if (toCam.lengthSqr() < 1.0E-6) toCam = new Vec3(0, 1, 0);
        Vec3 side = axis.cross(toCam.normalize());
        if (side.lengthSqr() < 1.0E-6) side = new Vec3(0, 1, 0);
        side = side.normalize();
        float t = Mth.clamp((this.age + partialTick) / this.lifetime, 0.0f, 1.0f);
        float len = length * (0.4f + 0.6f * (1.0f - t)) * 0.5f;
        float w = width * (1.0f - 0.5f * t);
        Vec3 a = axis.scale(len);
        Vec3 s = side.scale(w);
        float al = Mth.clamp(this.alpha, 0.0f, 1.0f);
        float u0 = getU0(), u1 = getU1(), v0 = getV0(), v1 = getV1();
        int light = 0xF000F0;

        Vec3 p0 = center.subtract(a).subtract(s);
        Vec3 p1 = center.subtract(a).add(s);
        Vec3 p2 = center.add(a).add(s);
        Vec3 p3 = center.add(a).subtract(s);
        vertex(consumer, p0, u0, v0, al, light);
        vertex(consumer, p1, u0, v1, al, light);
        vertex(consumer, p2, u1, v1, al, light);
        vertex(consumer, p3, u1, v0, al, light);
        vertex(consumer, p3, u1, v0, al, light);
        vertex(consumer, p2, u1, v1, al, light);
        vertex(consumer, p1, u0, v1, al, light);
        vertex(consumer, p0, u0, v0, al, light);
    }

    private void vertex(VertexConsumer c, Vec3 p, float u, float v, float a, int light) {
        c.vertex(p.x, p.y, p.z).uv(u, v).color(rCol, gCol, bCol, a).uv2(light).endVertex();
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;
    }

    @Override
    public ParticleRenderType getRenderType() {
        return GodlikeParticleRenderTypes.ADDITIVE;
    }

    public static class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;

        public Provider(SpriteSet sprites) {
            this.sprites = sprites;
        }

        @Override
        public Particle createParticle(SimpleParticleType type, ClientLevel level, double x, double y, double z, double vx, double vy, double vz) {
            return new StreakParticle(level, x, y, z, vx, vy, vz, sprites);
        }
    }
}
