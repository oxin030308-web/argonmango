package com.godlikealien.client;

import com.godlikealien.entity.CosmicOrbEntity;

/** Per-tick client particles for a flying cosmic orb (kept out of the entity class so servers never load client code). */
public final class CosmicOrbClientFx {
    private CosmicOrbClientFx() {}

    public static void tick(CosmicOrbEntity orb) {
        GodlikeFx.orbTrail(orb.position().add(0, orb.getBbHeight() * 0.5, 0), orb.getDeltaMovement(), orb.getPower(), orb.getTier(), orb.tickCount);
    }
}
