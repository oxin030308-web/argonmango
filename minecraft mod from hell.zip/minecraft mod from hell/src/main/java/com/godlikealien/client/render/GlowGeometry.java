package com.godlikealien.client.render;

import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

/** Shared procedural glow shapes for entity renderers (drawn with RenderType.lightning(): position + colour, additive). */
public final class GlowGeometry {
    private GlowGeometry() {}

    /** Radial-gradient disc in the local XY plane (use after applying the camera orientation to billboard it). */
    public static void flatDisc(VertexConsumer vc, Matrix4f m, float radius, float[] col, float alpha) {
        int n = 20;
        for (int i = 0; i < n; i++) {
            double a0 = i * Math.PI * 2 / n;
            double a1 = (i + 1) * Math.PI * 2 / n;
            float x0 = (float) (Math.cos(a0) * radius), y0 = (float) (Math.sin(a0) * radius);
            float x1 = (float) (Math.cos(a1) * radius), y1 = (float) (Math.sin(a1) * radius);
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, x0, y0, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x1, y1, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x1, y1, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, x0, y0, 0).color(col[0], col[1], col[2], 0.0f).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
            vc.vertex(m, 0, 0, 0).color(col[0], col[1], col[2], alpha).endVertex();
        }
    }
}
