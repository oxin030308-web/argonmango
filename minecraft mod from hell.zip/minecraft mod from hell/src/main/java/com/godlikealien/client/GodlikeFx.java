package com.godlikealien.client;

import com.godlikealien.GodlikeConfig;
import com.godlikealien.client.particle.GlowParticle;
import com.godlikealien.client.particle.ShockRingParticle;
import com.godlikealien.client.particle.SparkParticle;
import com.godlikealien.client.particle.StreakParticle;
import com.godlikealien.particle.GodlikeParticles;
import com.godlikealien.util.GodlikeMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The godlike particle library. Everything here is client-side eye candy; gameplay never depends on it.
 * Colour language: white core, cyan energy, violet halo, gold for impacts.
 */
public final class GodlikeFx {
    private static final RandomSource RNG = RandomSource.create();

    // palette
    public static final float[] WHITE = {1.0f, 1.0f, 1.0f};
    public static final float[] CYAN = {0.35f, 0.95f, 1.0f};
    public static final float[] DEEP = {0.1f, 0.5f, 1.0f};
    public static final float[] VIOLET = {0.7f, 0.35f, 1.0f};
    public static final float[] MAGENTA = {1.0f, 0.4f, 0.9f};
    public static final float[] GOLD = {1.0f, 0.85f, 0.4f};
    public static final float[] ORANGE = {1.0f, 0.55f, 0.2f};

    private GodlikeFx() {}

    private static double density() {
        try {
            return GodlikeConfig.CLIENT.particleDensity.get();
        } catch (Exception e) {
            return 1.0;
        }
    }

    private static int count(int base) {
        return Math.max(1, (int) Math.round(base * density()));
    }

    private static float[] mix(float[] a, float[] b, float t) {
        return new float[]{Mth.lerp(t, a[0], b[0]), Mth.lerp(t, a[1], b[1]), Mth.lerp(t, a[2], b[2])};
    }

    private static Vec3 randomDir() {
        double u = RNG.nextDouble() * 2 - 1;
        double a = RNG.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(1 - u * u);
        return new Vec3(r * Math.cos(a), u, r * Math.sin(a));
    }

    // ------------------------------------------------------------ primitives

    public static GlowParticle glow(Vec3 pos, Vec3 vel, float[] col, float size0, float size1, int life, float drag) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        Particle p = mc.particleEngine.createParticle(GodlikeParticles.GLOW.get(), pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
        if (p instanceof GlowParticle g) {
            return g.setup(col[0], col[1], col[2], size0, size1, life, drag, 0);
        }
        return null;
    }

    public static SparkParticle spark(Vec3 pos, Vec3 vel, float[] col, float size, int life, float drag, float gravity, boolean collide) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        Particle p = mc.particleEngine.createParticle(GodlikeParticles.SPARK.get(), pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
        if (p instanceof SparkParticle s) {
            return s.setup(col[0], col[1], col[2], size, life, drag, gravity, collide);
        }
        return null;
    }

    public static ShockRingParticle ring(Vec3 pos, float[] col, float r0, float r1, int life, float alpha) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        Particle p = mc.particleEngine.createParticle(GodlikeParticles.RING.get(), pos.x, pos.y, pos.z, 0, 0, 0);
        if (p instanceof ShockRingParticle s) {
            return s.setup(col[0], col[1], col[2], r0, r1, life, alpha);
        }
        return null;
    }

    public static StreakParticle streak(Vec3 pos, Vec3 axis, Vec3 vel, float[] col, float length, float width, int life, float alpha) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        Particle p = mc.particleEngine.createParticle(GodlikeParticles.STREAK.get(), pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
        if (p instanceof StreakParticle s) {
            return s.setup(col[0], col[1], col[2], axis, length, width, life, alpha, 0.85f);
        }
        return null;
    }

    private static void vanilla(net.minecraft.core.particles.ParticleOptions type, Vec3 pos, Vec3 vel) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) mc.level.addParticle(type, pos.x, pos.y, pos.z, vel.x, vel.y, vel.z);
    }

    private static void localSound(Vec3 pos, net.minecraft.sounds.SoundEvent sound, float volume, float pitch) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) mc.level.playLocalSound(pos.x, pos.y, pos.z, sound, SoundSource.PLAYERS, volume, pitch, false);
    }

    public static void uiSound(net.minecraft.sounds.SoundEvent sound, float volume, float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
    }

    // ------------------------------------------------------------ sphere / burst helpers

    public static void sparkBurst(Vec3 center, int n, float speed, float[] col, float size, int life, float gravity) {
        for (int i = 0; i < count(n); i++) {
            Vec3 d = randomDir();
            float s = speed * (0.4f + RNG.nextFloat() * 0.8f);
            spark(center, d.scale(s), col, size * (0.6f + RNG.nextFloat() * 0.8f), life + RNG.nextInt(Math.max(1, life / 2)), 0.9f, gravity, false);
        }
    }

    public static void glowBurst(Vec3 center, int n, float speed, float[] col, float size, int life) {
        for (int i = 0; i < count(n); i++) {
            Vec3 d = randomDir();
            glow(center, d.scale(speed * (0.3f + RNG.nextFloat())), col, size * (0.5f + RNG.nextFloat()), 0.0f, life + RNG.nextInt(Math.max(1, life / 2)), 0.9f);
        }
    }

    public static void shell(Vec3 center, double radius, int n, float[] col, float outward, float size, int life) {
        for (int i = 0; i < count(n); i++) {
            Vec3 d = randomDir();
            Vec3 p = center.add(d.scale(radius));
            spark(p, d.scale(outward), col, size, life, 0.9f, 0.0f, false);
        }
    }

    // ------------------------------------------------------------ Super Laser

    public static void beam(Vec3 start, Vec3 end, float power) {
        Vec3 d = end.subtract(start);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 dir = d.scale(1.0 / len);
        Vec3 perp = GodlikeMath.perpendicular(dir);
        Vec3 perp2 = dir.cross(perp).normalize();
        double step = 0.6;
        int steps = (int) Math.min(600, len / step);
        float radius = 0.9f + 1.1f * power;
        for (int i = 0; i <= steps; i++) {
            double t = i * step;
            Vec3 p = start.add(dir.scale(t));
            if (RNG.nextFloat() < 0.8 * density()) {
                double ang = RNG.nextDouble() * Math.PI * 2;
                Vec3 radial = perp.scale(Math.cos(ang)).add(perp2.scale(Math.sin(ang)));
                Vec3 pos = p.add(radial.scale(radius * (0.6 + RNG.nextDouble() * 0.6)));
                spark(pos, radial.scale(0.15 + 0.35 * power).add(dir.scale(0.4)), i % 3 == 0 ? WHITE : CYAN, 0.14f, 14 + RNG.nextInt(10), 0.9f, 0.01f, false);
            }
            if (i % 2 == 0) {
                glow(p, dir.scale(0.05), i % 4 == 0 ? VIOLET : CYAN, radius * 1.4f, 0.0f, 10 + RNG.nextInt(6), 1.0f);
            }
            if (i % 5 == 0) {
                streak(p, dir, dir.scale(0.9 + power), WHITE, 3.0f + 4.0f * power, 0.25f + 0.2f * power, 10, 0.9f);
            }
        }
        // muzzle flash
        glow(start, Vec3.ZERO, WHITE, 1.5f + 2.0f * power, 0.2f, 10, 1.0f);
        glow(start, Vec3.ZERO, CYAN, 3.0f + 3.0f * power, 0.5f, 12, 1.0f);
        sparkBurst(start, 30, 0.6f, CYAN, 0.16f, 14, 0.02f);
        ring(start.subtract(0, 0.2, 0), CYAN, 0.5f, 5.0f + 4.0f * power, 12, 0.9f);
        localSound(start, SoundEvents.ELYTRA_FLYING, 2.0f, 0.5f);
    }

    public static void laserImpact(Vec3 pos, Vec3 dir, float power) {
        float k = 1.0f + power;
        vanilla(ParticleTypes.FLASH, pos, Vec3.ZERO);
        glow(pos, Vec3.ZERO, WHITE, 6.0f * k, 1.0f, 12, 1.0f);
        glow(pos, Vec3.ZERO, CYAN, 12.0f * k, 3.0f, 16, 1.0f);
        glow(pos, Vec3.ZERO, VIOLET, 18.0f * k, 6.0f, 22, 1.0f);
        sparkBurst(pos, 220, 1.4f * k, WHITE, 0.2f, 24, 0.03f);
        sparkBurst(pos, 160, 0.9f * k, CYAN, 0.24f, 30, 0.02f);
        sparkBurst(pos, 90, 0.5f * k, VIOLET, 0.3f, 40, 0.01f);
        for (int i = 0; i < 3; i++) {
            ring(pos.subtract(0, 0.1 * i, 0), i == 0 ? WHITE : (i == 1 ? CYAN : VIOLET), 0.5f, 8.0f * k + i * 3.0f, 14 + i * 6, 1.0f);
        }
        ShockRingParticle wall = ring(pos, CYAN, 0.5f, 6.0f * k, 12, 0.8f);
        if (wall != null) wall.tilt(1.0f, 0.0f);
        for (int i = 0; i < count(40); i++) {
            vanilla(ParticleTypes.LARGE_SMOKE, pos.add(randomDir().scale(1.5 * k)), randomDir().scale(0.15).add(0, 0.2, 0));
        }
        for (int i = 0; i < count(30); i++) {
            Vec3 d = randomDir();
            streak(pos.add(d.scale(0.5)), d, d.scale(1.2 * k), WHITE, 2.5f, 0.2f, 16, 0.9f);
        }
        // the planted core wakes up
        ClientState.SEQUENCES.add(new PulseSequence(pos.subtract(dir.scale(0.8)), 40));
    }

    public static void laserFizzle(Vec3 pos, Vec3 dir) {
        Vec3 p = pos.add(dir.scale(1.2)).subtract(0, 0.3, 0);
        sparkBurst(p, 24, 0.35f, VIOLET, 0.12f, 12, 0.03f);
        glow(p, Vec3.ZERO, VIOLET, 1.5f, 0.0f, 8, 1.0f);
    }

    /** Called every client tick for a player that is charging the laser. */
    public static void chargeTick(Player player, int charge, float partial) {
        Vec3 look = player.getLookAngle().normalize();
        Vec3 orb = player.getEyePosition().add(look.scale(1.1)).subtract(0, 0.35, 0);
        float power = LaserChargeHelper.power(charge);
        float[] col = mix(mix(VIOLET, CYAN, Math.min(1.0f, charge / 20.0f)), WHITE, power * 0.8f);
        // energy gets sucked in from all around
        int n = count(4 + (int) (6 * power));
        for (int i = 0; i < n; i++) {
            Vec3 d = randomDir();
            double r = 2.0 + RNG.nextDouble() * 2.0 + power;
            Vec3 p = orb.add(d.scale(r));
            Vec3 v = d.scale(-r / 9.0);
            spark(p, v, i % 2 == 0 ? col : CYAN, 0.1f + 0.06f * power, 9, 1.0f, 0.0f, false);
        }
        if (charge % 2 == 0) {
            glow(orb, Vec3.ZERO, col, 0.5f + 1.2f * power, 0.1f, 6, 1.0f);
        }
        if (charge % 10 == 0) {
            ring(orb, col, 3.0f + 2.0f * power, 0.3f, 10, 0.8f);
        }
        if (power >= 1.0f && charge % 4 == 0) {
            sparkBurst(orb, 6, 0.3f, WHITE, 0.12f, 8, 0.0f);
        }
    }

    // ------------------------------------------------------------ Ginormous explosion

    public static void megaExplosion(Vec3 center, float radius) {
        vanilla(ParticleTypes.FLASH, center, Vec3.ZERO);
        glow(center, Vec3.ZERO, WHITE, radius * 2.0f, radius * 0.5f, 20, 1.0f);
        glow(center, Vec3.ZERO, GOLD, radius * 3.0f, radius, 30, 1.0f);
        glow(center, Vec3.ZERO, VIOLET, radius * 4.5f, radius * 2.0f, 40, 1.0f);
        sparkBurst(center, 400, radius * 0.12f, WHITE, 0.3f, 50, 0.01f);
        sparkBurst(center, 300, radius * 0.08f, GOLD, 0.4f, 60, 0.02f);
        sparkBurst(center, 200, radius * 0.05f, ORANGE, 0.5f, 80, 0.03f);
        for (int i = 0; i < 4; i++) {
            ring(center.add(0, i * 0.5, 0), i % 2 == 0 ? WHITE : GOLD, 1.0f, radius * (2.5f + i * 0.5f), 30 + i * 8, 1.0f);
        }
        for (int i = 0; i < count(120); i++) {
            Vec3 d = randomDir();
            streak(center.add(d.scale(2)), d, d.scale(radius * 0.08), WHITE, 6.0f, 0.5f, 30, 1.0f);
        }
        // pillar of light
        for (int i = 0; i < count(60); i++) {
            Vec3 p = center.add((RNG.nextDouble() - 0.5) * 3, RNG.nextDouble() * radius * 2, (RNG.nextDouble() - 0.5) * 3);
            glow(p, new Vec3(0, 0.6, 0), GOLD, 2.5f, 0.0f, 40 + RNG.nextInt(20), 0.98f);
        }
        localSound(center, SoundEvents.GENERIC_EXPLODE, 6.0f, 0.4f);
        localSound(center, SoundEvents.ENDER_DRAGON_GROWL, 4.0f, 0.5f);
        ClientState.SEQUENCES.add(new ExplosionWaveSequence(center, Math.round(radius)));
    }

    /** Expanding visual shell that matches the server-side destruction wave (1 block per tick). */
    private static final class ExplosionWaveSequence implements ClientState.FxSequence {
        private final Vec3 center;
        private final int maxRadius;
        private int r = 0;

        ExplosionWaveSequence(Vec3 center, int maxRadius) {
            this.center = center;
            this.maxRadius = Math.max(2, maxRadius);
        }

        @Override
        public boolean tick() {
            r++;
            if (r > maxRadius + 6) return false;
            float progress = r / (float) maxRadius;
            float[] col = mix(WHITE, mix(GOLD, ORANGE, progress), Math.min(1.0f, progress * 1.5f));
            int n = 30 + r * 3;
            shell(center, r, n, col, 0.35f, 0.25f + progress * 0.25f, 16 + RNG.nextInt(10));
            if (r % 3 == 0) {
                for (int i = 0; i < count(10); i++) {
                    Vec3 d = randomDir();
                    Vec3 p = center.add(d.scale(r));
                    glow(p, d.scale(0.3), i % 2 == 0 ? GOLD : VIOLET, 3.0f + progress * 3.0f, 0.0f, 18, 0.95f);
                    vanilla(ParticleTypes.LARGE_SMOKE, p, d.scale(0.2).add(0, 0.15, 0));
                }
            }
            if (r % 4 == 0) {
                ring(center.add(0, 0.3, 0), col, r, r + 4.0f, 10, 0.9f);
            }
            if (r == maxRadius) {
                ring(center, WHITE, r, r * 1.8f, 30, 1.0f);
                ring(center, GOLD, r * 0.5f, r * 1.4f, 40, 1.0f);
                sparkBurst(center, 200, r * 0.1f, WHITE, 0.35f, 60, 0.02f);
                localSound(center, SoundEvents.LIGHTNING_BOLT_THUNDER, 6.0f, 0.4f);
            }
            return true;
        }
    }

    /** Pulsing warning rings from a freshly planted core. */
    private static final class PulseSequence implements ClientState.FxSequence {
        private final Vec3 pos;
        private int ticks;

        PulseSequence(Vec3 pos, int ticks) {
            this.pos = pos;
            this.ticks = ticks;
        }

        @Override
        public boolean tick() {
            if (ticks-- <= 0) return false;
            if (ticks % 8 == 0) ring(pos, CYAN, 0.5f, 4.0f, 12, 0.7f);
            spark(pos.add(randomDir().scale(0.5)), new Vec3(0, 0.15, 0), VIOLET, 0.12f, 20, 0.95f, 0.0f, false);
            return true;
        }
    }

    public static void coreWarning(Vec3 pos, int fuse, float power) {
        float urgency = 1.0f - Mth.clamp(fuse / 300.0f, 0.0f, 1.0f);
        float[] col = mix(CYAN, MAGENTA, urgency);
        ring(pos, col, 0.3f, 4.0f + 8.0f * urgency + 4.0f * power, 16, 0.9f);
        glow(pos, Vec3.ZERO, col, 3.0f + 4.0f * urgency, 0.5f, 10, 1.0f);
        sparkBurst(pos, 10 + (int) (30 * urgency), 0.3f + urgency * 0.5f, col, 0.14f, 20, 0.02f);
    }

    // ------------------------------------------------------------ Godlike Punch

    public static void punch(Vec3 pos, Vec3 dir, float radius, boolean hit) {
        Vec3 d = dir.normalize();
        vanilla(ParticleTypes.FLASH, pos, Vec3.ZERO);
        glow(pos, Vec3.ZERO, WHITE, 3.0f, 0.5f, 8, 1.0f);
        glow(pos, Vec3.ZERO, hit ? GOLD : CYAN, 7.0f, 2.0f, 14, 1.0f);
        glow(pos, Vec3.ZERO, VIOLET, 10.0f, 3.0f, 18, 1.0f);
        // ground rings
        Vec3 ground = pos.subtract(0, 1.2, 0);
        ring(ground, WHITE, 0.5f, radius, 12, 1.0f);
        ring(ground.add(0, 0.2, 0), GOLD, 0.5f, radius * 1.3f, 18, 0.9f);
        ring(ground.add(0, 0.4, 0), VIOLET, 1.0f, radius * 1.6f, 24, 0.8f);
        // forward cone of sparks
        Vec3 perp = GodlikeMath.perpendicular(d);
        Vec3 perp2 = d.cross(perp).normalize();
        for (int i = 0; i < count(140); i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double spread = RNG.nextDouble() * 0.7;
            Vec3 v = d.add(perp.scale(Math.cos(ang) * spread)).add(perp2.scale(Math.sin(ang) * spread)).normalize().scale(0.6 + RNG.nextDouble() * 1.4);
            spark(pos, v, i % 3 == 0 ? WHITE : (i % 3 == 1 ? GOLD : CYAN), 0.18f, 18 + RNG.nextInt(12), 0.92f, 0.03f, true);
        }
        sparkBurst(pos, 80, 0.8f, WHITE, 0.16f, 16, 0.02f);
        for (int i = 0; i < count(40); i++) {
            Vec3 v = randomDir().scale(0.35).add(d.scale(0.5));
            vanilla(ParticleTypes.CLOUD, pos.add(randomDir().scale(0.8)), v);
        }
        for (int i = 0; i < count(30); i++) {
            Vec3 dd = randomDir();
            streak(pos.add(dd.scale(0.3)), dd, dd.scale(1.0), WHITE, 2.0f, 0.18f, 12, 0.9f);
        }
        if (hit) {
            sparkBurst(pos, 60, 1.2f, MAGENTA, 0.2f, 20, 0.02f);
        }
    }

    // ------------------------------------------------------------ Lightspeed Dash

    public static void dashStreak(Vec3 a, Vec3 b) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 dir = d.scale(1.0 / len);
        double step = 0.7;
        int steps = (int) Math.min(700, len / step);
        for (int i = 0; i <= steps; i++) {
            Vec3 p = a.add(dir.scale(i * step)).add(randomDir().scale(0.25));
            if (i % 2 == 0) glow(p, Vec3.ZERO, i % 4 == 0 ? WHITE : CYAN, 1.1f, 0.0f, 12 + RNG.nextInt(8), 1.0f);
            if (RNG.nextFloat() < 0.6 * density()) spark(p, randomDir().scale(0.12).add(dir.scale(0.05)), CYAN, 0.12f, 14 + RNG.nextInt(10), 0.92f, 0.005f, false);
            if (i % 3 == 0) streak(p, dir, dir.scale(0.3), WHITE, 3.5f, 0.22f, 12, 0.9f);
        }
        glow(a, Vec3.ZERO, WHITE, 2.5f, 0.0f, 8, 1.0f);
        ring(a.subtract(0, 0.8, 0), CYAN, 0.3f, 4.0f, 10, 0.9f);
        ShockRingParticle wall = ring(a, VIOLET, 0.3f, 3.0f, 10, 0.8f);
        if (wall != null) wall.tilt(1.0f, 0.0f);
        glow(b, Vec3.ZERO, WHITE, 3.0f, 0.2f, 10, 1.0f);
        glow(b, Vec3.ZERO, CYAN, 5.0f, 1.0f, 14, 1.0f);
        sparkBurst(b, 60, 0.8f, WHITE, 0.16f, 16, 0.02f);
        ring(b.subtract(0, 0.8, 0), WHITE, 0.3f, 6.0f, 12, 1.0f);
        ring(b.subtract(0, 0.6, 0), VIOLET, 0.3f, 8.0f, 18, 0.8f);
    }

    /** Tiny per-tick sparkle while aiming, at the destination marker. */
    public static void aimMarkerTick(Vec3 target, boolean blocked) {
        float[] col = blocked ? MAGENTA : CYAN;
        spark(target.add(randomDir().scale(0.4)).add(0, 0.9, 0), new Vec3(0, 0.05, 0), col, 0.1f, 10, 0.9f, 0.0f, false);
        if (ClientState.clientTicks % 5 == 0) {
            ring(target.add(0, 0.05, 0), col, 0.2f, 1.6f, 10, 0.7f);
        }
    }

    // ------------------------------------------------------------ misc

    public static void ascend(Vec3 pos) {
        glow(pos.add(0, 1, 0), Vec3.ZERO, WHITE, 4.0f, 0.5f, 20, 1.0f);
        glow(pos.add(0, 1, 0), Vec3.ZERO, VIOLET, 9.0f, 2.0f, 30, 1.0f);
        ring(pos.add(0, 0.05, 0), CYAN, 0.5f, 10.0f, 24, 1.0f);
        ring(pos.add(0, 0.1, 0), VIOLET, 0.5f, 14.0f, 34, 0.9f);
        sparkBurst(pos.add(0, 1, 0), 120, 0.7f, WHITE, 0.16f, 30, 0.01f);
        localSound(pos, SoundEvents.TOTEM_USE, 2.0f, 0.7f);
        ClientState.SEQUENCES.add(new ClientState.FxSequence() {
            int t = 0;

            @Override
            public boolean tick() {
                t++;
                if (t > 60) return false;
                for (int k = 0; k < 2; k++) {
                    double ang = t * 0.35 + k * Math.PI;
                    double r = 1.4;
                    double y = t * 0.09;
                    Vec3 p = pos.add(Math.cos(ang) * r, y, Math.sin(ang) * r);
                    glow(p, new Vec3(0, 0.05, 0), k == 0 ? CYAN : VIOLET, 0.8f, 0.0f, 24, 0.96f);
                    spark(p, new Vec3(0, 0.1, 0), WHITE, 0.12f, 20, 0.95f, 0.0f, false);
                }
                for (int i = 0; i < count(3); i++) {
                    Vec3 p = pos.add((RNG.nextDouble() - 0.5) * 1.5, RNG.nextDouble() * 4, (RNG.nextDouble() - 0.5) * 1.5);
                    glow(p, new Vec3(0, 0.25, 0), WHITE, 1.2f, 0.0f, 25, 0.97f);
                }
                return true;
            }
        });
    }

    public static void shield(Vec3 pos, float amount) {
        int n = count(12 + (int) Math.min(30, amount));
        for (int i = 0; i < n; i++) {
            double ang = RNG.nextDouble() * Math.PI * 2;
            double y = (RNG.nextDouble() - 0.5) * 1.8;
            Vec3 p = pos.add(Math.cos(ang) * 0.9, y, Math.sin(ang) * 0.9);
            spark(p, new Vec3(Math.cos(ang) * 0.08, 0, Math.sin(ang) * 0.08), CYAN, 0.12f, 10, 0.9f, 0.0f, false);
        }
        glow(pos, Vec3.ZERO, CYAN, 2.2f, 0.4f, 8, 1.0f);
    }

    /** Subtle cosmic aura for ascended players. */
    public static void auraTick(Player player) {
        if (!GodlikeConfig.CLIENT.particleDensity.get().equals(0.0) && ClientState.clientTicks % 2 == 0) {
            double ang = ClientState.clientTicks * 0.15 + player.getId();
            double r = 0.75;
            Vec3 base = player.position().add(0, 0.2 + ((Math.sin(ClientState.clientTicks * 0.05 + player.getId()) + 1) * 0.6), 0);
            Vec3 p = base.add(Math.cos(ang) * r, 0, Math.sin(ang) * r);
            spark(p, new Vec3(0, 0.02, 0), ClientState.clientTicks % 4 == 0 ? CYAN : VIOLET, 0.07f, 12, 0.9f, 0.0f, false);
        }
    }

    // ------------------------------------------------------------ Cosmic Barrage

    /** Orbs swirling around the hand while charging; one spark per orb that will be launched. */
    public static void barrageChargeTick(Player player, int charge) {
        Vec3 look = player.getLookAngle().normalize();
        Vec3 center = player.getEyePosition().add(look.scale(1.0)).subtract(0, 0.3, 0);
        Vec3 u = GodlikeMath.perpendicular(look);
        Vec3 w = look.cross(u).normalize();
        int count = BarrageChargeHelper.count(charge);
        float power = BarrageChargeHelper.power(charge);
        double t = ClientState.clientTicks * 0.22;
        for (int i = 0; i < count; i++) {
            double a = t + i * Math.PI * 2 / count;
            double r = 0.55 + 0.25 * Math.sin(t * 0.7 + i);
            Vec3 p = center.add(u.scale(Math.cos(a) * r)).add(w.scale(Math.sin(a) * r));
            spark(p, Vec3.ZERO, i % 3 == 0 ? WHITE : (i % 3 == 1 ? CYAN : VIOLET), 0.12f + 0.06f * power, 6, 0.9f, 0.0f, false);
        }
        if (charge % 3 == 0) {
            Vec3 d = randomDir();
            Vec3 p = center.add(d.scale(2.0 + RNG.nextDouble()));
            spark(p, center.subtract(p).scale(1.0 / 8.0), MAGENTA, 0.09f, 8, 1.0f, 0.0f, false);
        }
        if (charge % 4 == 0) glow(center, Vec3.ZERO, VIOLET, 0.6f + 0.6f * power, 0.1f, 6, 1.0f);
    }

    public static void barrageLaunch(Vec3 pos, Vec3 dir, int count) {
        Vec3 d = dir.normalize();
        glow(pos, Vec3.ZERO, WHITE, 1.4f, 0.2f, 8, 1.0f);
        glow(pos, Vec3.ZERO, VIOLET, 3.0f, 0.5f, 12, 1.0f);
        ring(pos.subtract(0, 0.3, 0), VIOLET, 0.4f, 3.5f, 12, 0.8f);
        ShockRingParticle wall = ring(pos, CYAN, 0.3f, 2.5f, 10, 0.8f);
        if (wall != null) wall.tilt(1.0f, 0.0f);
        for (int i = 0; i < count(10 + count * 3); i++) {
            Vec3 v = d.scale(0.4 + RNG.nextDouble() * 0.6).add(randomDir().scale(0.25));
            spark(pos, v, i % 2 == 0 ? WHITE : CYAN, 0.14f, 14, 0.92f, 0.0f, false);
        }
        localSound(pos, SoundEvents.ENDER_DRAGON_SHOOT, 1.0f, 1.5f);
    }

    /** Per-tick trail for a flying orb (client entity tick). */
    public static void orbTrail(Vec3 pos, Vec3 vel, float power, int tier, int tickCount) {
        if (tier == 0) {
            float size = 0.45f + 0.35f * power;
            glow(pos, vel.scale(-0.05), tickCount % 2 == 0 ? CYAN : WHITE, size, 0.0f, 9, 0.9f);
            if (tickCount % 2 == 0) glow(pos, vel.scale(-0.1), VIOLET, size * 1.8f, 0.0f, 7, 0.9f);
            if (RNG.nextFloat() < 0.7 * density()) {
                spark(pos.add(randomDir().scale(0.25)), vel.scale(-0.15).add(randomDir().scale(0.05)), i(tickCount) ? WHITE : CYAN, 0.1f, 12 + RNG.nextInt(8), 0.92f, 0.0f, false);
            }
            if (tickCount % 6 == 0) streak(pos, vel, vel.scale(-0.2), WHITE, 1.6f, 0.14f, 8, 0.8f);
        } else {
            glow(pos, vel.scale(-0.05), tickCount % 2 == 0 ? GOLD : ORANGE, 0.28f, 0.0f, 7, 0.9f);
            if (RNG.nextFloat() < 0.8 * density()) {
                spark(pos, vel.scale(-0.2).add(randomDir().scale(0.04)), GOLD, 0.08f, 10 + RNG.nextInt(6), 0.9f, 0.02f, false);
            }
        }
    }

    private static boolean i(int t) {
        return (t & 1) == 0;
    }

    public static void orbExplosion(Vec3 pos, float radius, int tier) {
        float k = Math.max(0.5f, radius);
        float[] hot = tier == 0 ? CYAN : GOLD;
        float[] halo = tier == 0 ? VIOLET : ORANGE;
        if (tier == 0) vanilla(ParticleTypes.FLASH, pos, Vec3.ZERO);
        glow(pos, Vec3.ZERO, WHITE, k * 1.2f, 0.3f, 8, 1.0f);
        glow(pos, Vec3.ZERO, hot, k * 2.4f, 0.8f, 12, 1.0f);
        glow(pos, Vec3.ZERO, halo, k * 3.6f, 1.2f, 16, 1.0f);
        sparkBurst(pos, tier == 0 ? 90 : 35, 0.45f * k, WHITE, 0.16f, 16, 0.02f);
        sparkBurst(pos, tier == 0 ? 70 : 25, 0.28f * k, hot, 0.2f, 24, 0.03f);
        ring(pos.subtract(0, 0.2, 0), hot, 0.4f, k * 2.2f, 12, 0.9f);
        if (tier == 0) {
            ring(pos.add(0, 0.1, 0), halo, 0.4f, k * 3.0f, 18, 0.8f);
            ShockRingParticle wall = ring(pos, WHITE, 0.3f, k * 1.8f, 10, 0.7f);
            if (wall != null) wall.tilt(1.0f, 0.0f);
            for (int i = 0; i < count(14); i++) {
                Vec3 d = randomDir();
                streak(pos.add(d.scale(0.3)), d, d.scale(0.6 * k), WHITE, 1.8f, 0.16f, 12, 0.9f);
            }
        }
        for (int i = 0; i < count(tier == 0 ? 10 : 4); i++) {
            vanilla(ParticleTypes.LARGE_SMOKE, pos.add(randomDir().scale(0.6 * k)), randomDir().scale(0.1).add(0, 0.12, 0));
        }
    }

    // ------------------------------------------------------------ Chaos Control

    public static void chaosStart(Vec3 center, float radius) {
        Vec3 c = center.add(0, 1.0, 0);
        vanilla(ParticleTypes.FLASH, c, Vec3.ZERO);
        glow(c, Vec3.ZERO, WHITE, 5.0f, 0.5f, 12, 1.0f);
        glow(c, Vec3.ZERO, CYAN, 12.0f, 2.0f, 18, 1.0f);
        ring(center.add(0, 0.1, 0), WHITE, 1.0f, radius, 28, 1.0f);
        ring(center.add(0, 0.6, 0), CYAN, 1.0f, radius * 1.05f, 34, 0.8f);
        ShockRingParticle dome = ring(c, WHITE, 1.0f, radius * 0.5f, 24, 0.7f);
        if (dome != null) dome.tilt(0.3f, 0.0f);
        ShockRingParticle dome2 = ring(c, CYAN, 1.0f, radius * 0.5f, 24, 0.7f);
        if (dome2 != null) dome2.tilt(0.0f, -0.3f);
        sparkBurst(c, 120, 0.8f, WHITE, 0.14f, 30, 0.0f);
        localSound(center, SoundEvents.AMETHYST_BLOCK_RESONATE, 2.0f, 0.5f);
        // the time wave: a sphere of sparks racing outward through the frozen air
        ClientState.SEQUENCES.add(new ClientState.FxSequence() {
            int t = 0;

            @Override
            public boolean tick() {
                t++;
                if (t > 24) return false;
                double r = radius * (t / 24.0);
                shell(c, r, 35, t % 2 == 0 ? WHITE : CYAN, 0.02f, 0.14f, 26);
                return true;
            }
        });
    }

    public static void chaosEnd(Vec3 center, float radius) {
        Vec3 c = center.add(0, 1.0, 0);
        // rings collapsing back into the player, then a snap
        ring(center.add(0, 0.1, 0), CYAN, radius * 0.7f, 0.5f, 16, 0.9f);
        ring(center.add(0, 0.6, 0), WHITE, radius * 0.5f, 0.5f, 12, 0.9f);
        glow(c, Vec3.ZERO, WHITE, 4.0f, 0.3f, 10, 1.0f);
        sparkBurst(c, 80, 0.9f, CYAN, 0.14f, 20, 0.02f);
        localSound(center, SoundEvents.GLASS_BREAK, 1.5f, 0.6f);
    }

    /** Suspended dust: slow white motes hanging in the frozen air around the viewer. */
    public static void timeDustTick(Vec3 center) {
        int n = count(3);
        for (int i = 0; i < n; i++) {
            Vec3 p = center.add((RNG.nextDouble() - 0.5) * 24, RNG.nextDouble() * 10 - 2, (RNG.nextDouble() - 0.5) * 24);
            spark(p, new Vec3(0, 0.002, 0), i == 0 ? CYAN : WHITE, 0.05f + RNG.nextFloat() * 0.04f, 60 + RNG.nextInt(40), 1.0f, 0.0f, false);
        }
    }

    /** Small glints on a frozen entity. */
    public static void frozenShimmer(Entity e) {
        AABB box = e.getBoundingBox();
        double x = Mth.lerp(RNG.nextDouble(), box.minX, box.maxX);
        double y = Mth.lerp(RNG.nextDouble(), box.minY, box.maxY);
        double z = Mth.lerp(RNG.nextDouble(), box.minZ, box.maxZ);
        spark(new Vec3(x, y, z), Vec3.ZERO, RNG.nextBoolean() ? WHITE : CYAN, 0.08f, 14, 1.0f, 0.0f, false);
    }

    /** Client-side mirror of the barrage charge curve. */
    public static final class BarrageChargeHelper {
        public static float power(int charge) {
            int min = GodlikeConfig.COMMON.barrageMinChargeTicks.get();
            int max = GodlikeConfig.COMMON.barrageMaxChargeTicks.get();
            if (max <= min) return 1.0f;
            return Mth.clamp((charge - min) / (float) (max - min), 0.0f, 1.0f);
        }

        public static float chargeFraction(int charge) {
            int max = GodlikeConfig.COMMON.barrageMaxChargeTicks.get();
            return Mth.clamp(charge / (float) Math.max(1, max), 0.0f, 1.0f);
        }

        public static int count(int charge) {
            int min = GodlikeConfig.COMMON.barrageMinCount.get();
            int max = GodlikeConfig.COMMON.barrageMaxCount.get();
            return Math.max(1, Math.round(Mth.lerp(power(charge), min, max)));
        }
    }

    /** Client-side helper to mirror the server's charge->power curve. */
    public static final class LaserChargeHelper {
        public static float power(int charge) {
            int min = GodlikeConfig.COMMON.laserMinChargeTicks.get();
            int max = GodlikeConfig.COMMON.laserMaxChargeTicks.get();
            if (max <= min) return 1.0f;
            return Mth.clamp((charge - min) / (float) (max - min), 0.0f, 1.0f);
        }

        public static float chargeFraction(int charge) {
            int max = GodlikeConfig.COMMON.laserMaxChargeTicks.get();
            return Mth.clamp(charge / (float) Math.max(1, max), 0.0f, 1.0f);
        }
    }
}
