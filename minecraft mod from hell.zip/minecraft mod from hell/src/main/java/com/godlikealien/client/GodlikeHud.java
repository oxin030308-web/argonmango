package com.godlikealien.client;

import com.baranhan123.viltrumitecore.util.ViltrumiteAbilityUser;
import com.godlikealien.GodlikeAbilities;
import com.godlikealien.GodlikeConfig;
import com.godlikealien.entity.UnstableCoreEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;

/**
 * Overlays drawn on top of ViltrumiteCore's ability hotbar: cooldown sweeps, laser charge, dash distance,
 * toggle states, plus crosshair readouts and the unstable core countdown.
 */
public final class GodlikeHud {
    // Layout constants copied from ViltrumiteCore's HUD mixin so our overlays land exactly on its slots.
    private static final int RIGHT_WIDTH = 62;
    private static final int BAR_HEIGHT = 22;
    private static final int VERT_WIDTH = 22;
    private static final int VERT_HEIGHT = 120;
    private static final int PADDING = 5;

    private static final int COL_CYAN = 0xFF5FEFFF;
    private static final int COL_WHITE = 0xFFFFFFFF;
    private static final int COL_VIOLET = 0xFFB08CFF;
    private static final int COL_MAGENTA = 0xFFFF66E0;
    private static final int COL_GREY = 0xFFA0A0A0;

    private GodlikeHud() {}

    public static void render(GuiGraphics g, Minecraft mc, ViltrumiteAbilityUser user, float partialTick) {
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        int rightBarX = w - RIGHT_WIDTH - PADDING;
        int barY = h - BAR_HEIGHT - PADDING;
        int vertBarX = rightBarX + RIGHT_WIDTH - VERT_WIDTH;
        int vertBarY = barY - VERT_HEIGHT;
        int offset = user.getActivePage() * 6;
        float time = ClientState.clientTicks + partialTick;
        float pulse = 0.5f + 0.5f * Mth.sin(time * 0.35f);

        for (int i = 0; i < 6; i++) {
            String id = user.getAbilityInSlot(offset + i);
            if (!GodlikeAbilities.isGodlike(id)) continue;
            int slotX = vertBarX + 3;
            int slotY = vertBarY + 3 + i * 20;
            renderSlot(g, mc, id, slotX, slotY, pulse);
        }

        renderCrosshairReadouts(g, mc, w, h, pulse);
        renderCoreCountdown(g, mc, w, pulse);
    }

    private static void renderSlot(GuiGraphics g, Minecraft mc, String id, int x, int y, float pulse) {
        int cd = GodlikeAbilities.cooldownIndex(id);
        boolean usable = ClientState.usable();

        if (!usable) {
            g.fill(x, y, x + 16, y + 16, 0x90200010);
            drawScaled(g, mc, "LOCKED", x + 8, y + 8, COL_MAGENTA, 0.5f);
            return;
        }

        if (cd >= 0 && ClientState.cooldown[cd] > 0) {
            float frac = ClientState.cooldown[cd] / (float) Math.max(1, ClientState.cooldownMax[cd]);
            int hgt = Mth.ceil(16 * frac);
            g.fill(x, y, x + 16, y + hgt, 0xB0081428);
            g.fill(x, y + hgt - 1, x + 16, y + hgt, 0xFF5FEFFF);
            String s = String.format("%.1f", ClientState.cooldown[cd] / 20.0f);
            drawScaled(g, mc, s, x + 8, y + 8, COL_WHITE, 0.6f);
        }

        if (GodlikeAbilities.LASER.equals(id) && ClientState.laserCharge >= 0) {
            float frac = GodlikeFx.LaserChargeHelper.chargeFraction(ClientState.laserCharge);
            float power = GodlikeFx.LaserChargeHelper.power(ClientState.laserCharge);
            int hgt = Mth.ceil(16 * frac);
            int col = power >= 1.0f ? 0x90FFFFFF : 0x9040E0FF;
            g.fill(x, y + 16 - hgt, x + 16, y + 16, col);
            frame(g, x, y, power >= 1.0f ? COL_WHITE : COL_CYAN, pulse);
        }

        if (GodlikeAbilities.DASH.equals(id) && ClientState.aiming) {
            frame(g, x, y, ClientState.aimBlocked ? COL_MAGENTA : COL_CYAN, pulse);
        }

        if (GodlikeAbilities.BARRAGE.equals(id)) {
            if (ClientState.barrageCharge >= 0) {
                float frac = GodlikeFx.BarrageChargeHelper.chargeFraction(ClientState.barrageCharge);
                float power = GodlikeFx.BarrageChargeHelper.power(ClientState.barrageCharge);
                int hgt = Mth.ceil(16 * frac);
                g.fill(x, y + 16 - hgt, x + 16, y + 16, power >= 1.0f ? 0x90FFFFFF : 0x90C070FF);
                frame(g, x, y, power >= 1.0f ? COL_WHITE : COL_VIOLET, pulse);
                drawScaled(g, mc, "x" + GodlikeFx.BarrageChargeHelper.count(ClientState.barrageCharge), x + 8, y + 8, COL_WHITE, 0.7f);
            } else if (ClientState.orbsAlive) {
                frame(g, x, y, COL_MAGENTA, pulse);
            }
        }

        if (GodlikeAbilities.CHAOS.equals(id) && ClientState.timeStopTicks > 0) {
            int max = Math.max(1, GodlikeConfig.COMMON.chaosDurationTicks.get());
            float frac = Mth.clamp(ClientState.timeStopTicks / (float) max, 0.0f, 1.0f);
            int hgt = Mth.ceil(16 * frac);
            g.fill(x, y + 16 - hgt, x + 16, y + 16, 0x80A0D8FF);
            frame(g, x, y, COL_WHITE, pulse);
            drawScaled(g, mc, String.format("%.1f", ClientState.timeStopTicks / 20.0f), x + 8, y + 8, COL_WHITE, 0.6f);
        }

        if (GodlikeAbilities.RESISTANCE.equals(id)) {
            statusDot(g, x, y, ClientState.resistance);
        }
        if (GodlikeAbilities.SONIC_FLIGHT.equals(id)) {
            statusDot(g, x, y, ClientState.sonic);
        }
    }

    private static void statusDot(GuiGraphics g, int x, int y, boolean on) {
        int col = on ? 0xFF40FF80 : 0xFFFF4040;
        g.fill(x + 12, y, x + 16, y + 4, 0xC0000000);
        g.fill(x + 13, y + 1, x + 15, y + 3, col);
    }

    private static void frame(GuiGraphics g, int x, int y, int color, float pulse) {
        int a = (int) (120 + 135 * pulse);
        int col = (a << 24) | (color & 0xFFFFFF);
        g.fill(x - 1, y - 1, x + 17, y, col);
        g.fill(x - 1, y + 16, x + 17, y + 17, col);
        g.fill(x - 1, y, x, y + 16, col);
        g.fill(x + 16, y, x + 17, y + 16, col);
    }

    private static void renderCrosshairReadouts(GuiGraphics g, Minecraft mc, int w, int h, float pulse) {
        int cx = w / 2;
        int cy = h / 2;
        if (ClientState.aiming) {
            String main = "LIGHTSPEED DASH  " + ClientState.dashDistance() + " m";
            String hint = ClientState.aimBlocked ? "path blocked - shortened" : "scroll: distance   release: go";
            int col = ClientState.aimBlocked ? COL_MAGENTA : COL_CYAN;
            g.drawCenteredString(mc.font, main, cx, cy + 14, col);
            drawScaled(g, mc, hint, cx, cy + 26, COL_GREY, 0.7f);
        }
        if (ClientState.laserCharge >= 0) {
            float frac = GodlikeFx.LaserChargeHelper.chargeFraction(ClientState.laserCharge);
            float power = GodlikeFx.LaserChargeHelper.power(ClientState.laserCharge);
            int barW = 70;
            int bx = cx - barW / 2;
            int by = cy + 16;
            g.fill(bx - 1, by - 1, bx + barW + 1, by + 5, 0xA0000000);
            int fillW = Mth.floor(barW * frac);
            int col = power >= 1.0f ? COL_WHITE : (power > 0 ? COL_CYAN : COL_VIOLET);
            g.fill(bx, by, bx + fillW, by + 4, col);
            String label = power >= 1.0f ? "MAXIMUM POWER" : (power > 0 ? "READY  " + Math.round(power * 100) + "%" : "CHARGING");
            drawScaled(g, mc, label, cx, by + 11, col, 0.75f);
        }
        if (ClientState.barrageCharge >= 0) {
            float frac = GodlikeFx.BarrageChargeHelper.chargeFraction(ClientState.barrageCharge);
            float power = GodlikeFx.BarrageChargeHelper.power(ClientState.barrageCharge);
            int count = GodlikeFx.BarrageChargeHelper.count(ClientState.barrageCharge);
            int barW = 70;
            int bx = cx - barW / 2;
            int by = cy + 16;
            g.fill(bx - 1, by - 1, bx + barW + 1, by + 5, 0xA0000000);
            int fillW = Mth.floor(barW * frac);
            int col = power >= 1.0f ? COL_WHITE : (power > 0 ? COL_VIOLET : COL_GREY);
            g.fill(bx, by, bx + fillW, by + 4, col);
            String label = (power > 0 ? "COSMIC BARRAGE  x" + count : "GATHERING ORBS") + (power >= 1.0f ? "  MAX" : "");
            drawScaled(g, mc, label, cx, by + 11, col, 0.75f);
        } else if (ClientState.orbsAlive) {
            drawScaled(g, mc, "orbs follow your crosshair  -  press again to detonate", cx, cy + 20, COL_MAGENTA, 0.7f);
        }
        if (ClientState.timeStopTicks > 0) {
            String t = String.format("TIME FROZEN  %.1fs", ClientState.timeStopTicks / 20.0f);
            g.drawCenteredString(mc.font, t, cx, cy - 26, pulse > 0.5f ? COL_WHITE : COL_CYAN);
            drawScaled(g, mc, "press again to resume", cx, cy - 14, COL_GREY, 0.7f);
        }
    }

    private static void renderCoreCountdown(GuiGraphics g, Minecraft mc, int w, float pulse) {
        if (mc.level == null || mc.player == null) return;
        UnstableCoreEntity nearest = null;
        double best = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof UnstableCoreEntity core) {
                double d = core.distanceToSqr(mc.player);
                boolean mine = core.getOwner().map(u -> u.equals(mc.player.getUUID())).orElse(false);
                if (!mine && d > 96 * 96) continue;
                if (d < best) {
                    best = d;
                    nearest = core;
                }
            }
        }
        if (nearest == null) return;
        float seconds = nearest.getFuse() / 20.0f;
        boolean mine = nearest.getOwner().map(u -> u.equals(mc.player.getUUID())).orElse(false);
        float progress = nearest.getProgress(0);
        int col = progress > 0.75f ? (pulse > 0.5f ? COL_MAGENTA : COL_WHITE) : COL_CYAN;
        String text = (mine ? "UNSTABLE CORE DETONATES IN " : "WARNING: UNSTABLE CORE  ") + String.format("%.1f", Math.max(0, seconds)) + "s";
        int dist = (int) Math.sqrt(best);
        String sub = dist + " m away   radius " + nearest.getExplosionRadius() + " blocks";
        int y = 6;
        int tw = mc.font.width(text);
        g.fill(w / 2 - tw / 2 - 4, y - 2, w / 2 + tw / 2 + 4, y + 18, 0x80000000);
        g.drawCenteredString(mc.font, text, w / 2, y, col);
        drawScaled(g, mc, sub, w / 2, y + 12, COL_GREY, 0.7f);
    }

    private static void drawScaled(GuiGraphics g, Minecraft mc, String text, int cx, int cy, int color, float scale) {
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1.0f);
        int tw = mc.font.width(text);
        g.drawString(mc.font, text, -tw / 2, -4, color, true);
        g.pose().popPose();
    }

    public static boolean enabled() {
        try {
            return GodlikeConfig.CLIENT.showHud.get();
        } catch (Exception e) {
            return true;
        }
    }
}
