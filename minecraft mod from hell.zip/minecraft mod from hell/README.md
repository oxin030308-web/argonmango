# Godlike Alien

An extension for **ViltrumiteCore / ViltrumiteFlight** (Minecraft Java 1.20.1, Forge 47.x) that adds a godlike
power set. The abilities plug straight into the Viltrumite ability menu (press **K**) and hotbar (**ALT** swaps pages).

## Abilities

| Ability | Type | What it does |
| --- | --- | --- |
| **Super Laser** | Hold | Hold to charge (1–3 s), release to fire a beam that annihilates everything in its path, blasts a crater at the impact and drills up to 24 blocks into the ground behind it. The impact point becomes an **Unstable Core** that detonates in a **ginormous explosion 15 s later** (radius scales with charge, up to 32 blocks; the destruction spreads over a few seconds so the server never freezes). |
| **Lightspeed Dash** | Hold + scroll | Hold to aim, **scroll wheel** sets the distance (4–256 blocks, Shift = bigger steps), release to move faster than light. Smashes straight through blocks, obliterates anything in the path. Tap for an instant dash at the last distance. |
| **Godlike Punch** | Instant | Uses the Viltrumite punch animation. Whatever it hits dies in **one shot**; the **Warden takes two**. Massive shockwave that launches everything nearby and pulverizes the ground. |
| **Cosmic Barrage** | Hold (+ press again) | Hold to gather 4 to 12 cosmic orbs (more with longer charge), release to launch them. The swarm **steers toward your crosshair**. Each orb that hits a block or mob explodes and bursts into a **cluster of bomblets** that scatter and explode again. Press the key again while orbs fly to **detonate them all**. |
| **Chaos Control** | Toggle | Stops time in a 96-block bubble around you for 8 s: mobs, players, arrows, TNT, falling blocks and your own orbs freeze mid-air (and keep their momentum for when time resumes). You keep moving and can hit frozen enemies. The world desaturates and a tick-tock counts down; press again to resume early. 30 s cooldown. |
| **Godlike Resistance** | Toggle (passive) | Nothing can hurt you: no damage of any kind, no fire, no drowning, no freezing. Only `/kill` and the void still work. |
| **Sonic Flight** | Toggle (passive) | Cruise past 80 % throttle and your flight ramps up to the **speed of sound** (343 m/s). |

## Becoming a Godlike Alien

* New players get a third option on the Viltrumite race screen: **Ascend: GODLIKE ALIEN**.
* Existing players: `/godlikealien ascend [players]` (operators). `/godlikealien equip` puts the abilities on a free hotbar page.
* Other commands: `descend`, `reset` (cooldowns), `toggle resistance|sonic`, `status`.
* `requireAscension` in `config/godlikealien-common.toml` can be set to `false` to let every Viltrumite use the abilities.

## Building

The Viltrumite jars are in `libs/`. Java 17 is required (the Prism Launcher runtime works):

```powershell
$env:JAVA_HOME = "C:\Users\demen\AppData\Roaming\PrismLauncher\java\java-runtime-gamma"
.\gradlew.bat build
```

The mod jar ends up in `build/libs/godlikealien-1.0.0.jar`. Drop it into the mods folder next to
`viltrumitecore-forge-1.7.3.jar` and `viltrumiteflight-forge-1.6.0.jar`.

## Configuration

* `config/godlikealien-common.toml` – damage, cooldowns, explosion radius, detonation delay, dash range, block breaking, sonic speed.
* `config/godlikealien-client.toml` – particle density, camera shake, screen flash, HUD toggle, saved dash distance.
